var my_titulo = 'Banco de Bogotá';
var my_contenido = `

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
<link
    href="https://fonts.googleapis.com/css2?family=Montserrat:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&amp;family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&amp;display=swap"
    rel="stylesheet">

<link rel="stylesheet"
    href="https://www.bancodebogota.com/wps/contenthandler/banco-de-bogota/!ut/p/digest!TM72YEXfiAGwPp639PTwww/sp/mashup:ra:collection?soffset=0&amp;eoffset=6&amp;themeID=ZJ_609I03O0J06TD0AM9I1D751G53&amp;locale=es&amp;locale=en&amp;mime-type=text%2Fcss&amp;entry=wp_one_ui_30__0.0%3Ahead_css&amp;entry=wp_one_ui_dijit_30__0.0%3Ahead_css&amp;entry=wp_legacy_layouts__0.0%3Ahead_css&amp;entry=wp_theme_portal_80__0.0%3Ahead_css&amp;entry=wp_status_bar__0.0%3Ahead_css&amp;entry=wp_portlet_css__0.0%3Ahead_css"
    type="text/css">
<link rel="stylesheet"
    href="https://www.bancodebogota.com/wps/contenthandler/banco-de-bogota/!ut/p/digest!TM72YEXfiAGwPp639PTwww/sp/mashup:ra:collection?soffset=6&amp;eoffset=13&amp;themeID=ZJ_609I03O0J06TD0AM9I1D751G53&amp;locale=es&amp;locale=en&amp;mime-type=text%2Fcss&amp;entry=wp_one_ui_30__0.0%3Ahead_css&amp;entry=wp_one_ui_dijit_30__0.0%3Ahead_css&amp;entry=wp_legacy_layouts__0.0%3Ahead_css&amp;entry=wp_theme_portal_80__0.0%3Ahead_css&amp;entry=wp_status_bar__0.0%3Ahead_css&amp;entry=wp_portlet_css__0.0%3Ahead_css"
    type="text/css">
<script type="text/javascript"
    src="https://www.bancodebogota.com/wps/contenthandler/banco-de-bogota/!ut/p/digest!wYZk2bGPQvPvvG0ssU4wJg/mashup/ra:collection?themeID=ZJ_609I03O0J06TD0AM9I1D751G53&amp;locale=es&amp;locale=en&amp;mime-type=text%2Fplain&amp;entry=wp_client_main__0.0%3Ahead_js&amp;entry=wp_client_ext__0.0%3Ahead_js&amp;entry=wp_theme_portal_80__0.0%3Ahead_js"></script><!--[if IE 7]>

    <!-- Facebook -->
<meta name="facebook-domain-verification" content="z3u0zh0vs5n4111v3kjxo6hgtlvv62">
<!-- Facebook -->


<!--ICON-->
<link rel="shortcut icon" type="/images/favicon.ico">
<link rel="shortcut icon" type="/images/favicon.png">

<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css"
    integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">

<link rel="canonical"
    href="https://www.bancodebogota.comhttps://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota">
<meta name="description"
    content="Encuentra información sobre los productos y servicios de Banco de Bogotá. También puedes hacer transacciones y consultas en línea desde nuestro portal web.">
<meta name="keywords" content="">
<link rel="stylesheet" title=""
    href="${my_banco}css/estilos-chat.css"
    type="text/css">
<script type="text/javascript" 
    src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/61251eca-7500-4294-854b-1b55f8cc52ec/popup.js?MOD=AJPERES"
    name="popup"></script>

<link rel="stylesheet" title=""
    href="${my_banco}css/websphere.css" type="text/css">
<!-- whatsapp Widget -->
<link rel="stylesheet" type="text/css"
    href="${my_banco}css/whatsapp.css">
<!--Css/Js-->
<link rel="stylesheet" title=""
    href="${my_banco}css/style-10.css" type="text/css">
<link rel="stylesheet" title=""
    href="${my_banco}css/style-menu-10.css"
    type="text/css">
<link rel="stylesheet" title=""
    href="${my_banco}css/main.css" type="text/css">

<link rel="stylesheet" title=""
    href="${my_banco}css/App-Css-10.css" type="text/css">

<link rel="stylesheet" title=""
    href="${my_banco}css/owl.carousel.min.css"
    type="text/css">

<link rel="stylesheet" title=""
    href="${my_banco}css/pop-up.css" type="text/css">

<!--estilos izymodal-->
<link rel="stylesheet" title=""
    href="${my_banco}css/iziModal.min.css"
    type="text/css">

<!-- <script type="text/javascript"
    src="${my_banco}js/owl.carousel.js"></script> -->


    <!-- Loader -->
<div id="loading_modal"></div> 

    <div class="wpthemeMainContent" role="main">
        <div class="wpthemeInner">
            <div class="wpthemeClear"></div>
            <div style="display:none" id="portletState">{}</div>
            <table class="layoutRow" cellpadding="0" cellspacing="0" role="presentation">
                <tbody>
                    <tr>
                        <td valign="top">
                            <table class="layoutColumn" cellpadding="0" cellspacing="0" role="presentation">

                                <tbody>
                                    <tr>
                                        <td style="width:100%;" valign="top">

                                            <table class="layoutRow" cellpadding="0" cellspacing="0"
                                                role="presentation">
                                                <tbody>
                                                    <tr>
                                                        <td valign="top">
                                                            <div
                                                                class="component-control id-Z7_609I03O0J06TD0AM9I1D751O50">
                                                                <span id="Z7_609I03O0J06TD0AM9I1D751O50"></span>
                                                                <section
                                                                    class="ibmPortalControl wpthemeNoSkin a11yRegionTarget"
                                                                    role="region">
                                                                    <!-- marks the node the analytics tags for this portlet will be placed in -->
                                                                    <!-- asa.overlay marks the node that the AsaOverlayWidget will be placed in -->
                                                                    <div style="position:relative; z-index: 1;">
                                                                        <div class="analytics.overlay"></div>
                                                                    </div>
                                                                    <!-- Hide the text of the title, but still provide the lm-dynamic-title container for accessing the dynamic title -->
                                                                    <span class="wpthemeAccess">
                                                                        <span
                                                                            class="lm-dynamic-title asa.portlet.title a11yRegionLabel"><span
                                                                                lang="es" dir="ltr">Header</span></span>
                                                                    </span>
                                                                    <div class="wpthemeOverflowAuto">
                                                                        <!-- lm:control dynamic spot injects markup of layout control -->




                                                                        <!-- <script type="text/javascript"
                                                                            src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/d5171bc6-0ff5-497e-afc7-acf72d3cce58/jquery.min.js?MOD=AJPERES"></script> -->
                                                                        <!-- <script type="text/javascript"
                                                                            src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/a1089183-f877-4035-8a19-481a5c9d2c84/modernizr.custom.js?MOD=AJPERES"></script> -->
                                                                        <!-- <script type="text/javascript"
                                                                            src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/c590b6c8-2d5b-4ef3-884c-4ad6c46c73c3/jquery.dlmenu.js?MOD=AJPERES"></script> -->
                                                                        <!-- <script type="text/javascript">
                                                                            $(function() {
                                                                                $('#dl-menu').dlmenu();
                                                                            });
                                                                        </script> -->



                                                                        <script>
                                                                            function muestra_oculta(id) {
                                                                                if (document.getElementById) {
                                                                                    var el = document.getElementById(id);
                                                                                    el.style.display = (el.style.display == 'block') ? 'none' : 'block';
                                                                                }
                                                                            }
                                                                            window.onload = function() {
                                                                                muestra_oculta('mostrar');
                                                                            }

                                                                            $(document).ready(function() {
                                                                                function ocultalo(ide) {
                                                                                    var DivS = document.getElementById(ide);
                                                                                    DivS.style.display = 'none';
                                                                                }
                                                                                var isMobile = {
                                                                                    Android: function() {
                                                                                        return navigator.userAgent.match(/Android/i);
                                                                                    },
                                                                                    BlackBerry: function() {
                                                                                        return navigator.userAgent.match(/BlackBerry/i);
                                                                                    },
                                                                                    iOS: function() {
                                                                                        return navigator.userAgent.match(/iPhone|iPad|iPod/i);
                                                                                    },
                                                                                };

                                                                                if (isMobile.iOS()) {
                                                                                    ocultalo('android');
                                                                                    ocultalo('blackberry');
                                                                                } else if (isMobile.BlackBerry()) {
                                                                                    ocultalo('apple');
                                                                                    ocultalo('android');
                                                                                } else {
                                                                                    ocultalo('blackberry');
                                                                                    ocultalo('apple');
                                                                                }
                                                                            });
                                                                        </script>

                                                                        <div class="aplicacion"> <a
                                                                                onclick="muestra_oculta('mostrar');this.style.display='none';"
                                                                                class="cerrar"> X </a>
                                                                            <div class="app" id="mostrar"
                                                                                style="display: block;">
                                                                                <div class="app-logo"> <img
                                                                                        src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/77edcd99-61da-4b31-87a9-5ad19c65f030/logo-bogogota-app.png?MOD=AJPERES&amp;CACHEID=77edcd99-61da-4b31-87a9-5ad19c65f030"
                                                                                        alt="Logo App Banco de Bogotá">
                                                                                </div>
                                                                                <div class="app-cont">
                                                                                    <!--<h5>Banco de Bogotá </h5>-->
                                                                                    <p>Aplicación Banca Móvil. </p>
                                                                                    <div style="display: none;"
                                                                                        id="apple"><a
                                                                                            href="https://itunes.apple.com/us/app/banco-de-bogota/id741196012?l=es&amp;ls=1&amp;mt=8"
                                                                                            target="_blank"> Descárgala
                                                                                            <span
                                                                                                class="i-arrowyellow-right"></span></a>
                                                                                    </div>
                                                                                    <div style="display:block"
                                                                                        id="android"><a
                                                                                            href="https://play.google.com/store/apps/details?id=com.bancodebogota.bancamovil&amp;hl=es-419"
                                                                                            target="_blank">Descárgala
                                                                                            <span
                                                                                                class="i-arrowyellow-right"></span></a>
                                                                                    </div>
                                                                                    <div style="display: none;"
                                                                                        id="blackberry"><a
                                                                                            href="http://appworld.blackberry.com/webstore/content/39734906/?lang=en&amp;countrycode=CO"
                                                                                            target="_blank">Descárgala
                                                                                            <span
                                                                                                class="i-arrowyellow-right"></span></a>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>
                                                                        <!---->

                                                                        <header>




                                                                            <!--Logo-->
                                                                            <div class="logo-home"><a
                                                                                    href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota"
                                                                                    title="Logo Banco de Bogotá"
                                                                                    target="_self"><img
                                                                                        src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/185fc6ee-7266-42e9-8d7a-561c8ca8e8b0/logo-bogota-azul.png?MOD=AJPERES&amp;CACHEID=185fc6ee-7266-42e9-8d7a-561c8ca8e8b0"
                                                                                        alt="Logo Banco de Bogotá"
                                                                                        width="314" height="46"></a>
                                                                            </div>
                                                                            <div class="logo-home-movil"><a
                                                                                    href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota"
                                                                                    title="Logo Banco de Bogotá"
                                                                                    target="_self"><img
                                                                                        src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/03295ca3-ff13-475c-87a3-88b3bebfd661/logo-bogota-mobile.jpg?MOD=AJPERES&amp;CACHEID=03295ca3-ff13-475c-87a3-88b3bebfd661"
                                                                                        alt="Logo Banco de Bogotá"
                                                                                        width="262" height="33"></a>
                                                                            </div>
                                                                            <div class="cont-busqueda-movil"><a href="#"
                                                                                    title="Icono Busqueda"
                                                                                    target="_self"><img
                                                                                        src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/c36b3c80-99af-412b-a027-97e39629cd79/icono-busqueda-movil.png?MOD=AJPERES&amp;CACHEID=c36b3c80-99af-412b-a027-97e39629cd79"
                                                                                        alt="Icono Busqueda" width="18"
                                                                                        height="22"></a></div>
                                                                            <!--Menu-->
                                                                            <div id="dl-menu" class="dl-menuwrapper">
                                                                                <div class="dl-trigger"></div>
                                                                                <ul class="dl-menu" id="submenu-prod">
                                                                                    <li> <a target="" title="" href="#"
                                                                                            class="titles">PRODUCTOS<div
                                                                                                class="arrow-down">
                                                                                            </div></a>
                                                                                        <ul class="dl-submenu">
                                                                                            <div class="dl-back"><img
                                                                                                    src="/wps/wcm/connect/banco-de-bogota/cffa0d0e-9259-4cd9-91da-3a25c14a709c/icon-back.png?MOD=AJPERES">
                                                                                            </div>
                                                                                            <div class="menu-prod-der">
                                                                                                <li
                                                                                                    class="subtitulo-menu">
                                                                                                    Para Ti</li>
                                                                                                <li> <a target=""
                                                                                                        title="Cuenta Corriente"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/cuenta-corriente"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'CuentaCorriente'});">Cuenta
                                                                                                        Corriente <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a target=""
                                                                                                        title="Cuentas de Ahorro"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/cuenta-de-ahorros"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'CuentasAhorros'});">Cuentas
                                                                                                        de Ahorro <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a target=""
                                                                                                        title="Remesas Familiares"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/cuenta-de-ahorros/remesas-internacionales"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'RemesasFamiliares'});">Remesas
                                                                                                        Familiares <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a target=""
                                                                                                        title="Tarjetas Débito"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/tarjetas-debito"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'TarjetasDebito'});">Tarjetas
                                                                                                        Débito <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a target=""
                                                                                                        title="CDT e Inversión"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/cdt-e-inversion"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'CDTeInversion'});">
                                                                                                        CDT e Inversión
                                                                                                        <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a target=""
                                                                                                        title="Tarjetas de Crédito "
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/tarjetas-de-credito"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'TarjetasCredito'});">Tarjetas
                                                                                                        de Crédito <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a href="https://www.portafoliovivienda.com/public/"
                                                                                                        title="Portafolio de Vivienda"
                                                                                                        target="_blank"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'Portafoliovivienda'});">
                                                                                                        Portafolio de
                                                                                                        Vivienda <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a target=""
                                                                                                        title="Créditos"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/creditos-y-financiacion"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'Creditos'});">Créditos
                                                                                                        <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a target=""
                                                                                                        title="Soluciones de Leasing"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/creditos-y-financiacion/leasing/todos-los-productos-leasing"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'Leasing'});">Soluciones
                                                                                                        de Leasing <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a target=""
                                                                                                        title="Seguros"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/seguros"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'Seguros'});">Seguros
                                                                                                        <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a target=""
                                                                                                        title="Tasas y Tarifas "
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/tasas-y-tarifas"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'TasasTarifasPersonas'});">Tasas
                                                                                                        y Tarifas <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a target=""
                                                                                                        title="Bienes e Inmuebles"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/bienes-e-inmuebles-catalogo"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'BienesInmuebles'});">Bienes
                                                                                                        e Inmuebles en
                                                                                                        Venta <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <div
                                                                                                    class="cont-cliente-menu">
                                                                                                    <span
                                                                                                        class="subtitulo-cliente">Busca
                                                                                                        una
                                                                                                        Oficina.</span>
                                                                                                    <span
                                                                                                        class="txt-prod"><a
                                                                                                            href="https://www.bancodebogota.com/BuscadordePuntosBogota"
                                                                                                            target="_blank"
                                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'BuscaOficina'});">Encuentra
                                                                                                            la más
                                                                                                            cercana a
                                                                                                            ti<i
                                                                                                                class="i-arroworange-right"></i></a></span>
                                                                                                    <span
                                                                                                        class="txt-prod"><a
                                                                                                            href="https://www.bancodebogota.comhttps://www.bancodebogota.com/wps/themes/html/banco-de-bogota/landings/infografia-canales/index.html"
                                                                                                            target="_blank"
                                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'InfografiaCanales'});">Conoce
                                                                                                            como buscar
                                                                                                            tus
                                                                                                            Canales<i
                                                                                                                class="i-arroworange-right"></i></a></span>
                                                                                                </div>
                                                                                            </div>
                                                                                            <div class="menu-prod-izq">
                                                                                                <li
                                                                                                    class="subtitulo-menu">
                                                                                                    Para Empresas</li>
                                                                                                <li> <a id="soluciones-financiacion"
                                                                                                        target=""
                                                                                                        title="Soluciones de Financiación"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-empresas/soluciones-de-financiacion"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'SolucionesFinanciacion'});">Soluciones
                                                                                                        de Financiación
                                                                                                        <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a id="soluciones-recaudo-pagos"
                                                                                                        target=""
                                                                                                        title="Soluciones de Recaudo y Pagos"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-empresas/soluciones-de-recaudo-y-pagos"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'SolucionesRecaudoPagos'});">Soluciones
                                                                                                        de Recaudo y
                                                                                                        Pagos <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a id="soluciones-inversion-liquidez"
                                                                                                        target=""
                                                                                                        title="Soluciones de Inversión y Liquidez"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-empresas/soluciones-de-inversion-y-liquidez"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'SolucionesInversionLiquidez'});">Soluciones
                                                                                                        de Inversión y
                                                                                                        Liquidez <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a id="soluciones-comercio-internacional-tesoreria"
                                                                                                        target=""
                                                                                                        title="Soluciones de Comercio Internacional y Tesorería "
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-empresas/soluciones-de-comercio-internacional-y-tesoreria"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'SolucionesComercioInternacional'});">Soluciones
                                                                                                        de Comercio
                                                                                                        Internacional y
                                                                                                        Tesorería <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a id="soluciones-informacion"
                                                                                                        target=""
                                                                                                        title="Soluciones de Información "
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-empresas/soluciones-de-informacion"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'SolucionesInformacion'});">Soluciones
                                                                                                        de Información
                                                                                                        <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a id="soluciones-fiduciarias"
                                                                                                        target=""
                                                                                                        title="Soluciones Fiduciarias"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-empresas/soluciones-fiduciarias"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'SolucionesFiduciarias'});">Soluciones
                                                                                                        Fiduciarias <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a id="soluciones-leasing"
                                                                                                        target=""
                                                                                                        title="Soluciones de Leasing "
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-empresas/soluciones-de-leasing"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'SolucionesLeasing'});">Soluciones
                                                                                                        de Leasing <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a id="soluciones-logistica"
                                                                                                        target=""
                                                                                                        title="Soluciones de Logística"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-empresas/soluciones-de-logistica"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'SolucionesLogistica'});">Soluciones
                                                                                                        de Logística <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a id="soluciones-credito-constructor"
                                                                                                        target=""
                                                                                                        title="Soluciones de Crédito Constructor"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-empresas/soluciones-de-credito-constructor"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'SolucionesCreditoConstructor'});">Soluciones
                                                                                                        de Crédito
                                                                                                        Constructor <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a id="soluciones-financiacion-estructurada"
                                                                                                        target=""
                                                                                                        title="Soluciones de Financiación Estructurada"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-empresas/soluciones-financiacion-estructurada"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'SolucionesFinanciacionEstructurada'});">Soluciones
                                                                                                        de Financiación
                                                                                                        Estructurada <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li> <a id="soluciones-tasas-tarifas"
                                                                                                        target=""
                                                                                                        title="Tasas y Tarifas "
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/tasas-y-tarifas"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicProductos','eventLabel': 'TasasTarifasEmpresas'});">Tasas
                                                                                                        y Tarifas <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                            </div>
                                                                                        </ul>
                                                                                    </li>
                                                                                    <li> <a target="" title="" href="#"
                                                                                            class="titles">BANCAS<div
                                                                                                class="arrow-down">
                                                                                            </div></a>
                                                                                        <ul class="dl-submenu"
                                                                                            id="submenu-banca">
                                                                                            <div class="dl-back"><img
                                                                                                    src="/wps/wcm/connect/banco-de-bogota/cffa0d0e-9259-4cd9-91da-3a25c14a709c/icon-back.png?MOD=AJPERES">
                                                                                            </div>
                                                                                            <div class="menu-banca-der">
                                                                                                <li
                                                                                                    class="subtitulo-menu">
                                                                                                    Para Ti</li>
                                                                                                <li><a id="banca-personas"
                                                                                                        target=""
                                                                                                        title="Banca Personas"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-ti/banca-personas"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaPersonas'});">Banca
                                                                                                        Personas <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li><a id="banca-infantil"
                                                                                                        target=""
                                                                                                        title="Banca Infantil"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-ti/banca-infantil"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaInfantil'});">Banca
                                                                                                        Infantil <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li><a id="banca-joven"
                                                                                                        target=""
                                                                                                        title="Banca Joven"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-ti/banca-joven"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaJoven'});">Banca
                                                                                                        Joven <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li><a id="banca-experiencia"
                                                                                                        target=""
                                                                                                        title="Banca Experiencia"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-ti/banca-experiencia"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaExperiencia'});">Banca
                                                                                                        Experiencia <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li><a id="banca-preferente"
                                                                                                        target=""
                                                                                                        title="Banca Preferente"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-ti/banca-preferente"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaPreferente'});">Banca
                                                                                                        Preferente <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li><a id="banca-premium"
                                                                                                        target=""
                                                                                                        title="Banca Premium"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-ti/banca-premium"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaPremium'});">Banca
                                                                                                        Premium <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li><a id="banca-microempresas"
                                                                                                        target=""
                                                                                                        title="Banca Microempresas"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-ti/banca-microempresas"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaMicroEmpresas'});">Banca
                                                                                                        Microempresas <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li><a id="banca-microfinanzas"
                                                                                                        target=""
                                                                                                        title="Banca Microfinanzas"
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-ti/banca-microfinanzas"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaMicrofinanzas'});">Banca
                                                                                                        Microfinanzas <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                            </div>
                                                                                            <div class="menu-banca-izq">
                                                                                                <li
                                                                                                    class="subtitulo-menu">
                                                                                                    Para Empresas</li>

                                                                                                <li><a target=""
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-empresas/banca-pyme"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaPyme'});">Banca
                                                                                                        Pyme <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li><a target=""
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-empresas/banca-empresarial"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaMedianaEmpresarial'});">Banca
                                                                                                        Mediana Empresa,
                                                                                                        Empresarial y
                                                                                                        Corporativa <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <!--<li><a target="" href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-empresas/banca-corporativa" onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaCorporativa'});">Banca Corporativa <i class="i-arroworange-right"></i></a></li>-->
                                                                                                <li><a target=""
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-empresas/banca-institucional"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaInstitucional'});">Banca
                                                                                                        Institucional <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li><a target=""
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-empresas/banca-oficial"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaOficial'});">Banca
                                                                                                        Oficial <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li><a target=""
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-empresas/banca-social"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaSocial'});">Banca
                                                                                                        Social <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                                <li><a title=""
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/bancas/para-empresas/banca-internacional"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'BancaInternacional'});"
                                                                                                        target="_blank">Banca
                                                                                                        Internacional <i
                                                                                                            class="i-arroworange-right"></i></a>
                                                                                                </li>
                                                                                            </div>
                                                                                            <div
                                                                                                class="cont-banca-menu">
                                                                                                <span
                                                                                                    class="subtitulo-cliente">¿Necesita
                                                                                                    Ayuda?</span>
                                                                                                <span
                                                                                                    class="txt-prod"><a
                                                                                                        id="banca-necesita-ayuda"
                                                                                                        target=""
                                                                                                        title=""
                                                                                                        href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/atencion-al-cliente/necesita-ayuda"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicBancas','eventLabel': 'NecesitaAyuda'});">Ver
                                                                                                        más <i
                                                                                                            class="i-arroworange-right"></i></a></span>
                                                                                            </div>


                                                                                        </ul>
                                                                                    </li>
                                                                                    <li> <a target="" title="" href="#"
                                                                                            class="titles">ATENCIÓN AL
                                                                                            CLIENTE<div
                                                                                                class="arrow-down">
                                                                                            </div></a>
                                                                                        <ul class="dl-submenu"
                                                                                            id="submenu-atencion">
                                                                                            <div class="dl-back"><img
                                                                                                    src="/wps/wcm/connect/banco-de-bogota/cffa0d0e-9259-4cd9-91da-3a25c14a709c/icon-back.png?MOD=AJPERES">
                                                                                            </div>
                                                                                            <li><a href="https://turnodigital.bancodebogota.com.co/"
                                                                                                    title="Turno Digital"
                                                                                                    target="_blank"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicAtencionAlCliente','eventLabel': 'TurnoDigital'});">Turno
                                                                                                    Digital <i
                                                                                                        class="i-arrowblue-right"></i></a>
                                                                                            </li>
                                                                                            <li><a target=""
                                                                                                    title="¿Necesitas Ayuda?"
                                                                                                    href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/atencion-al-cliente/necesita-ayuda"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicAtencionAlCliente','eventLabel': 'NecesitaAyuda'});">¿Necesitas
                                                                                                    Ayuda? <i
                                                                                                        class="i-arrowblue-right"></i></a>
                                                                                            </li>
                                                                                            <li><a target=""
                                                                                                    title="Puntos de Atención"
                                                                                                    href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/atencion-al-cliente/puntos-de-atencion"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicAtencionAlCliente','eventLabel': 'PuntosDeAtencion'});">Puntos
                                                                                                    de Atención <i
                                                                                                        class="i-arrowblue-right"></i></a>
                                                                                            </li>
                                                                                            <li><a id="nuestros-canales"
                                                                                                    target=""
                                                                                                    title="Nuestros Canales"
                                                                                                    href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/atencion-al-cliente/canales-electronicos"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicAtencionAlCliente','eventLabel': 'NuestrosCanales'});">Nuestros
                                                                                                    Canales <i
                                                                                                        class="i-arrowblue-right"></i></a>
                                                                                            </li>
                                                                                            <li><a id="seguridad-bancaria"
                                                                                                    target=""
                                                                                                    title="Seguridad Bancaria"
                                                                                                    href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/atencion-al-cliente/seguridad-bancaria"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicAtencionAlCliente','eventLabel': 'SeguridadBancaria'});">Seguridad
                                                                                                    Bancaria <i
                                                                                                        class="i-arrowblue-right"></i></a>
                                                                                            </li>
                                                                                            <li><a id="proteccion-consumidor"
                                                                                                    target=""
                                                                                                    title="Protección al Consumidor"
                                                                                                    href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/atencion-al-cliente/proteccion-al-consumidor"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicAtencionAlCliente','eventLabel': 'ProteccionAlConsumidor'});">Protección
                                                                                                    al Consumidor <i
                                                                                                        class="i-arrowblue-right"></i></a>
                                                                                            </li>
                                                                                            <li><a id="defensor-consumidor-financiero"
                                                                                                    target=""
                                                                                                    title="Defensor del Consumidor Financiero"
                                                                                                    href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/atencion-al-cliente/proteccion-al-consumidor/defensor-del-consumidor"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicAtencionAlCliente','eventLabel': 'DefensorDelConsumidor'});">Defensor
                                                                                                    del Consumidor
                                                                                                    Financiero <i
                                                                                                        class="i-arrowblue-right"></i></a>
                                                                                            </li>
                                                                                            <li><a id="paga-tus-impuestos"
                                                                                                    title="Paga tus Impuestos"
                                                                                                    href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/atencion-al-cliente/impuestos"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicAtencionAlCliente','eventLabel': 'PagaTusImpuestos'});">Paga
                                                                                                    tus Impuestos <i
                                                                                                        class="i-arrowblue-right"></i></a>
                                                                                            </li>
                                                                                            <li><a id="disponibilidad-en-canales"
                                                                                                    target=""
                                                                                                    title="Disponibilidad en Canales"
                                                                                                    href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/atencion-al-cliente/disponibilidad-de-canales"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicAtencionAlCliente','eventLabel': 'DisponibilidadEnCanales'});">Disponibilidad
                                                                                                    en Canales <i
                                                                                                        class="i-arrowblue-right"></i></a>
                                                                                            </li>
                                                                                            <li><a id="te-escuchamos"
                                                                                                    target="_blank"
                                                                                                    title="Te escuchamos"
                                                                                                    href="https://www.bancodebogota.com/wps/themes/html/banco-de-bogota/landings/te-escuchamos/index.html"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Header','eventAction': 'ClicAtencionAlCliente','eventLabel': 'TeEscuchamos'});">Te
                                                                                                    escuchamos <i
                                                                                                        class="i-arrowblue-right"></i></a>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </li>
                                                                                    <li id="menu-busqueda"><a target=""
                                                                                            title="Icono busqueda"
                                                                                            href="#">BÚSQUEDA
                                                                                            <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/4acf8408-5cd6-4dd8-981b-17b01afcd134/icono-busqueda.png?MOD=AJPERES&amp;CACHEID=4acf8408-5cd6-4dd8-981b-17b01afcd134"
                                                                                                alt="Icono busqueda"></a>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                        </header>




















                                                                    </div>
                                                                </section>
                                                            </div>
                                                        </td>



                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="width:100%;" valign="top">







                                            <table class="layoutRow" cellpadding="0" cellspacing="0"
                                                role="presentation">
                                                <tbody>
                                                    <tr>




                                                        <td valign="top">
                                                            <div
                                                                class="component-control id-Z7_609I03O0J06TD0AM9I1D751O57">
                                                                <span id="Z7_609I03O0J06TD0AM9I1D751O57"></span>
                                                                <section
                                                                    class="ibmPortalControl wpthemeNoSkin a11yRegionTarget"
                                                                    role="region">
                                                                    <!-- marks the node the analytics tags for this portlet will be placed in -->
                                                                    <!-- asa.overlay marks the node that the AsaOverlayWidget will be placed in -->
                                                                    <div style="position:relative; z-index: 1;">
                                                                        <div class="analytics.overlay"></div>
                                                                    </div>
                                                                    <!-- Hide the text of the title, but still provide the lm-dynamic-title container for accessing the dynamic title -->
                                                                    <span class="wpthemeAccess">
                                                                        <span
                                                                            class="lm-dynamic-title asa.portlet.title a11yRegionLabel">Estilos
                                                                            Fidubogota desarrollo</span>
                                                                    </span>
                                                                    <div class="wpthemeOverflowAuto">
                                                                        <!-- lm:control dynamic spot injects markup of layout control -->
<!-- 
                                                                        <script type="text/javascript">
                                                                            function relocate() {
                                                                                $('#iframe').attr('src', "");
                                                                                $('#iframe').attr('src', 'https://virtual.bancodebogota.co/#/loginweb');
                                                                            }
                                                                            $(document).ready(function() {
                                                                                relocate();
                                                                            });
                                                                        </script> -->



                                                                        <div class="grancont-login-personas"
                                                                            id="formulario">


                                                                            <div class="cont-personas">
                                                                                <div class="cont-btn-transaccione">
                                                                                    <div class="btn-personas"><a
                                                                                            target=""
                                                                                            title="Banca Personas"
                                                                                            href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/personas/"
                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'BtnPersonas'});">Banca
                                                                                            Personas</a></div>
                                                                                    <div class="btn-empresas"><a
                                                                                            target=""
                                                                                            title="Banca Empresas"
                                                                                            href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/empresas/"
                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'BtnEmpresas'});">Banca
                                                                                            Empresas</a></div>

                                                                                    <!--<div class="cont-bancavirtual">
<h5>¿Quieres probar el nuevo portal del Banco?</h5>
<div class="btn-bancavirtual-home"> <a href="https://virtual.bancodebogota.co/?utm_source=bancodebogota.com&amp;utm_medium=boton&amp;utm_campaign=migracion_bv&amp;utm_content=btn-lateral#/login" title="&iquest;Quieres probar el nuevo portal del Banco?" target="_blank"  id="btn-probar-nuevoportal-bancavirtual"> Ingresa aquí </a></div>
</div>-->


                                                                                </div>
                                                                                <h1>Productos Bancarios</h1>
                                                                                <p id="mensaje-descripcion">Ingresa con
                                                                                    tus datos a Banca Virtual, aquí
                                                                                    puedes realizar tus pagos por
                                                                                    internet y conocer los movimientos
                                                                                    de tus productos bancarios
                                                                                    <!--<br><br><br><br>
<a href="https://www.bancodebogota.com/Banking/pb/logon?a=00010016&amp;pbold=true" target="_blank"  style="color: white; font-weight: bold; padding: 10px 15px; text-align: center; background-color: #002C76;margin: 0 auto; display: block; border-radius: 50px; text-decoration: none;">Ingresa a Banca Virtual aquí</a>
<br><br><br><br>-->
                                                                                </p>

                                                                                <div class="logini" id="bogota_body">
                                                                                    <!-- Ruta producción -->



                                                                                    <!-- Pruebas stagin QA -->
                                                                                    <!--<iframe  id="iframe" src="https://virtual-staging.bancodebogota.co/?#/login" frameborder="0" allowfullscreen min-height="600px"></iframe>-->

                                                                                    <!-- imagen contingencia -->
                                                                                    <!--<div class="" style="float: left; margin-left: -40px">
  <a href="https://www.bancodebogota.com/Banking/pb/logon?a=00010016&amp;pbold=true" target="_blank"  id="btn-ingresa-seguro"><img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/23181d84-e13d-496c-b486-d7207d30510c/fuera-de-servicio.jpg?MOD=AJPERES&amp;CACHEID=23181d84-e13d-496c-b486-d7207d30510c" alt=""/></a>
</div>-->

                                                                                    <!--<div class="" style="float: left; margin-left: -40px">
  <a href="https://www.bancodebogota.com/Banking/pb/logon?a=00010016" target="_blank" ><img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/4783ae33-cdfc-47a4-8791-48333cd9ca98/img-login-2.jpg?MOD=AJPERES&amp;CACHEID=4783ae33-cdfc-47a4-8791-48333cd9ca98" alt=""/></a>
</div>-->
                                                                                </div>
                                                                                <div class="loginToggle">
                                                                                    <a class="mostrar"
                                                                                        title="AvalPay Center"
                                                                                        id="btn-avalpay-center"><img
                                                                                            src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/a7f45770-9c00-4a05-b20d-5b1065f5563a/aval-pay.jpg?MOD=AJPERES&amp;CACHEID=a7f45770-9c00-4a05-b20d-5b1065f5563a"
                                                                                            alt="Logo AvalPay Center">
                                                                                        <i
                                                                                            class="i-arrowblue-down"></i></a>

                                                                                    <ul class="loginAcordeon">
                                                                                        <li><a href="https://www.avalpaycenter.com/wps/portal/portal-de-pagos/web/banco-bogota/"
                                                                                                target="_blank"
                                                                                                id="btn-avalpay-pagos-convenios"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-avalpay-pagos-convenios'});">Pagos
                                                                                                a Convenios</a></li>
                                                                                        <li><a href="https://www.avalpaycenter.com/wps/portal/portal-de-pagos/web/banco-bogota/resultado-busqueda/pago-obligaciones-financieras?idConv=O0105&amp;origen=buscar"
                                                                                                target="_blank"
                                                                                                id="btn-avalpay-tc-visa"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-avalpay-tc-visa'});">Banco
                                                                                                de Bogotá Tarjeta de
                                                                                                Crédito Visa</a></li>
                                                                                        <li><a href="https://www.avalpaycenter.com/wps/portal/portal-de-pagos/web/banco-bogota/resultado-busqueda/pago-obligaciones-financieras?idConv=O0104&amp;origen=buscar"
                                                                                                target="_blank"
                                                                                                id="btn-avalpay-tc-master"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-avalpay-tc-master'});">Banco
                                                                                                de Bogotá Tarjeta de
                                                                                                Crédito MasterCard</a>
                                                                                        </li>
                                                                                        <li><a href="https://www.avalpaycenter.com/wps/portal/portal-de-pagos/web/banco-bogota/resultado-busqueda/pago-obligaciones-financieras?idConv=O0101&amp;origen=buscar"
                                                                                                target="_blank"
                                                                                                id="btn-avalpay-crediservice"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-avalpay-crediservice'});">Banco
                                                                                                de Bogotá
                                                                                                Crediservice</a></li>
                                                                                        <li><a href="https://www.avalpaycenter.com/wps/portal/portal-de-pagos/web/banco-bogota/resultado-busqueda/pago-obligaciones-financieras?idConv=O0102&amp;origen=buscar"
                                                                                                target="_blank"
                                                                                                id="btn-avalpay-credito-hipotecario"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-avalpay-credito-hipotecario'});">Banco
                                                                                                de Bogotá Crédito
                                                                                                Hipotecario</a></li>
                                                                                        <li><a href="https://www.avalpaycenter.com/wps/portal/portal-de-pagos/web/banco-bogota/resultado-busqueda/pago-obligaciones-financieras?idConv=O0103&amp;origen=buscar"
                                                                                                target="_blank"
                                                                                                id="btn-avalpay-otros-creditos"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-avalpay-otros-creditos'});">Banco
                                                                                                de Bogotá Otros
                                                                                                Créditos</a></li>
                                                                                    </ul>

                                                                                </div>

                                                                                <div class="pagos">
                                                                                    <ul>
                                                                                        <li><img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/c7ba5a7a-1fb4-4604-83ad-843ec754d03f/logo-pay.png?MOD=AJPERES&amp;CACHEID=c7ba5a7a-1fb4-4604-83ad-843ec754d03f"
                                                                                                alt="Icono Facilpass"><a
                                                                                                href="https://usuariopaymas.bancodebogota.com/bdb/sign-in"
                                                                                                title="Pay+Personas"
                                                                                                target="_blank"
                                                                                                id="btn-pay-personas"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-pay-personas'});"><i
                                                                                                    class="i-arrowbluepagos-right"></i></a>
                                                                                        </li>

                                                                                        <li><img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/2e60d2e9-86da-4508-8caf-a27f733b4e8f/facil-pass.jpg?MOD=AJPERES&amp;CACHEID=2e60d2e9-86da-4508-8caf-a27f733b4e8f"
                                                                                                alt="Icono Facilpass"><a
                                                                                                href="http://www.facilpass.com/pagfacilpass/"
                                                                                                title="FacilPass"
                                                                                                target="_blank"
                                                                                                id="btn-facilpass"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-facilpass'});"><i
                                                                                                    class="i-arrowbluepagos-right"></i></a>
                                                                                        </li>

                                                                                        <li><a href="https://portal.psepagos.com.co/web/banco-de-bogota/buscador"
                                                                                                title="Portal de Pagos Electrónicos"
                                                                                                target="_blank"
                                                                                                id="btn-portal-pagos-electronicos"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-portal-pagos-electronicos'});">Portal
                                                                                                de Pagos Electrónicos <i
                                                                                                    class="i-arrowbluepagos-right"></i></a>
                                                                                        </li>

                                                                                        <li><a href="https://www.sgg.bancodebogota.com/canalcafetero"
                                                                                                title="Canal Cafetero"
                                                                                                target="_blank"
                                                                                                id="btn-canal-cafetero"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-canalcafetero'});">Canal
                                                                                                Cafetero <i
                                                                                                    class="i-arrowbluepagos-right"></i></a>
                                                                                        </li>

                                                                                        <li><a href="https://www.nuevosoi.com.co/"
                                                                                                title="Pago Seguridad Social"
                                                                                                target="_blank"
                                                                                                id="btn-pago-segridad-social"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-pago-seguridad-social'});">Pago
                                                                                                Seguridad Social <i
                                                                                                    class="i-arrowbluepagos-right"></i></a>
                                                                                        </li>

                                                                                        <li><a id="btn-apertura-productos"
                                                                                                target="_blank"
                                                                                                title="Formato de Apertura de Productos"
                                                                                                href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/formato-apertura-productos"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-formation-apertura-productos'});">Formato
                                                                                                de Apertura de Productos
                                                                                                <i
                                                                                                    class="i-arrowbluepagos-right"></i></a>
                                                                                        </li>

                                                                                        <li><a href="https://www.bancodebogota.comhttps://www.bancodebogota.com/wps/themes/html/pop-ups/correo-seguro/correoseguro.htm"
                                                                                                target="popup"
                                                                                                id="btn-correo-seguro"
                                                                                                class="ghost-button"
                                                                                                onclick="window.open('https://www.bancodebogota.comhttps://www.bancodebogota.com/wps/themes/html/pop-ups/correo-seguro/correoseguro.htm','popup','width=390,height=200'); return false;">Correo
                                                                                                Seguro<i
                                                                                                    class="i-arrowbluepagos-right"></i></a>
                                                                                        </li>

                                                                                        <li><a href="https://factoring.bancodebogota.com.co/factoring/indexef.seam"
                                                                                                target="_blank"
                                                                                                id="btn-factoring"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'loginpersonas','eventLabel': 'btn-factoring'});">Plataforma
                                                                                                Factoring <i
                                                                                                    class="i-arrowbluepagos-right"></i></a>
                                                                                        </li>

                                                                                    </ul>
                                                                                </div>

                                                                            </div>
                                                                        </div>

                                                                        <select id="selector-target"
                                                                            name="selector-target"
                                                                            style="visible:none; display:none;"
                                                                            title="Zona Transaccional Personas">
                                                                            <option value="1">inner</option>
                                                                            <option value="2">parent</option>
                                                                        </select>

                                                                        <script type="text/javascript">
                                                                            /*
                                                                            function paso1(){
                                                                              alert(document.getElementById("idNumber").value);
                                                                            
                                                                            }
                                                                            */

                                                                            $('#iframe').bind('load', function() {
                                                                                if ($("#selector-target").val() == 2) {
                                                                                    $("footer").css({
                                                                                        display: "none"
                                                                                    });
                                                                                    $('#iframe').css({
                                                                                        position: "fixed",
                                                                                        top: "0px",
                                                                                        left: "0px",
                                                                                        bottom: "0px",
                                                                                        right: "0px",
                                                                                        width: "100%",
                                                                                        height: "100%",
                                                                                        border: "none",
                                                                                        margin: "0",
                                                                                        padding: "0",
                                                                                        overflow: "hidden",
                                                                                        "z-index": "999999"
                                                                                    });
                                                                                } else {
                                                                                    $('#iframe').removeAttr("style");
                                                                                    $('footer').removeAttr("style");
                                                                                }
                                                                            });
                                                                        </script>

<!-- 
                                                                        <script type="text/javascript">
                                                                            /* <![CDATA[ */
                                                                            $(function() {
                                                                                var input = document.createElement("input");
                                                                                if (('placeholder' in input) == false) {
                                                                                    $('[placeholder]').focus(function() {
                                                                                        var i = $(this);
                                                                                        if (i.val() == i.attr('placeholder')) {
                                                                                            i.val('').removeClass('placeholder');
                                                                                            if (i.hasClass('password')) {
                                                                                                i.removeClass('password');
                                                                                                this.type = 'password';

                                                                                            }
                                                                                        }
                                                                                    }).blur(function() {
                                                                                        var i = $(this);
                                                                                        if (i.val() == '' || i.val() == i.attr('placeholder')) {
                                                                                            if (this.type == 'password') {
                                                                                                i.addClass('password');
                                                                                                this.type = 'text';
                                                                                                this.style.cssText = "color:#b5bac3;"
                                                                                            }
                                                                                            i.addClass('placeholder').val(i.attr('placeholder'));

                                                                                        }
                                                                                    }).blur().parents('form').submit(function() {
                                                                                        $(this).find('[placeholder]').each(function() {
                                                                                            var i = $(this);
                                                                                            if (i.val() == i.attr('placeholder'))
                                                                                                i.val('');

                                                                                        })
                                                                                    });
                                                                                }
                                                                            });
                                                                            /* ]]> */
                                                                        </script> -->


                                                                        <link rel="stylesheet"
                                                                            href="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/ce92c311-bd54-4b7c-8e23-864a8e4eb694/acordeon-login.css?MOD=AJPERES">

                                                                        <script type="text/javascript">
                                                                            $(".loginToggle").click(function() {
                                                                                $(".loginAcordeon").slideToggle();
                                                                            });
                                                                        </script>
                                                                    </div>
                                                                </section>
                                                            </div>
                                                        </td>



                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="width:100%;" valign="top">







                                            <table class="layoutRow" cellpadding="0" cellspacing="0"
                                                role="presentation">
                                                <tbody>
                                                    <tr>




                                                        <td valign="top">
                                                            <div
                                                                class="component-control id-Z7_609I03O0J06TD0AM9I1D751O51">
                                                                <span id="Z7_609I03O0J06TD0AM9I1D751O51"></span>
                                                                <section
                                                                    class="ibmPortalControl wpthemeNoSkin a11yRegionTarget"
                                                                    role="region">
                                                                    <!-- marks the node the analytics tags for this portlet will be placed in -->
                                                                    <!-- asa.overlay marks the node that the AsaOverlayWidget will be placed in -->
                                                                    <div style="position:relative; z-index: 1;">
                                                                        <div class="analytics.overlay"></div>
                                                                    </div>
                                                                    <!-- Hide the text of the title, but still provide the lm-dynamic-title container for accessing the dynamic title -->
                                                                    <span class="wpthemeAccess">
                                                                        <span
                                                                            class="lm-dynamic-title asa.portlet.title a11yRegionLabel"><span
                                                                                lang="es" dir="ltr">Slider</span></span>
                                                                    </span>
                                                                    <div class="wpthemeOverflowAuto">
                                                                        <!-- lm:control dynamic spot injects markup of layout control -->


                                                                        <div class="slider-home">
                                                                            <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/58498c9b-1311-4004-8eba-07ba70b1bbdd/vigilado-superintendencia.png?MOD=AJPERES&amp;CACHEID=58498c9b-1311-4004-8eba-07ba70b1bbdd"
                                                                                alt="Vigilado Superintendencia Financiera de Colombia"
                                                                                class="vigilado">
                                                                            <div
                                                                                class="owl-carousel owl-loaded owl-drag">
                                                                                <!-- Crédito FEP -->


                                                                                <!-- FERIA AHORRO-->
                                                                                <!-- <div>
    <a href="https://contigo.bancodebogota.com.co/pub/sf/ResponseForm?_ri_=X0Gzc2X%3DAQpglLjHJlDQGuclNzewFnLmJLYjIOFzbfAlR55azbO1R2KjyDcVXMtX%3DAQpglLjHJlDQGjw9EmrvzdKH8TF83qXFW3zeh55azbO1R2KjyDc&amp;_ei_=Eis_D7MNOrLoA6IO8Rugcng&amp;_di_=icmsm19g1s52eioo4ct911lnm9aj56bm45k46udi15aa52rql420" target="_blank"  onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'FeriaAhorro'});">
    <picture>
        <source srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/3b6b21e8-eb15-42ed-a168-112b32f6acaa/banner-movil-540x805.jpg?MOD=AJPERES" media="(max-width: 524px)">
        <source srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/3f94928c-fb61-4886-939f-d388de08bfdb/banner-tablet-540x805.jpg?MOD=AJPERES" media="(max-width: 1079px)">
        <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/1962de3e-a92b-4149-af3e-36b2ca9097a3/img.png?MOD=AJPERES&amp;CACHEID=1962de3e-a92b-4149-af3e-36b2ca9097a3" alt="Pide aquí tus alivios financieros con el Banco de bogotá"  style="background-image: url('https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/584356d1-8cc0-4c21-b1d3-51a05ae9189f/banner-escritorio.PNG?MOD=AJPERES');"/>
    </picture>
    </a>
</div>-->



                                                                                <!-- TARJETA DEBITO AMAZONIA  -->


                                                                                <!-- PRODUCTOS DIGITALES-->


                                                                                <!-- DUCC Campañas Politicas -->

                                                                                <div class="owl-stage-outer">
                                                                                    <div class="owl-stage"
                                                                                        style="transform: translate3d(-5905px, 0px, 0px); transition: 0.25s; width: 9448px;">
                                                                                        <div class="owl-item cloned"
                                                                                            style="width: 1181px;">
                                                                                            <div>
                                                                                                <div class="text blue">
                                                                                                    <h3>Abre ya tus
                                                                                                        productos por
                                                                                                        Internet</h3>
                                                                                                    <p>Aprobamos y
                                                                                                        desembolsamos al
                                                                                                        instante</p>
                                                                                                    <div class="button blue"
                                                                                                        data-popup-open="productos"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'aperturaProductos'});">
                                                                                                        Ábrelos aquí
                                                                                                    </div>
                                                                                                    <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/19f956d2-66da-4aed-8787-ba3817b0dc9f/caminando-contigo-white.png?MOD=AJPERES&amp;CACHEID=19f956d2-66da-4aed-8787-ba3817b0dc9f"
                                                                                                        alt="Cambiando contigo"
                                                                                                        class="sello"
                                                                                                        style="margin-top:25px;width:200px;height:auto;">
                                                                                                </div>
                                                                                                <picture>
                                                                                                    <source
                                                                                                        srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/51238b1a-cd64-4cae-baee-1f0e3eddb30b/productos-digitales-mobile.jpg?MOD=AJPERES"
                                                                                                        media="(max-width: 524px)">
                                                                                                    <source
                                                                                                        srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/5967221d-129c-4066-8da8-6a9c896ea4b8/productos-digitales-tablet.jpg?MOD=AJPERES"
                                                                                                        media="(max-width: 1079px)">
                                                                                                    <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/1962de3e-a92b-4149-af3e-36b2ca9097a3/img.png?MOD=AJPERES&amp;CACHEID=1962de3e-a92b-4149-af3e-36b2ca9097a3"
                                                                                                        alt="Pide aquí tus alivios financieros con el Banco de bogotá"
                                                                                                        style="background-image: url('https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/87a79384-57fa-451f-b72e-578358a27d2c/productos-digitales.jpg?MOD=AJPERES');">
                                                                                                </picture>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="owl-item cloned"
                                                                                            style="width: 1181px;">
                                                                                            <div>
                                                                                                <a href="https://www.bancodebogota.comhttps://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/cuenta-corriente"
                                                                                                    title="DUCC Campañas Politicas"
                                                                                                    target="_blank"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'DUCC Campañas Politicas'});">
                                                                                                    <picture>
                                                                                                        <source
                                                                                                            srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/f521f86c-39b0-4755-9f63-e43a41c446d5/banner-cta-electoral-movil.jpg?MOD=AJPERES"
                                                                                                            media="(max-width: 524px)">
                                                                                                        <source
                                                                                                            srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/b195ae94-c258-4d29-9940-ca3cc6c1ec8e/banner-cta-electoral-tablet.jpg?MOD=AJPERES"
                                                                                                            media="(max-width: 1079px)">
                                                                                                        <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/1962de3e-a92b-4149-af3e-36b2ca9097a3/img.png?MOD=AJPERES&amp;CACHEID=1962de3e-a92b-4149-af3e-36b2ca9097a3"
                                                                                                            alt="Pide aquí tus alivios financieros con el Banco de bogotá"
                                                                                                            style="background-image: url('https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/600a6bf6-4879-4848-9006-ddbbd528055e/banner-cta-electoral-escritorio.jpg?MOD=AJPERES');">
                                                                                                    </picture>
                                                                                                </a>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="owl-item"
                                                                                            style="width: 1181px;">
                                                                                            <div>
                                                                                                <a href="https://contigo.bancodebogota.com.co/pub/sf/ResponseForm?_ri_=X0Gzc2X%3DAQpglLjHJlDQG1tgzdayJzc9Tq5zdIOkivkzaBpBaqPpbuDd3CrNVXMtX%3DAQpglLjHJlDQGf28zdyjMzeeXYksIwg0RHzefTBaqPpbuDd3CrN&amp;_ei_=EXbZquKKu0frScbn2iz5qXM&amp;_di_=vdc9qojuvaa83eqkqum3jg6ubn7ldongunt6bq6brbdpasgvett0"
                                                                                                    title="Crédito FEP"
                                                                                                    target="_blank"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'CreditoFEP'});">
                                                                                                    <picture>
                                                                                                        <source
                                                                                                            srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/79ff411b-20b2-4321-8ce3-8398f762b1ca/banner-fep-movil.jpg?MOD=AJPERES"
                                                                                                            media="(max-width: 524px)">
                                                                                                        <source
                                                                                                            srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/613bb528-9555-409d-b3f8-e6f2fd512c1a/banner-fep-tablet.jpg?MOD=AJPERES"
                                                                                                            media="(max-width: 1079px)">
                                                                                                        <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/563c3aab-cc7b-49e9-898d-b59ed3e8ee7f/banner-fep-default.png?MOD=AJPERES&amp;CACHEID=563c3aab-cc7b-49e9-898d-b59ed3e8ee7f"
                                                                                                            alt="Crédito FEP"
                                                                                                            style="background-image: url('https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/aa595e30-6616-4e71-bf18-0ca5ba9570eb/banner-fep-desktop.jpg?MOD=AJPERES');">
                                                                                                    </picture>
                                                                                                </a>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="owl-item"
                                                                                            style="width: 1181px;"><a
                                                                                                href="https://www.bancodebogota.comhttps://www.bancodebogota.com/wps/themes/html/banco-de-bogota/landings/tarjeta-debito-amazonia/index.html"
                                                                                                target="_blank"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'TarjetaDebitoAmazonia'});">
                                                                                                <picture>
                                                                                                    <source
                                                                                                        srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/cb2d691b-327e-4bb9-a840-fb9a81c66c32/banner-amazonia-movil.jpg?MOD=AJPERES"
                                                                                                        media="(max-width: 524px)">
                                                                                                    <source
                                                                                                        srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/93706d18-1dcf-4cdb-aa73-f392af4f8967/banner-amazonia-tablet.jpg?MOD=AJPERES"
                                                                                                        media="(max-width: 1079px)">
                                                                                                    <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/1962de3e-a92b-4149-af3e-36b2ca9097a3/img.png?MOD=AJPERES&amp;CACHEID=1962de3e-a92b-4149-af3e-36b2ca9097a3"
                                                                                                        alt="Nueva tarjeta de débito Amazonia"
                                                                                                        style="background-image: url('https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/8e0f01da-35eb-4edb-8dcf-a5544da3265e/banner-amazonia.jpg?MOD=AJPERES');">
                                                                                                </picture>
                                                                                            </a></div>
                                                                                        <div class="owl-item"
                                                                                            style="width: 1181px;">
                                                                                            <div>
                                                                                                <div class="text blue">
                                                                                                    <h3>Abre ya tus
                                                                                                        productos por
                                                                                                        Internet</h3>
                                                                                                    <p>Aprobamos y
                                                                                                        desembolsamos al
                                                                                                        instante</p>
                                                                                                    <div class="button blue"
                                                                                                        data-popup-open="productos"
                                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'aperturaProductos'});">
                                                                                                        Ábrelos aquí
                                                                                                    </div>
                                                                                                    <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/19f956d2-66da-4aed-8787-ba3817b0dc9f/caminando-contigo-white.png?MOD=AJPERES&amp;CACHEID=19f956d2-66da-4aed-8787-ba3817b0dc9f"
                                                                                                        alt="Cambiando contigo"
                                                                                                        class="sello"
                                                                                                        style="margin-top:25px;width:200px;height:auto;">
                                                                                                </div>
                                                                                                <picture>
                                                                                                    <source
                                                                                                        srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/51238b1a-cd64-4cae-baee-1f0e3eddb30b/productos-digitales-mobile.jpg?MOD=AJPERES"
                                                                                                        media="(max-width: 524px)">
                                                                                                    <source
                                                                                                        srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/5967221d-129c-4066-8da8-6a9c896ea4b8/productos-digitales-tablet.jpg?MOD=AJPERES"
                                                                                                        media="(max-width: 1079px)">
                                                                                                    <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/1962de3e-a92b-4149-af3e-36b2ca9097a3/img.png?MOD=AJPERES&amp;CACHEID=1962de3e-a92b-4149-af3e-36b2ca9097a3"
                                                                                                        alt="Pide aquí tus alivios financieros con el Banco de bogotá"
                                                                                                        style="background-image: url('https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/87a79384-57fa-451f-b72e-578358a27d2c/productos-digitales.jpg?MOD=AJPERES');">
                                                                                                </picture>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="owl-item active"
                                                                                            style="width: 1181px;">
                                                                                            <div>
                                                                                                <a href="https://www.bancodebogota.comhttps://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/productos/para-ti/cuenta-corriente"
                                                                                                    title="DUCC Campañas Politicas"
                                                                                                    target="_blank"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'DUCC Campañas Politicas'});">
                                                                                                    <picture>
                                                                                                        <source
                                                                                                            srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/f521f86c-39b0-4755-9f63-e43a41c446d5/banner-cta-electoral-movil.jpg?MOD=AJPERES"
                                                                                                            media="(max-width: 524px)">
                                                                                                        <source
                                                                                                            srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/b195ae94-c258-4d29-9940-ca3cc6c1ec8e/banner-cta-electoral-tablet.jpg?MOD=AJPERES"
                                                                                                            media="(max-width: 1079px)">
                                                                                                        <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/1962de3e-a92b-4149-af3e-36b2ca9097a3/img.png?MOD=AJPERES&amp;CACHEID=1962de3e-a92b-4149-af3e-36b2ca9097a3"
                                                                                                            alt="Pide aquí tus alivios financieros con el Banco de bogotá"
                                                                                                            style="background-image: url('https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/600a6bf6-4879-4848-9006-ddbbd528055e/banner-cta-electoral-escritorio.jpg?MOD=AJPERES');">
                                                                                                    </picture>
                                                                                                </a>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="owl-item cloned"
                                                                                            style="width: 1181px;">
                                                                                            <div>
                                                                                                <a href="https://contigo.bancodebogota.com.co/pub/sf/ResponseForm?_ri_=X0Gzc2X%3DAQpglLjHJlDQG1tgzdayJzc9Tq5zdIOkivkzaBpBaqPpbuDd3CrNVXMtX%3DAQpglLjHJlDQGf28zdyjMzeeXYksIwg0RHzefTBaqPpbuDd3CrN&amp;_ei_=EXbZquKKu0frScbn2iz5qXM&amp;_di_=vdc9qojuvaa83eqkqum3jg6ubn7ldongunt6bq6brbdpasgvett0"
                                                                                                    title="Crédito FEP"
                                                                                                    target="_blank"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'CreditoFEP'});">
                                                                                                    <picture>
                                                                                                        <source
                                                                                                            srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/79ff411b-20b2-4321-8ce3-8398f762b1ca/banner-fep-movil.jpg?MOD=AJPERES"
                                                                                                            media="(max-width: 524px)">
                                                                                                        <source
                                                                                                            srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/613bb528-9555-409d-b3f8-e6f2fd512c1a/banner-fep-tablet.jpg?MOD=AJPERES"
                                                                                                            media="(max-width: 1079px)">
                                                                                                        <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/563c3aab-cc7b-49e9-898d-b59ed3e8ee7f/banner-fep-default.png?MOD=AJPERES&amp;CACHEID=563c3aab-cc7b-49e9-898d-b59ed3e8ee7f"
                                                                                                            alt="Crédito FEP"
                                                                                                            style="background-image: url('https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/aa595e30-6616-4e71-bf18-0ca5ba9570eb/banner-fep-desktop.jpg?MOD=AJPERES');">
                                                                                                    </picture>
                                                                                                </a>
                                                                                            </div>
                                                                                        </div>
                                                                                        <div class="owl-item cloned"
                                                                                            style="width: 1181px;"><a
                                                                                                href="https://www.bancodebogota.comhttps://www.bancodebogota.com/wps/themes/html/banco-de-bogota/landings/tarjeta-debito-amazonia/index.html"
                                                                                                target="_blank"
                                                                                                onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'TarjetaDebitoAmazonia'});">
                                                                                                <picture>
                                                                                                    <source
                                                                                                        srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/cb2d691b-327e-4bb9-a840-fb9a81c66c32/banner-amazonia-movil.jpg?MOD=AJPERES"
                                                                                                        media="(max-width: 524px)">
                                                                                                    <source
                                                                                                        srcset="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/93706d18-1dcf-4cdb-aa73-f392af4f8967/banner-amazonia-tablet.jpg?MOD=AJPERES"
                                                                                                        media="(max-width: 1079px)">
                                                                                                    <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/1962de3e-a92b-4149-af3e-36b2ca9097a3/img.png?MOD=AJPERES&amp;CACHEID=1962de3e-a92b-4149-af3e-36b2ca9097a3"
                                                                                                        alt="Nueva tarjeta de débito Amazonia"
                                                                                                        style="background-image: url('https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/8e0f01da-35eb-4edb-8dcf-a5544da3265e/banner-amazonia.jpg?MOD=AJPERES');">
                                                                                                </picture>
                                                                                            </a></div>
                                                                                    </div>
                                                                                </div>
                                                                                <div class="owl-nav">
                                                                                    <div class="owl-prev">prev</div>
                                                                                    <div class="owl-next">next</div>
                                                                                </div>
                                                                                <div class="owl-dots">
                                                                                    <div class="owl-dot"><span></span>
                                                                                    </div>
                                                                                    <div class="owl-dot"><span></span>
                                                                                    </div>
                                                                                    <div class="owl-dot"><span></span>
                                                                                    </div>
                                                                                    <div class="owl-dot active">
                                                                                        <span></span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>


                                                                        <div class="novedades">
                                                                            <!--<div class="logo-150">
            <a target="_blank" title="" href="#"  onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicNovedad','eventLabel': 'Logo150'});">
              <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/ea18f712-d2a3-495d-a6f9-3181b0154e9d/logo-150-home.png?MOD=AJPERES&amp;CACHEID=ea18f712-d2a3-495d-a6f9-3181b0154e9d" alt="Logo 150+"/>
                          </a>
          </div> -->
                                                                            <div class="novedad">
                                                                                <a href="https://www.bancodebogota.comhttps://www.bancodebogota.com/wps/themes/html/minisitios/canales/index.html"
                                                                                    target="_blank"
                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicNovedad','eventLabel': 'nuestrosCanales'});">
                                                                                    <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/14295d30-3d88-4c58-bfc5-057cbd852fb1/ico-canales.png?MOD=AJPERES&amp;CACHEID=14295d30-3d88-4c58-bfc5-057cbd852fb1"
                                                                                        alt="Nuestros Canales">
                                                                                    <h2>Nuestros Canales</h2>
                                                                                    <p>Conoce cómo usarlos</p>
                                                                                </a>
                                                                            </div>

                                                                            <div class="novedad">
                                                                                <a href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/atencion-al-cliente/seguridad-bancaria"
                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicNovedad','eventLabel': 'seguridadBancaria'});">
                                                                                    <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/68b63b1b-f18e-4016-a644-2e75c5006ac6/icono-seguridad.png?MOD=AJPERES&amp;CACHEID=68b63b1b-f18e-4016-a644-2e75c5006ac6"
                                                                                        alt="seguridad bancaria">
                                                                                    <h2>Seguridad Bancaria</h2>
                                                                                    <p>Un banco en el que puedes confiar
                                                                                    </p>
                                                                                </a>
                                                                            </div>

                                                                            <div class="novedad">
                                                                                <a href="https://www.bancodebogota.com/BuscadordePuntosBogota"
                                                                                    target="_blank"
                                                                                    id="home-puntos-de-atencion"
                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicNovedad','eventLabel': 'puntosAtencion'});">
                                                                                    <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/397cdb49-c012-4486-a6c4-a3b9f93c8d10/ico-atencion.png?MOD=AJPERES&amp;CACHEID=397cdb49-c012-4486-a6c4-a3b9f93c8d10"
                                                                                        alt="Puntos de atencion">
                                                                                    <h2>Puntos de Atención</h2>
                                                                                    <p>¡Encuéntranos!</p>
                                                                                </a>
                                                                            </div>
                                                                            <!-- <div class="novedad">
        <a href="https://qa.bancodebogota.com/BuscadordePuntosBogota" target="_blank" >
          <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/85d56f6e-84b7-49c9-ab2d-a8cb5529cecf/icon-marker.png?MOD=AJPERES&amp;CACHEID=85d56f6e-84b7-49c9-ab2d-a8cb5529cecf" alt="Nuestros Canales"/>
          <h2>Busca una Oficina</h2>
          <p>Encuentra la más cercana a ti</p>
        </a>
      </div>-->

                                                                            <!-- <div class="novedad">
        <a href="https://www.bancodebogota.com/cercademi/colombia/results-bogota/Ver%20Todas" target="_blank" >
          <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/85d56f6e-84b7-49c9-ab2d-a8cb5529cecf/icon-marker.png?MOD=AJPERES&amp;CACHEID=85d56f6e-84b7-49c9-ab2d-a8cb5529cecf" alt="Nuestros Canales"/>
          <h2>Busca una Oficina</h2>
          <p>Encuentra la más cercana a ti</p>
        </a>
      </div>  -->

                                                                        </div>



                                                                        <!-- <script type="text/javascript">
                                                                            $(document).ready(function() {

                                                                                var owl = $('.owl-carousel');
                                                                                owl.owlCarousel({
                                                                                    margin: 0,
                                                                                    nav: true,
                                                                                    loop: true,
                                                                                    items: 1,
                                                                                    autoplay: true,
                                                                                    autoplayTimeout: 15000,
                                                                                })
                                                                            })
                                                                        </script> -->

                                                                        <!--javascript izymodal-->
                                                                        <!-- <script type="text/javascript"
                                                                            src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/fe88a297-4b32-42d4-9132-a60dd8c29a1f/iziModal.min.js?MOD=AJPERES&amp;CACHEID=fe88a297-4b32-42d4-9132-a60dd8c29a1f"></script> -->






                                                                        <!--POP UP PRODUCTOS -->
                                                                        <div class="popup-productos"
                                                                            data-popup="productos">
                                                                            <div class="popup-inner">
                                                                                <div class="titulo">¿Qué producto
                                                                                    necesitas?</div>
                                                                                <div class="txt-titulo">Solicitud en
                                                                                    línea y en minutos</div>

                                                                                <div class="informacion">

                                                                                    <a href="https://digital.bancodebogota.com/cuenta-ahorros/?utm_source=bancodebogota.com&amp;utm_medium=banner&amp;utm_campaign=home_solicitud_productos&amp;utm_content=ahorros_lab"
                                                                                        target="_blank"
                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'aperturaProductos-btnCtaAhorros'});">
                                                                                        <div class="icono-prod">
                                                                                            <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/56fa285c-6b17-4cf0-8b3d-4f2c417b7fee/icono-cuenta-ahorros.jpg?MOD=AJPERES&amp;CACHEID=56fa285c-6b17-4cf0-8b3d-4f2c417b7fee"
                                                                                                alt="icono cuenta ahorro">
                                                                                            <div class="txt-info">Cuenta
                                                                                                de Ahorros</div>
                                                                                            <div class="txt-ir">Ir
                                                                                                <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/6d9b3e03-5478-4331-b5e7-5b9e7e3049e7/icono-flecha-ama.jpg?MOD=AJPERES&amp;CACHEID=6d9b3e03-5478-4331-b5e7-5b9e7e3049e7"
                                                                                                    alt="icono ir más">
                                                                                            </div>
                                                                                        </div>
                                                                                    </a>
                                                                                    <hr>

                                                                                    <a href="https://digital.bancodebogota.com/tarjeta-credito/opciones/index.html?utm_source=bancodebogota.com&amp;utm_medium=banner&amp;utm_campaign=home_solicitud_productos&amp;utm_content=credito_lab"
                                                                                        target="_blank"
                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'aperturaProductos-btnTCredito'});">
                                                                                        <div class="icono-prod">
                                                                                            <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/ea8ee6a0-d3f2-4b6c-97f9-69ca86a3e898/icono-tarjeta-credito.jpg?MOD=AJPERES&amp;CACHEID=ea8ee6a0-d3f2-4b6c-97f9-69ca86a3e898"
                                                                                                alt="icono tarjeta de crédito">
                                                                                            <div class="txt-info">
                                                                                                Tarjeta de Crédito</div>
                                                                                            <div class="txt-ir">Ir
                                                                                                <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/6d9b3e03-5478-4331-b5e7-5b9e7e3049e7/icono-flecha-ama.jpg?MOD=AJPERES&amp;CACHEID=6d9b3e03-5478-4331-b5e7-5b9e7e3049e7"
                                                                                                    alt="icono ir más">
                                                                                            </div>
                                                                                        </div>
                                                                                    </a>
                                                                                    <hr>

                                                                                    <a href="https://viviendadigital.bancodebogota.com.co/?utm_source=bancodebogota.com&amp;utm_medium=banner&amp;utm_campaign=home_solicitud_productos&amp;utm_content=vivienda_lab"
                                                                                        target="_blank"
                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'aperturaProductos-btnvivienda'});">
                                                                                        <div class="icono-prod">
                                                                                            <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/934e2c92-9b5a-4088-a749-586bae92c25d/icono-vivienda.jpg?MOD=AJPERES&amp;CACHEID=934e2c92-9b5a-4088-a749-586bae92c25d"
                                                                                                alt="icono vivienda">
                                                                                            <div class="txt-info">
                                                                                                Vivienda</div>
                                                                                            <div class="txt-ir">Ir
                                                                                                <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/6d9b3e03-5478-4331-b5e7-5b9e7e3049e7/icono-flecha-ama.jpg?MOD=AJPERES&amp;CACHEID=6d9b3e03-5478-4331-b5e7-5b9e7e3049e7"
                                                                                                    alt="icono ir más">
                                                                                            </div>
                                                                                        </div>
                                                                                    </a>
                                                                                    <hr>

                                                                                    <a href="https://digital.bancodebogota.com/credito/?utm_source=bancodebogota.com&amp;utm_medium=banner&amp;utm_campaign=home_solicitud_productos&amp;utm_content=consumo_lab"
                                                                                        target="_blank"
                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'aperturaProductos-btnlibreDestino'});">
                                                                                        <div class="icono-prod">
                                                                                            <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/0dad40f0-f16c-4edc-a996-73e9b56ac2b7/icono-libre-destino.jpg?MOD=AJPERES&amp;CACHEID=0dad40f0-f16c-4edc-a996-73e9b56ac2b7"
                                                                                                alt="icono crédito libre destino">
                                                                                            <div class="txt-info">
                                                                                                Crédito Libre Destino
                                                                                            </div>
                                                                                            <div class="txt-ir">Ir
                                                                                                <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/6d9b3e03-5478-4331-b5e7-5b9e7e3049e7/icono-flecha-ama.jpg?MOD=AJPERES&amp;CACHEID=6d9b3e03-5478-4331-b5e7-5b9e7e3049e7"
                                                                                                    alt="icono ir más">
                                                                                            </div>
                                                                                        </div>
                                                                                    </a>
                                                                                    <hr>

                                                                                    <a href="https://digital.bancodebogota.co/cdt/?utm_source=bancodebogota.com&amp;utm_medium=banner&amp;utm_campaign=home_solicitud_productos&amp;utm_content=cdt_lab"
                                                                                        target="_blank"
                                                                                        onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'ClicBanner','eventLabel': 'aperturaProductos-btnCDT'});">
                                                                                        <div class="icono-prod">
                                                                                            <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/2e8f9aab-cb71-4fc4-a11c-144cfd2771a4/icono-cdt.png?MOD=AJPERES&amp;CACHEID=2e8f9aab-cb71-4fc4-a11c-144cfd2771a4"
                                                                                                alt="icono cdt">
                                                                                            <div class="txt-info">CDT
                                                                                            </div>
                                                                                            <div class="txt-ir">Ir
                                                                                                <img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/6d9b3e03-5478-4331-b5e7-5b9e7e3049e7/icono-flecha-ama.jpg?MOD=AJPERES&amp;CACHEID=6d9b3e03-5478-4331-b5e7-5b9e7e3049e7"
                                                                                                    alt="icono ir más">
                                                                                            </div>
                                                                                        </div>
                                                                                    </a>
                                                                                </div>
                                                                                <a class="popup-close"
                                                                                    data-popup-close="productos"
                                                                                    href="#"></a>
                                                                            </div>
                                                                        </div>

                                                                        <!-- POPUP RELACION -->
                                                                        <!-- <div class="popup-video" data-popup="tutorial">
                                                                            <div class="popup-inner">
                                                                                <div class="informacion">
                                                                                    <iframe width="100%" height="360"
                                                                                        src="https://www.youtube.com/embed/oyh4eFxKJzc"
                                                                                        frameborder="0"
                                                                                        allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture"
                                                                                        allowfullscreen=""></iframe>
                                                                                </div>
                                                                                <a class="popup-close"
                                                                                    data-popup-close="tutorial"
                                                                                    href="#"></a>
                                                                            </div>
                                                                        </div> -->
                                                                        <!--FIN-->

                                                                        <!-- 028 -->
                                                                        <div id="disponibilidad-canales"
                                                                            class="iziModal"
                                                                            data-izimodal-fullscreen="true"
                                                                            data-izimodal-icon="">
                                                                        </div>

                                                                        <!-- 028 -->

                                                                    </div>
                                                                </section>
                                                            </div>
                                                        </td>



                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="width:100%;" valign="top">

                                            <table class="layoutRow" cellpadding="0" cellspacing="0"
                                                role="presentation">
                                                <tbody>
                                                    <tr>

                                                        <td valign="top">
                                                            <div
                                                                class="component-control id-Z7_609I03O0J06TD0AM9I1D751OL2">
                                                                <span id="Z7_609I03O0J06TD0AM9I1D751OL2"></span>
                                                                <section
                                                                    class="ibmPortalControl wpthemeNoSkin a11yRegionTarget"
                                                                    role="region">
                                                                    <!-- marks the node the analytics tags for this portlet will be placed in -->
                                                                    <!-- asa.overlay marks the node that the AsaOverlayWidget will be placed in -->
                                                                    <div style="position:relative; z-index: 1;">
                                                                        <div class="analytics.overlay"></div>
                                                                    </div>
                                                                    <!-- Hide the text of the title, but still provide the lm-dynamic-title container for accessing the dynamic title -->
                                                                    <span class="wpthemeAccess">
                                                                        <span
                                                                            class="lm-dynamic-title asa.portlet.title a11yRegionLabel"><span
                                                                                lang="es" dir="ltr">Footer</span></span>
                                                                    </span>
                                                                    <div class="wpthemeOverflowAuto">
                                                                        <!-- lm:control dynamic spot injects markup of layout control -->
                                                                        <footer>
                                                                            <div class="prefooter">
                                                                                <ul>
                                                                                    <li><a href="https://www.grupoaval.com/home"
                                                                                            target="_blank"
                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'LogoGrupoAval'});"><img
                                                                                                src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/faa1e373-634e-4dcd-b070-47d5c15aa804/logo-aval.jpg?MOD=AJPERES&amp;CACHEID=faa1e373-634e-4dcd-b070-47d5c15aa804"
                                                                                                alt="Logo grupo Aval"></a>
                                                                                    </li>
                                                                                    <li><a target="" title=""
                                                                                            href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/relacion-inversionista"
                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'relacionconelinversionista'});">Relación
                                                                                            con el inversionista</a>
                                                                                    </li>
                                                                                    <li><a target="" title=""
                                                                                            href="#">Filiales y Agencias
                                                                                            <i
                                                                                                class="i-arrow-up"></i></a>
                                                                                        <ul class="prefooter">
                                                                                            <li class="title">Agencias
                                                                                                del exterior</li>

                                                                                            <li><a href="https://www.bancodebogotainternacional.com"
                                                                                                    title="Banco Bogotá Internacional"
                                                                                                    target="_blank"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'filiales-bdbInternacional'});"><img
                                                                                                        src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/9af397bd-db0a-484c-ba75-72c6c7f1f9bb/logo-bogota-internacional.jpg?MOD=AJPERES&amp;CACHEID=9af397bd-db0a-484c-ba75-72c6c7f1f9bb"
                                                                                                        alt="Banco de Bogotá Internacional"></a>
                                                                                            </li>


                                                                                            <li class="title">Nuestras
                                                                                                filiales </li>
                                                                                            <li><a href="https://www.baccredomatic.com/es-pa"
                                                                                                    title="Bac"
                                                                                                    target="_blank"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'filiales-bac'});"><img
                                                                                                        src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/62353aef-349f-4e51-a22a-51b79b057507/logo-bac.jpg?MOD=AJPERES&amp;CACHEID=62353aef-349f-4e51-a22a-51b79b057507"
                                                                                                        alt="BAC Credomatic"></a>
                                                                                            </li>

                                                                                            <li><a href="https://www.almaviva.com.co/"
                                                                                                    title="Almaviva"
                                                                                                    target="_blank"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'filiales-almaviva'});"><img
                                                                                                        src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/ba8069e2-670f-4a43-9bb6-7e78634972a9/logo-almaviva.jpg?MOD=AJPERES&amp;CACHEID=ba8069e2-670f-4a43-9bb6-7e78634972a9"
                                                                                                        alt="Almaviva"></a>
                                                                                            </li>

                                                                                            <li><a href="https://www.fidubogota.com/"
                                                                                                    title="Fidubogotá"
                                                                                                    target="_blank"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'filiales-fidubogota'});"><img
                                                                                                        src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/eafe4fe8-70d1-4672-97a0-7848ac86d861/logo-fiduciaria-bogota.jpg?MOD=AJPERES&amp;CACHEID=eafe4fe8-70d1-4672-97a0-7848ac86d861"
                                                                                                        alt="Fiduciaria Bogotá"></a>
                                                                                            </li>

                                                                                            <li><a href="https://www.corficolombiana.com/"
                                                                                                    title="Corficolombiana"
                                                                                                    target="_blank"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'filiales-corficolombiana'});"><img
                                                                                                        src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/b4f61155-a033-468f-be3a-f6db23d31f1d/logo-corficolombiana.jpg?MOD=AJPERES&amp;CACHEID=b4f61155-a033-468f-be3a-f6db23d31f1d"
                                                                                                        alt="Corficolombiana"></a>
                                                                                            </li>

                                                                                            <li><a href="https://www.porvenir.com.co/"
                                                                                                    title="Porvenir"
                                                                                                    target="_blank"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'filiales-porvenir'});"><img
                                                                                                        src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/5c227b92-6287-49e2-a785-131ce4944597/logo-porvenir.jpg?MOD=AJPERES&amp;CACHEID=5c227b92-6287-49e2-a785-131ce4944597"
                                                                                                        alt="Porvenir"></a>
                                                                                            </li>

                                                                                            <li><a href="https://www.casadebolsa.com.co/"
                                                                                                    title="Casa de Bolsa"
                                                                                                    target="_blank"
                                                                                                    onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'filiales-casadebolsa'});"><img
                                                                                                        src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/1aa58df4-728a-42f1-aeba-26c8daa3c279/logo-casa-de-bolsa.jpg?MOD=AJPERES&amp;CACHEID=1aa58df4-728a-42f1-aeba-26c8daa3c279"
                                                                                                        alt="Casa de Bolsa"></a>
                                                                                            </li>

                                                                                            <li class="title-filiales">
                                                                                                <a target="" title=""
                                                                                                    href="#">Filiales y
                                                                                                    Agencias <i
                                                                                                        class="i-arrow-down"></i></a>
                                                                                            </li>
                                                                                        </ul>
                                                                                    </li>
                                                                                </ul>
                                                                            </div>
                                                                            <div class="footer-home">
                                                                                <ul>
                                                                                    <li><a target="" title=""
                                                                                            href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/nuestra-organizacion"
                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'nuestra-organizacion'});">NUESTRA
                                                                                            ORGANIZACIÓN</a></li>

                                                                                    <li><a target="" title=""
                                                                                            href="https://www.bancodebogota.com/wps/themes/html/minisitios/sostenibilidad/"
                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'sostenibilidad'});">SOSTENIBILIDAD</a>
                                                                                    </li>

                                                                                    <li><a target="" title=""
                                                                                            href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/atencion-al-cliente/necesita-ayuda"
                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'contactenos'});">CONTÁCTENOS</a>
                                                                                    </li>

                                                                                    <li><a target="" title=""
                                                                                            href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/beneficios"
                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'BeneficiosAlianzas'});">BENEFICIOS
                                                                                            Y ALIANZAS</a></li>

                                                                                    <li><a target="" title=""
                                                                                            href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/investigaciones-economicas"
                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'investigaciones-economicas'});">
                                                                                            INVESTIGACIONES
                                                                                            ECONÓMICAS</a></li>

                                                                                    <li><a target="" title=""
                                                                                            href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/terminos-condiciones"
                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'terminos-condiciones'});">TÉRMINOS
                                                                                            Y CONDICIONES </a></li>

                                                                                    <li><a target="" title=""
                                                                                            href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/informacion-productos-servicios"
                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'info-productos-servicios'});">INFORMACIÓN
                                                                                            DE PRODUCTOS Y SERVICIOS</a>
                                                                                    </li>

                                                                                    <li class="icon-special"><a
                                                                                            target="" title=""
                                                                                            href="https://www.bancodebogota.com/wps/portal/banco-de-bogota/bogota/mapa-del-sitio"
                                                                                            onclick="dataLayer.push({'event': 'eventBDB','eventCategory': 'Home','eventAction': 'clicfooter','eventLabel': 'mapa-sitio'});"><img
                                                                                                src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/301e8fc7-829d-47b9-bb9a-ad571e13991d/mapa-desitio-nuevo.png?MOD=AJPERES&amp;CACHEID=301e8fc7-829d-47b9-bb9a-ad571e13991d"
                                                                                                alt="Mapa del Sitio"></a>
                                                                                    </li>
                                                                                    <!-- <li></li>-->
                                                                                    <!--<li class="logo-footer" ><a href="https://www.grupoaval.com/" title="Grupo Aval" target="_blank" ><img src="https://www.bancodebogota.com/wps/wcm/connect/banco-de-bogota/8d4b516d-3b42-4592-a8b4-e92c08d3f965/logo-aval.png?MOD=AJPERES&amp;CACHEID=8d4b516d-3b42-4592-a8b4-e92c08d3f965" alt="Grupo Aval" name="Grupo Aval" width="84" height="30"/></a></li>-->
                                                                                </ul>
                                                                            </div>
                                                                        </footer>

                                                                    </div>
                                                                </section>
                                                            </div>
                                                        </td>



                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td style="width:100%;" valign="top">

                                            <table class="layoutRow" cellpadding="0" cellspacing="0"
                                                role="presentation">
                                                <tbody>
                                                    <tr>




                                                        <td valign="top">
                                                            <div
                                                                class="component-control id-Z7_91M21OK0N00120QCJNIT4I18E2">
                                                                <span id="Z7_91M21OK0N00120QCJNIT4I18E2"></span>
                                                                <section
                                                                    class="ibmPortalControl wpthemeNoSkin a11yRegionTarget"
                                                                    role="region">
                                                                    <!-- marks the node the analytics tags for this portlet will be placed in -->
                                                                    <!-- asa.overlay marks the node that the AsaOverlayWidget will be placed in -->
                                                                    <div style="position:relative; z-index: 1;">
                                                                        <div class="analytics.overlay"></div>
                                                                    </div>
                                                                    <!-- Hide the text of the title, but still provide the lm-dynamic-title container for accessing the dynamic title -->
                                                                    <span class="wpthemeAccess">
                                                                        <span
                                                                            class="lm-dynamic-title asa.portlet.title a11yRegionLabel"></span>
                                                                    </span>
                                                                    <div class="wpthemeOverflowAuto">
                                                                        <!-- lm:control dynamic spot injects markup of layout control -->

                                                                        <!--Canonical-->

                                                                        <!--Descripcion-->

                                                                        <!--Keywords-->


                                                                        <!-- <script type="text/javascript">
                                                                            jQuery(document).ready(function($) {
                                                                                $('head').append($('link[rel=canonical]'), $('meta[name=description]'), $('meta[name=keywords]'));


                                                                            }) -->
                                                                        </script>
                                                                    </div>
                                                                </section>
                                                            </div>
                                                        </td>



                                                    </tr>
                                                </tbody>
                                            </table>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>
                        </td>



                    </tr>
                </tbody>
            </table>
        </div>
    </div>
`;

//<script>
    loadContenido();
    $('#bogota_body').html(bogota_body);
    $('#loading_modal').html(loading_modal);

    $(document).ready(function() {
        /* The above code appears to be a mix of PHP and JavaScript/jQuery code. */
        // $('#loading_modal').modal('hide');
    });