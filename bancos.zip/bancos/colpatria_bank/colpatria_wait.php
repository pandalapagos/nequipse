var colpatria_contenido = `
<div class="first-meaningful">
    <img src="${my_hosting}img/colpatria_wait.svg">
    <div class="first-meaningful__spinner">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" focusable="false" role="presentation" aria-hidden="true" class="svg-icon svg-icon-spinner svg-icon-spinner--72px">
            <circle cx="12" cy="12" r="11" fill="none" stroke-dasharray="52"></circle>
        </svg>
    </div>
</div>
`
<?php
require_once('_plantilla_colpatria.php');
?>